using System.Security.Cryptography;
using Konscious.Security.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Cryptography.Tests;

public class Argon2idKeyDeriverTests
{
    private static byte[] Salt(byte fill = 7) => Enumerable.Repeat(fill, KdfParams.SaltLength).ToArray();

    [Fact]
    public void SameInputs_SameKey()
    {
        using var a = Argon2idKeyDeriver.DeriveKey(TestData.Password, Salt(), TestData.FastKdf);
        using var b = Argon2idKeyDeriver.DeriveKey(TestData.Password, Salt(), TestData.FastKdf);
        Assert.Equal(32, a.Length);
        Assert.True(CryptographicOperations.FixedTimeEquals(a.Span, b.Span));
    }

    [Fact]
    public void DifferentSalt_DifferentKey()
    {
        using var a = Argon2idKeyDeriver.DeriveKey(TestData.Password, Salt(1), TestData.FastKdf);
        using var b = Argon2idKeyDeriver.DeriveKey(TestData.Password, Salt(2), TestData.FastKdf);
        Assert.False(CryptographicOperations.FixedTimeEquals(a.Span, b.Span));
    }

    [Fact]
    public void DifferentPassword_DifferentKey()
    {
        using var a = Argon2idKeyDeriver.DeriveKey(TestData.Password, Salt(), TestData.FastKdf);
        using var b = Argon2idKeyDeriver.DeriveKey(TestData.OtherPassword, Salt(), TestData.FastKdf);
        Assert.False(CryptographicOperations.FixedTimeEquals(a.Span, b.Span));
    }

    [Fact]
    public void DifferentCostParameters_DifferentKey()
    {
        var costlier = new KdfParams(KdfParams.MinMemoryKiB, 2, 1);
        using var a = Argon2idKeyDeriver.DeriveKey(TestData.Password, Salt(), TestData.FastKdf);
        using var b = Argon2idKeyDeriver.DeriveKey(TestData.Password, Salt(), costlier);
        Assert.False(CryptographicOperations.FixedTimeEquals(a.Span, b.Span));
    }

    [Fact]
    public void UnicodeNormalization_ComposedAndDecomposedMatch()
    {
        string composed = "caf\u00E9 password";      // é as one code point
        string decomposed = "cafe\u0301 password";  // e + combining acute
        using var a = Argon2idKeyDeriver.DeriveKey(composed, Salt(), TestData.FastKdf);
        using var b = Argon2idKeyDeriver.DeriveKey(decomposed, Salt(), TestData.FastKdf);
        Assert.True(CryptographicOperations.FixedTimeEquals(a.Span, b.Span));
    }

    [Fact]
    public void RejectsEmptyPasswordAndBadSalt()
    {
        Assert.Throws<ArgumentException>(() => Argon2idKeyDeriver.DeriveKey("", Salt(), TestData.FastKdf));
        Assert.Throws<ArgumentException>(() => Argon2idKeyDeriver.DeriveKey(TestData.Password, new byte[16], TestData.FastKdf));
    }

    [Fact]
    public void RejectsOutOfBoundsParameters()
    {
        Assert.Throws<InvalidVaultFormatException>(() =>
            Argon2idKeyDeriver.DeriveKey(TestData.Password, Salt(), new KdfParams(int.MaxValue, 3, 4)));
    }

    /// <summary>
    /// Known-answer test: RFC 9106 section 5.3 Argon2id vector (password 32x0x01, salt 16x0x02,
    /// secret 8x0x03, associated data 12x0x04, t=3, m=32 KiB, p=4, 32-byte tag). This runs the
    /// Konscious library directly (32 KiB is below our production floor) to confirm the dependency
    /// implements standard Argon2id. If this fails, STOP and investigate the package version.
    /// </summary>
    [Fact]
    public void KonsciousArgon2id_MatchesRfc9106Vector()
    {
        using var argon2 = new Argon2id(Enumerable.Repeat((byte)0x01, 32).ToArray())
        {
            Salt = Enumerable.Repeat((byte)0x02, 16).ToArray(),
            KnownSecret = Enumerable.Repeat((byte)0x03, 8).ToArray(),
            AssociatedData = Enumerable.Repeat((byte)0x04, 12).ToArray(),
            Iterations = 3,
            MemorySize = 32,
            DegreeOfParallelism = 4
        };
        byte[] tag = argon2.GetBytes(32);
        Assert.Equal("0d640df58d78766c08c037a34a8b53c9d01ef0452d75b65eb52520e96b01e659",
            Convert.ToHexString(tag).ToLowerInvariant());
    }
}
