using System.Security.Cryptography;

namespace SecureUSB.Cryptography.Tests;

public class AeadTests
{
    private static byte[] Key() => SecureRandom.GetBytes(Aead.KeySize);
    private static readonly byte[] Aad = { 1, 2, 3 };

    [Fact]
    public void SealOpen_RoundTrips()
    {
        byte[] key = Key();
        byte[] plain = TestData.RandomData(100);
        byte[] sealedData = Aead.Seal(key, plain, Aad);
        Assert.Equal(plain.Length + Aead.Overhead, sealedData.Length);
        Assert.Equal(plain, Aead.Open(key, sealedData, Aad));
    }

    [Fact]
    public void SealOpen_EmptyPlaintext()
    {
        byte[] key = Key();
        byte[] sealedData = Aead.Seal(key, ReadOnlySpan<byte>.Empty, Aad);
        Assert.Empty(Aead.Open(key, sealedData, Aad));
    }

    [Fact]
    public void Seal_UsesFreshNonceEveryTime()
    {
        byte[] key = Key();
        var nonces = new HashSet<string>();
        for (int i = 0; i < 200; i++)
            nonces.Add(Convert.ToHexString(Aead.Seal(key, new byte[] { 1 }, Aad).AsSpan(0, Aead.NonceSize)));
        Assert.Equal(200, nonces.Count);
    }

    [Fact]
    public void Open_WrongKey_Fails()
    {
        byte[] sealedData = Aead.Seal(Key(), new byte[] { 1, 2, 3 }, Aad);
        Assert.ThrowsAny<CryptographicException>(() => Aead.Open(Key(), sealedData, Aad));
    }

    [Fact]
    public void Open_WrongAad_Fails()
    {
        byte[] key = Key();
        byte[] sealedData = Aead.Seal(key, new byte[] { 1, 2, 3 }, Aad);
        Assert.ThrowsAny<CryptographicException>(() => Aead.Open(key, sealedData, new byte[] { 9 }));
    }

    [Fact]
    public void Open_AnyBitFlip_Fails()
    {
        byte[] key = Key();
        byte[] good = Aead.Seal(key, TestData.RandomData(40), Aad);
        for (int i = 0; i < good.Length; i++)
        {
            byte[] bad = (byte[])good.Clone();
            bad[i] ^= 0x01;
            Assert.ThrowsAny<CryptographicException>(() => Aead.Open(key, bad, Aad));
        }
    }

    [Fact]
    public void Open_TooShort_Fails()
    {
        Assert.ThrowsAny<CryptographicException>(() => Aead.Open(Key(), new byte[Aead.Overhead - 1], Aad));
    }

    [Fact]
    public void RejectsWrongKeyLength()
    {
        Assert.Throws<ArgumentException>(() => Aead.Seal(new byte[31], new byte[1], Aad));
    }
}
