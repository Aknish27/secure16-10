using SecureUSB.Core;
using SecureUSB.Cryptography;
using SecureUSB.Models;
using SecureUSB.Storage;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.ViewModels.Tests;

internal static class Pw
{
    public const string P1 = "correct horse battery staple";
    public const string P2 = "tulip granite harbor violin mosaic";
    public const string P3 = "quantum lantern orchid velvet meadow";
    public const string Wrong = "this is definitely the wrong password";
}

internal sealed class FakeDrive : IDriveInfoService
{
    public long Total = 32L << 30;
    public long Free = 20L << 30;
    public string FileSystem = "exFAT";
    public bool Available = true;

    public DriveCapacity GetCapacity(string path)
    {
        if (!Available) throw new IOException("Simulated: the USB drive was removed.");
        return new DriveCapacity("E:\\", "TESTUSB", FileSystem, DriveType.Removable, Total, Free);
    }

    public bool IsAvailable(string path) => Available;
}

internal sealed class FixedTime : TimeProvider
{
    public DateTimeOffset Now = new(2026, 1, 1, 12, 0, 0, TimeSpan.Zero);
    public override DateTimeOffset GetUtcNow() => Now;
    public void Advance(TimeSpan span) => Now += span;
}

internal sealed class TempVault : IDisposable
{
    public string Root { get; } = Path.Combine(Path.GetTempPath(), "secureusb-vm-tests-" + Guid.NewGuid().ToString("N"));
    public FakeDrive Drive { get; } = new();
    public FixedTime Time { get; } = new();

    public TempVault() => Directory.CreateDirectory(Root);

    public string Sub(string name)
    {
        string p = Path.Combine(Root, name);
        Directory.CreateDirectory(p);
        return p;
    }

    public void Dispose()
    {
        try { Directory.Delete(Root, recursive: true); } catch { /* best effort */ }
    }
}

internal sealed class FakeNav : IShellNavigation
{
    public int WelcomeCount, DashboardCount, ActivityCount;
    public List<VaultLocation> Opened { get; } = new();
    public void ShowWelcome() => WelcomeCount++;
    public void OpenLocation(VaultLocation location) => Opened.Add(location);
    public void ShowDashboard() => DashboardCount++;
    public void NotifyActivity() => ActivityCount++;
}

internal sealed class FakeDialogs : IDialogService
{
    public bool DefaultConfirm = true;
    public Queue<bool> ConfirmAnswers { get; } = new();
    public Queue<string?> PromptAnswers { get; } = new();
    public List<ConfirmRequest> Confirms { get; } = new();
    public List<PromptRequest> Prompts { get; } = new();
    public List<(string Title, string Message, MessageKind Kind)> Messages { get; } = new();
    public List<ModalViewModel> Modals { get; } = new();
    /// <summary>Lets a test act on a modal at the moment it is "shown".</summary>
    public Func<ModalViewModel, Task>? ModalHandler { get; set; }

    public Task<bool> ConfirmAsync(ConfirmRequest request)
    {
        Confirms.Add(request);
        return Task.FromResult(ConfirmAnswers.Count > 0 ? ConfirmAnswers.Dequeue() : DefaultConfirm);
    }

    public Task<string?> PromptAsync(PromptRequest request)
    {
        Prompts.Add(request);
        return Task.FromResult(PromptAnswers.Count > 0 ? PromptAnswers.Dequeue() : null);
    }

    public Task ShowMessageAsync(string title, string message, MessageKind kind = MessageKind.Information)
    {
        Messages.Add((title, message, kind));
        return Task.CompletedTask;
    }

    public Task ShowModalAsync(ModalViewModel modal)
    {
        Modals.Add(modal);
        return ModalHandler?.Invoke(modal) ?? Task.CompletedTask;
    }
}

internal sealed class FakeFiles : IFileDialogService
{
    public List<string> FilesToPick { get; } = new();
    public string? FolderToPick { get; set; }
    public int FilePicks, FolderPicks;

    public IReadOnlyList<string> PickFiles(string title)
    {
        FilePicks++;
        return FilesToPick.ToList();
    }

    public string? PickFolder(string title)
    {
        FolderPicks++;
        return FolderToPick;
    }
}

internal sealed class FakeLauncher : IShellLauncher
{
    public List<string> Opened { get; } = new();
    public List<byte[]> ContentAtOpen { get; } = new();

    public void OpenFile(string path)
    {
        Opened.Add(path);
        ContentAtOpen.Add(File.ReadAllBytes(path));
    }
}

internal sealed class FakeTheme : IThemeService
{
    public List<ThemeKind> Applied { get; } = new();
    public void Apply(ThemeKind theme) => Applied.Add(theme);
}

/// <summary>Runs posted work immediately; timers only fire when the test calls <see cref="Tick"/>.</summary>
internal sealed class ManualScheduler : IUiScheduler
{
    private readonly List<ManualTimer> _timers = new();
    public int ActiveTimers => _timers.Count(t => !t.Disposed);

    public void Post(Action action) => action();

    public IDisposable Every(TimeSpan interval, Action tick)
    {
        var t = new ManualTimer(tick);
        _timers.Add(t);
        return t;
    }

    public void Tick()
    {
        foreach (ManualTimer t in _timers.ToList())
            if (!t.Disposed) t.Fire();
    }

    private sealed class ManualTimer : IDisposable
    {
        private readonly Action _tick;
        public ManualTimer(Action tick) => _tick = tick;
        public bool Disposed { get; private set; }
        public void Fire() => _tick();
        public void Dispose() => Disposed = true;
    }
}

internal sealed class FakeLocations : ILocationProvider
{
    public List<VaultLocation> Found { get; } = new();
    public bool ThrowOnDiscover { get; set; }

    public IReadOnlyList<VaultLocation> Discover()
    {
        if (ThrowOnDiscover) throw new IOException("drive enumeration failed");
        return Found.ToList();
    }

    public VaultLocation FromFolder(string root) =>
        new(root, Path.GetFileName(root), "Selected folder", Directory.Exists(VaultPaths.ForUsbRoot(root).DataDirectory), false, false);
}

internal sealed class FakeFactory : IVaultServiceFactory
{
    private readonly TempVault _t;
    private readonly string _tempRoot;
    public List<VaultService> Created { get; } = new();
    public Exception? ThrowOnCreate { get; set; }

    public FakeFactory(TempVault t, string tempRoot)
    {
        _t = t;
        _tempRoot = tempRoot;
    }

    public VaultService Create(VaultLocation location)
    {
        if (ThrowOnCreate is not null) throw ThrowOnCreate;
        VaultService service = Make(_t, _tempRoot, VaultPaths.ForUsbRoot(location.Root));
        Created.Add(service);
        return service;
    }

    public static VaultService Make(TempVault t, string tempRoot, VaultPaths paths) => new(new VaultServiceOptions
    {
        Paths = paths,
        Drive = t.Drive,
        TempRoot = tempRoot,
        Time = t.Time,
        Kdf = new KdfParams(KdfParams.MinMemoryKiB, 1, 1),
        UsbPollInterval = TimeSpan.Zero,
        LockDrainTimeout = TimeSpan.FromMilliseconds(300),
        ApplicationPaths = new[] { Path.Combine(t.Root, "SecureUSB.exe") }
    });
}

internal static class Data
{
    public static byte[] Bytes(int length, int seed = 1)
    {
        var data = new byte[length];
        new Random(seed).NextBytes(data);
        return data;
    }

    public static void FlipByte(string path, int offset)
    {
        byte[] b = File.ReadAllBytes(path);
        b[offset] ^= 0x01;
        File.WriteAllBytes(path, b);
    }
}

/// <summary>A scratch USB drive with a real VaultService on it.</summary>
internal class ServiceKit : IDisposable
{
    private readonly List<VaultService> _services = new();

    public TempVault T { get; } = new();
    public string TempRoot { get; }
    public VaultPaths Paths { get; }
    public VaultService Service { get; }
    public VaultLocation Location { get; }

    public ServiceKit()
    {
        TempRoot = T.Sub("hostTemp");
        Paths = VaultPaths.ForUsbRoot(T.Root);
        Service = NewService();
        Location = new VaultLocation(T.Root, "Test USB", "TESTUSB \u00B7 exFAT", false, true, true);
    }

    public VaultService NewService()
    {
        VaultService s = FakeFactory.Make(T, TempRoot, Paths);
        _services.Add(s);
        return s;
    }

    /// <summary>Creates the vault (password P1) and leaves it unlocked.</summary>
    public VaultService Unlocked()
    {
        Service.CreateVault(Pw.P1, Pw.P1);
        return Service;
    }

    /// <summary>Creates the vault and locks it again.</summary>
    public VaultService Locked()
    {
        Unlocked();
        Service.Lock();
        return Service;
    }

    public string Source(string name, byte[]? data = null, string subfolder = "src")
    {
        string dir = T.Sub(subfolder);
        string path = Path.Combine(dir, name);
        File.WriteAllBytes(path, data ?? Data.Bytes(500));
        return path;
    }

    public virtual void Dispose()
    {
        for (int i = _services.Count - 1; i >= 0; i--) _services[i].Dispose();
        T.Dispose();
    }
}

/// <summary>ServiceKit + an unlocked vault + a DashboardViewModel wired to fakes.</summary>
internal sealed class DashboardKit : ServiceKit
{
    public FakeNav Nav { get; } = new();
    public FakeDialogs Dialogs { get; } = new();
    public FakeFiles Files { get; } = new();
    public FakeLauncher Launcher { get; } = new();
    public SessionSettings Settings { get; } = new();
    public DashboardViewModel Dashboard { get; }

    public DashboardKit(bool initialize = true)
    {
        Unlocked();
        Dashboard = new DashboardViewModel(Service, Location, Nav, Dialogs, Files, Launcher, Settings,
            new AppInfo("SecureUSB", "1.0.0-test"), T.Time);
        if (initialize) Dashboard.InitializeAsync().GetAwaiter().GetResult();
    }

    public FileEntry Seed(string name, byte[]? data = null, string folder = "")
    {
        string src = Source(name, data, "seed" + Guid.NewGuid().ToString("N"));
        FileEntry e = Service.AddFile(src, folder);
        return e;
    }

    public async Task SeedAndRefreshAsync(params (string Name, string Folder)[] files)
    {
        foreach (var (name, folder) in files) Seed(name, null, folder);
        await Dashboard.RefreshAsync();
    }

    public VaultItemViewModel Item(string name) => Dashboard.Items.Single(i => i.Name == name);

    public void Select(params string[] names) =>
        Dashboard.SetSelection(names.Select(Item).ToList());

    public override void Dispose()
    {
        Dashboard.Dispose();
        base.Dispose();
    }
}
