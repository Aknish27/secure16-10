using SecureUSB.Core;
using SecureUSB.Models;
using SecureUSB.Storage;

namespace SecureUSB.ViewModels.Tests;

public class WelcomeViewModelTests
{
    private static VaultLocation Loc(string root, bool hasVault = false) => new(root, "Drive " + root, "details", hasVault, true, false);

    [Fact]
    public void ListsTheDrivesItFinds()
    {
        var locations = new FakeLocations();
        locations.Found.Add(Loc("E:\\", true));
        locations.Found.Add(Loc("F:\\"));

        var vm = new WelcomeViewModel(new FakeNav(), locations, new FakeFiles());

        Assert.Equal(2, vm.Locations.Count);
        Assert.True(vm.HasLocations);
        Assert.Equal("Vault found", vm.Locations[0].StatusText);
        Assert.Equal("No vault yet", vm.Locations[1].StatusText);
    }

    [Fact]
    public void WithoutDrives_ExplainsWhatToDo()
    {
        var vm = new WelcomeViewModel(new FakeNav(), new FakeLocations(), new FakeFiles());
        Assert.False(vm.HasLocations);
        Assert.Contains("Insert your SecureUSB drive", vm.Message);
    }

    [Fact]
    public void FailingDriveEnumeration_DoesNotBreakTheScreen()
    {
        var vm = new WelcomeViewModel(new FakeNav(), new FakeLocations { ThrowOnDiscover = true }, new FakeFiles());
        Assert.False(vm.HasLocations);
        Assert.NotEmpty(vm.Message);
    }

    [Fact]
    public void ChoosingADrive_OpensIt()
    {
        var nav = new FakeNav();
        var locations = new FakeLocations();
        VaultLocation drive = Loc("E:\\", true);
        locations.Found.Add(drive);
        var vm = new WelcomeViewModel(nav, locations, new FakeFiles());

        vm.SelectCommand.Execute(drive);

        Assert.Equal(new[] { drive }, nav.Opened);
    }

    [Fact]
    public void Browse_OpensTheChosenFolder_AndDoesNothingWhenCancelled()
    {
        var nav = new FakeNav();
        var files = new FakeFiles();
        var vm = new WelcomeViewModel(nav, new FakeLocations(), files);

        vm.BrowseCommand.Execute(null);
        Assert.Empty(nav.Opened);

        files.FolderToPick = Path.GetTempPath();
        vm.BrowseCommand.Execute(null);
        Assert.Equal(Path.GetTempPath(), Assert.Single(nav.Opened).Root);
    }

    [Fact]
    public void Refresh_PicksUpNewlyInsertedDrives()
    {
        var locations = new FakeLocations();
        var vm = new WelcomeViewModel(new FakeNav(), locations, new FakeFiles());
        Assert.False(vm.HasLocations);

        locations.Found.Add(Loc("G:\\"));
        vm.RefreshCommand.Execute(null);

        Assert.True(vm.HasLocations);
        Assert.Single(vm.Locations);
    }
}

public class CreateVaultViewModelTests : IDisposable
{
    private readonly ServiceKit _kit = new();
    private readonly FakeNav _nav = new();

    public void Dispose() => _kit.Dispose();

    private CreateVaultViewModel NewVm() => new(_kit.Service, _kit.Location, _nav);

    private CreateVaultViewModel ReadyVm(string password = Pw.P1)
    {
        CreateVaultViewModel vm = NewVm();
        vm.Password = password;
        vm.Confirmation = password;
        vm.Understood = true;
        return vm;
    }

    [Fact]
    public void StartsEmpty_AndCannotCreate()
    {
        CreateVaultViewModel vm = NewVm();
        Assert.False(vm.CanCreate);
        Assert.False(vm.CreateCommand.CanExecute(null));
        Assert.Equal(-1, vm.StrengthLevel);
        Assert.Equal("", vm.StrengthText);
        Assert.Equal(0, vm.StrengthFraction);
        Assert.Empty(vm.PolicyMessages);
        Assert.False(vm.ShowPassword);
    }

    [Fact]
    public void StrengthMeter_FollowsTheTypedPassword()
    {
        CreateVaultViewModel vm = NewVm();

        vm.Password = "abc";
        Assert.InRange(vm.StrengthLevel, 0, 1);
        Assert.NotEmpty(vm.PolicyMessages);
        Assert.NotEqual("", vm.StrengthText);

        vm.Password = Pw.P1;
        Assert.InRange(vm.StrengthLevel, 3, 4);
        Assert.True(vm.StrengthFraction >= 0.8);
        Assert.Empty(vm.PolicyMessages);

        vm.Password = "";
        Assert.Equal(-1, vm.StrengthLevel);
    }

    [Fact]
    public void WeakPassword_CannotBeUsed_EvenWhenConfirmedAndAcknowledged()
    {
        CreateVaultViewModel vm = ReadyVm("Password123!");
        Assert.False(vm.CanCreate);
        Assert.False(vm.CreateCommand.CanExecute(null));
        Assert.NotEmpty(vm.PolicyMessages);
    }

    [Fact]
    public void TheUserMustAcknowledgeThatThereIsNoRecovery()
    {
        CreateVaultViewModel vm = ReadyVm();
        Assert.True(vm.CanCreate);

        vm.Understood = false;
        Assert.False(vm.CanCreate);
        Assert.False(vm.CreateCommand.CanExecute(null));
        Assert.Contains("cannot be recovered", CreateVaultViewModel.WarningText);
        Assert.Contains("no backdoor", CreateVaultViewModel.WarningText);
    }

    [Fact]
    public void MismatchedConfirmation_IsExplained_AndBlocksCreation()
    {
        CreateVaultViewModel vm = ReadyVm();
        vm.Confirmation = Pw.P2;

        Assert.Equal("The passwords do not match.", vm.MismatchText);
        Assert.False(vm.CanCreate);

        vm.Confirmation = Pw.P1;
        Assert.Equal("", vm.MismatchText);
        Assert.True(vm.CanCreate);
    }

    [Fact]
    public async Task CreatingTheVault_UnlocksItAndOpensTheDashboard()
    {
        CreateVaultViewModel vm = ReadyVm();

        await vm.CreateCommand.ExecuteAsync();

        Assert.Equal(1, _nav.DashboardCount);
        Assert.True(_kit.Service.IsUnlocked);
        Assert.True(File.Exists(_kit.Paths.HeaderPath));
        Assert.Equal("", vm.Password);          // the password does not linger in the view-model
        Assert.Equal("", vm.Confirmation);
        Assert.False(vm.IsBusy);
        Assert.Equal("", vm.ErrorMessage);
    }

    [Fact]
    public async Task WhenTheDriveCannotBeWritten_ShowsASafeMessage_AndStaysOnTheScreen()
    {
        File.WriteAllText(Path.Combine(_kit.T.Root, VaultPaths.DataFolderName), "a file where the vault folder should be");
        CreateVaultViewModel vm = ReadyVm();

        await vm.CreateCommand.ExecuteAsync();

        Assert.Equal(0, _nav.DashboardCount);
        Assert.False(vm.IsBusy);
        Assert.Contains("USB drive", vm.ErrorMessage);
        Assert.DoesNotContain(_kit.T.Root, vm.ErrorMessage);
        Assert.False(_kit.Service.IsUnlocked);
    }

    [Fact]
    public async Task EditingThePassword_ClearsAnOldErrorMessage()
    {
        File.WriteAllText(Path.Combine(_kit.T.Root, VaultPaths.DataFolderName), "blocks the vault folder");
        CreateVaultViewModel vm = ReadyVm();
        await vm.CreateCommand.ExecuteAsync();
        Assert.NotEqual("", vm.ErrorMessage);

        vm.Password = Pw.P3;

        Assert.Equal("", vm.ErrorMessage);
    }

    [Fact]
    public void ShowPassword_CanBeToggled()
    {
        CreateVaultViewModel vm = NewVm();
        vm.ToggleShowPasswordCommand.Execute(null);
        Assert.True(vm.ShowPassword);
        vm.ToggleShowPasswordCommand.Execute(null);
        Assert.False(vm.ShowPassword);
    }

    [Fact]
    public void Back_GoesToTheDriveChooser()
    {
        NewVm().BackCommand.Execute(null);
        Assert.Equal(1, _nav.WelcomeCount);
    }

    [Fact]
    public void LeavingThePage_ClearsThePasswords()
    {
        CreateVaultViewModel vm = ReadyVm();
        vm.Dispose();
        Assert.Equal("", vm.Password);
        Assert.Equal("", vm.Confirmation);
    }

    [Fact]
    public void ShowsWhichDriveIsBeingSetUp()
    {
        Assert.Contains("Test USB", NewVm().LocationText);
    }
}

public class UnlockViewModelTests : IDisposable
{
    private readonly ServiceKit _kit = new();
    private readonly FakeNav _nav = new();
    private readonly ManualScheduler _ui = new();
    private readonly FakeDialogs _dialogs = new();

    public UnlockViewModelTests() => _kit.Locked();

    public void Dispose() => _kit.Dispose();

    private UnlockViewModel NewVm() => new(_kit.Service, _kit.Location, _nav, _ui, _dialogs);

    private async Task Fail(UnlockViewModel vm, int times)
    {
        for (int i = 0; i < times; i++)
        {
            vm.Password = Pw.Wrong;
            await vm.UnlockCommand.ExecuteAsync();
            _kit.T.Time.Advance(TimeSpan.FromHours(1));   // wait out any delay so the next attempt is evaluated
        }
    }

    [Fact]
    public async Task TheCorrectPassword_OpensTheDashboard_AndIsForgotten()
    {
        UnlockViewModel vm = NewVm();
        vm.Password = Pw.P1;

        await vm.UnlockCommand.ExecuteAsync();

        Assert.Equal(1, _nav.DashboardCount);
        Assert.True(_kit.Service.IsUnlocked);
        Assert.Equal("", vm.Password);
        Assert.False(vm.IsBusy);
    }

    [Fact]
    public void WithoutAPassword_UnlockIsDisabled()
    {
        UnlockViewModel vm = NewVm();
        Assert.False(vm.CanUnlock);
        Assert.False(vm.UnlockCommand.CanExecute(null));

        vm.Password = "x";
        Assert.True(vm.CanUnlock);
        Assert.True(vm.UnlockCommand.CanExecute(null));
    }

    [Fact]
    public async Task AWrongPassword_IsRejected_WithoutRevealingAnythingElse()
    {
        UnlockViewModel vm = NewVm();
        vm.Password = Pw.Wrong;

        await vm.UnlockCommand.ExecuteAsync();

        Assert.Equal(0, _nav.DashboardCount);
        Assert.False(_kit.Service.IsUnlocked);
        Assert.Contains("Wrong password", vm.Message);
        Assert.Equal(BannerKind.Error, vm.MessageKind);
        Assert.True(vm.HasMessage);
        Assert.Equal(1, vm.FailedAttempts);
        Assert.Contains("1", vm.AttemptsText);
        Assert.DoesNotContain(Pw.Wrong, vm.Message);
        Assert.False(vm.BackupHeaderAvailable);
        Assert.False(vm.IndexDamaged);
    }

    [Fact]
    public async Task RepeatedFailures_StartACooldown_ThatCountsDownAndEnds()
    {
        UnlockViewModel vm = NewVm();
        vm.Password = Pw.Wrong;
        for (int i = 0; i < 3; i++) await vm.UnlockCommand.ExecuteAsync();

        Assert.True(vm.IsCoolingDown);
        Assert.Contains("5 seconds", vm.CooldownText);
        Assert.False(vm.CanUnlock);
        Assert.False(vm.UnlockCommand.CanExecute(null));
        Assert.Equal(3, vm.FailedAttempts);

        _kit.T.Time.Advance(TimeSpan.FromSeconds(2));
        _ui.Tick();   // the one-second UI timer
        Assert.True(vm.IsCoolingDown);
        Assert.Contains("3 seconds", vm.CooldownText);

        _kit.T.Time.Advance(TimeSpan.FromSeconds(3));
        _ui.Tick();
        Assert.False(vm.IsCoolingDown);
        Assert.Equal("", vm.CooldownText);

        vm.Password = Pw.P1;
        await vm.UnlockCommand.ExecuteAsync();
        Assert.Equal(1, _nav.DashboardCount);
    }

    [Fact]
    public async Task DuringACooldown_EvenTheCorrectPasswordIsNotTried()
    {
        UnlockViewModel vm = NewVm();
        vm.Password = Pw.Wrong;
        for (int i = 0; i < 3; i++) await vm.UnlockCommand.ExecuteAsync();

        vm.Password = Pw.P1;
        await vm.UnlockCommand.ExecuteAsync();   // disabled: does nothing

        Assert.Equal(0, _nav.DashboardCount);
        Assert.False(_kit.Service.IsUnlocked);
    }

    [Fact]
    public async Task ACooldownIsShownImmediately_WhenTheApplicationIsReopened()
    {
        UnlockViewModel first = NewVm();
        first.Password = Pw.Wrong;
        for (int i = 0; i < 3; i++) await first.UnlockCommand.ExecuteAsync();
        first.Dispose();

        UnlockViewModel reopened = NewVm();   // "closed and reopened SecureUSB"

        Assert.True(reopened.IsCoolingDown);
        Assert.Equal(3, reopened.FailedAttempts);
    }

    [Fact]
    public async Task ARefusalDuringTheCooldown_IsShownAsAWarning()
    {
        UnlockViewModel vm = NewVm();   // created while still allowed to try
        for (int i = 0; i < 3; i++) _kit.Service.Unlock(Pw.Wrong);

        vm.Password = Pw.P1;
        await vm.UnlockCommand.ExecuteAsync();

        Assert.Equal(BannerKind.Warning, vm.MessageKind);
        Assert.Contains("Too many failed attempts", vm.Message);
        Assert.Equal(0, _nav.DashboardCount);
    }

    [Fact]
    public async Task BitRotInTheHeader_OffersTheBackupHeader()
    {
        Data.FlipByte(_kit.Paths.HeaderPath, VaultHeader.WrappedKeyOffset + 5);
        UnlockViewModel vm = NewVm();
        Assert.False(vm.UnlockWithBackupCommand.CanExecute(null));

        vm.Password = Pw.P1;
        await vm.UnlockCommand.ExecuteAsync();
        Assert.True(vm.BackupHeaderAvailable);
        Assert.True(vm.UnlockWithBackupCommand.CanExecute(null));

        await vm.UnlockWithBackupCommand.ExecuteAsync();

        Assert.Equal(1, _nav.DashboardCount);
        Assert.True(_kit.Service.IsUnlocked);
    }

    [Fact]
    public async Task ADamagedIndex_IsExplained_AndRebuildNeedsConfirmation()
    {
        // a file must exist, otherwise a missing index just means "new empty vault"
        Assert.True(_kit.Service.Unlock(Pw.P1).Succeeded);
        _kit.Service.AddFile(_kit.Source("a.bin"));
        _kit.Service.Lock();
        foreach (string p in new[] { _kit.Paths.IndexPath, _kit.Paths.IndexPrevPath, _kit.Paths.IndexTempPath })
            if (File.Exists(p)) File.Delete(p);

        UnlockViewModel vm = NewVm();
        vm.Password = Pw.P1;
        await vm.UnlockCommand.ExecuteAsync();

        Assert.True(vm.IndexDamaged);
        Assert.Contains("file index is damaged", vm.Message);
        Assert.Equal(0, vm.FailedAttempts);   // the password was right: no penalty
        Assert.True(vm.RebuildIndexCommand.CanExecute(null));

        _dialogs.ConfirmAnswers.Enqueue(false);
        await vm.RebuildIndexCommand.ExecuteAsync();
        Assert.Single(_dialogs.Confirms);
        Assert.Equal(0, _nav.DashboardCount);

        _dialogs.ConfirmAnswers.Enqueue(true);
        await vm.RebuildIndexCommand.ExecuteAsync();
        Assert.Equal(2, _dialogs.Confirms.Count);
        Assert.Equal(1, _nav.DashboardCount);
        Assert.True(_kit.Service.IsUnlocked);
        Assert.Single(_kit.Service.ListFiles());
    }

    [Fact]
    public async Task UnavailableDrive_IsReportedAsSuch_NotAsAWrongPassword()
    {
        UnlockViewModel vm = NewVm();
        _kit.T.Drive.Available = false;
        vm.Password = Pw.P1;

        await vm.UnlockCommand.ExecuteAsync();

        Assert.Contains("not available", vm.Message);
        Assert.Equal(0, vm.FailedAttempts);
        Assert.Equal(0, _nav.DashboardCount);
    }

    [Fact]
    public async Task AVaultOpenInAnotherWindow_IsExplained()
    {
        VaultService other = _kit.NewService();
        Assert.True(other.Unlock(Pw.P1).Succeeded);

        UnlockViewModel vm = NewVm();
        vm.Password = Pw.P1;
        await vm.UnlockCommand.ExecuteAsync();

        Assert.Equal(BannerKind.Warning, vm.MessageKind);
        Assert.Contains("already open", vm.Message);
        Assert.Equal(0, vm.FailedAttempts);
    }

    [Fact]
    public void ChangeLocation_GoesBackToTheDriveChooser()
    {
        NewVm().ChangeLocationCommand.Execute(null);
        Assert.Equal(1, _nav.WelcomeCount);
    }

    [Fact]
    public void TheCooldownTimer_IsStoppedWhenThePageIsLeft()
    {
        UnlockViewModel vm = NewVm();
        Assert.Equal(1, _ui.ActiveTimers);

        vm.Password = "something";
        vm.Dispose();

        Assert.Equal(0, _ui.ActiveTimers);
        Assert.Equal("", vm.Password);
    }

    [Fact]
    public void ShowPassword_CanBeToggled()
    {
        UnlockViewModel vm = NewVm();
        Assert.False(vm.ShowPassword);
        vm.ToggleShowPasswordCommand.Execute(null);
        Assert.True(vm.ShowPassword);
    }
}
