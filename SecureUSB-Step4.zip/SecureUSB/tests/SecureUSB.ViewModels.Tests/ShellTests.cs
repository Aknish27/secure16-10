using SecureUSB.Core;
using SecureUSB.Models;
using SecureUSB.Storage;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.ViewModels.Tests;

internal sealed class ShellKit : IDisposable
{
    public TempVault T { get; } = new();
    public string TempRoot { get; }
    public FakeLocations Locations { get; } = new();
    public FakeFactory Factory { get; }
    public ModalHost Modals { get; } = new();
    public FakeFiles Files { get; } = new();
    public FakeLauncher Launcher { get; } = new();
    public ManualScheduler Ui { get; } = new();
    public FakeTheme Theme { get; } = new();
    public AppInfo App { get; } = new("SecureUSB", "1.0.0-test");
    public ShellViewModel Shell { get; }

    public ShellKit()
    {
        TempRoot = T.Sub("hostTemp");
        Factory = new FakeFactory(T, TempRoot);
        Shell = new ShellViewModel(new ShellServices
        {
            Factory = Factory, Locations = Locations, Modals = Modals, Files = Files, Launcher = Launcher,
            Ui = Ui, Theme = Theme, App = App, Time = T.Time
        });
    }

    public VaultLocation AppDrive(bool hasVault) => new(T.Root, "SecureUSB (E:)", "TESTUSB \u00B7 exFAT", hasVault, true, true);

    /// <summary>Puts a vault (password P1) on the scratch drive, then closes it.</summary>
    public void PrepareVaultOnDisk()
    {
        using VaultService s = FakeFactory.Make(T, TempRoot, VaultPaths.ForUsbRoot(T.Root));
        s.CreateVault(Pw.P1, Pw.P1);
    }

    public async Task<DashboardViewModel> CreateVaultThroughTheUiAsync()
    {
        Shell.OpenLocation(AppDrive(false));
        var create = Assert.IsType<CreateVaultViewModel>(Shell.CurrentPage);
        create.Password = Pw.P1;
        create.Confirmation = Pw.P1;
        create.Understood = true;
        await create.CreateCommand.ExecuteAsync();
        var dashboard = Assert.IsType<DashboardViewModel>(Shell.CurrentPage);
        await dashboard.InitializeAsync();
        return dashboard;
    }

    public void Dispose()
    {
        Shell.Dispose();
        foreach (VaultService s in Factory.Created) s.Dispose();
        T.Dispose();
    }
}

public class ShellViewModelTests : IDisposable
{
    private readonly ShellKit _k = new();

    public void Dispose() => _k.Dispose();

    private ShellViewModel Shell => _k.Shell;

    // ------------------------------------------------------------------ start-up

    [Fact]
    public void WhenTheAppsOwnDriveHoldsAVault_StartsOnTheUnlockScreen()
    {
        _k.PrepareVaultOnDisk();
        _k.Locations.Found.Add(_k.AppDrive(true));

        Shell.Initialize();

        Assert.IsType<UnlockViewModel>(Shell.CurrentPage);
        Assert.False(Shell.Banner.IsVisible);
        Assert.Contains("Locked", Shell.WindowTitle);
        Assert.False(Shell.IsVaultUnlocked);
    }

    [Fact]
    public void WithoutAVaultAnywhere_StartsOnTheWelcomeScreen()
    {
        _k.Locations.Found.Add(_k.AppDrive(false));
        Shell.Initialize();

        var welcome = Assert.IsType<WelcomeViewModel>(Shell.CurrentPage);
        Assert.Single(welcome.Locations);
        Assert.Equal("SecureUSB", Shell.WindowTitle);
    }

    [Fact]
    public void WithNoDrivesAtAll_StillShowsTheWelcomeScreen()
    {
        Shell.Initialize();
        Assert.IsType<WelcomeViewModel>(Shell.CurrentPage);

        var other = new ShellKit();
        other.Locations.ThrowOnDiscover = true;
        other.Shell.Initialize();
        Assert.IsType<WelcomeViewModel>(other.Shell.CurrentPage);
        other.Dispose();
    }

    [Fact]
    public void AVaultOnAnotherRemovableDrive_IsNotOpenedWithoutTheUsersChoice()
    {
        _k.PrepareVaultOnDisk();
        _k.Locations.Found.Add(new VaultLocation(_k.T.Root, "Other stick", "x", true, true, IsAppDrive: false));

        Shell.Initialize();

        Assert.IsType<WelcomeViewModel>(Shell.CurrentPage);
    }

    [Fact]
    public void ChoosingADriveWithoutAVault_OffersToCreateOne_WithAVault_ToUnlock()
    {
        Shell.OpenLocation(_k.AppDrive(false));
        Assert.IsType<CreateVaultViewModel>(Shell.CurrentPage);

        _k.PrepareVaultOnDisk();
        // a fresh location pointing at the now-existing vault
        Shell.OpenLocation(_k.AppDrive(true));
        Assert.IsType<UnlockViewModel>(Shell.CurrentPage);
    }

    [Fact]
    public void TheIdleTimer_IsStartedWithTheShell_AndStoppedWithIt()
    {
        Shell.Initialize();
        Assert.Equal(1, _k.Ui.ActiveTimers);
        Shell.Dispose();
        Assert.Equal(0, _k.Ui.ActiveTimers);
    }

    // ------------------------------------------------------------------ the one-password flow

    [Fact]
    public async Task CreatingAVault_LeadsToTheUnlockedDashboard()
    {
        DashboardViewModel dashboard = await _k.CreateVaultThroughTheUiAsync();

        Assert.True(Shell.IsVaultUnlocked);
        Assert.Contains("Unlocked", Shell.WindowTitle);
        Assert.True(Shell.Service!.IsUnlocked);
        Assert.Empty(dashboard.Items);
        Assert.Equal(HealthLevel.Healthy, dashboard.Health.Level);
    }

    [Fact]
    public async Task UnlockingWithThePassword_LeadsToTheDashboard_WithTheFiles()
    {
        DashboardViewModel first = await _k.CreateVaultThroughTheUiAsync();
        string src = Path.Combine(_k.T.Sub("src"), "report.pdf");
        File.WriteAllBytes(src, Data.Bytes(300));
        Shell.Service!.AddFile(src);
        await first.LockCommand.ExecuteAsync();
        var unlock = Assert.IsType<UnlockViewModel>(Shell.CurrentPage);

        unlock.Password = Pw.P1;
        await unlock.UnlockCommand.ExecuteAsync();

        var dashboard = Assert.IsType<DashboardViewModel>(Shell.CurrentPage);
        await dashboard.InitializeAsync();
        Assert.Equal(new[] { "report.pdf" }, dashboard.Items.Select(i => i.Name).ToArray());
    }

    // ------------------------------------------------------------------ locking

    [Fact]
    public async Task TheLockButton_ReturnsToTheUnlockScreen_AndClearsTheDashboard()
    {
        DashboardViewModel dashboard = await _k.CreateVaultThroughTheUiAsync();
        string src = Path.Combine(_k.T.Sub("src"), "a.txt");
        File.WriteAllBytes(src, Data.Bytes(50));
        Shell.Service!.AddFile(src);
        await dashboard.RefreshAsync();
        Assert.Single(dashboard.Items);

        await dashboard.LockCommand.ExecuteAsync();

        Assert.IsType<UnlockViewModel>(Shell.CurrentPage);
        Assert.Equal(VaultState.Locked, Shell.Service.State);
        Assert.Empty(dashboard.Items);                 // nothing of the vault stays in the old screen
        Assert.Equal(PreviewKind.None, dashboard.PreviewKind);
        Assert.True(Shell.Banner.IsVisible);
        Assert.Equal(BannerKind.Info, Shell.Banner.Kind);
        Assert.Contains("locked", Shell.Banner.Message);
        Assert.Contains("Locked", Shell.WindowTitle);
    }

    [Fact]
    public async Task RemovingTheUsb_ImmediatelyShowsTheLockedState_WithAWarning()
    {
        DashboardViewModel dashboard = await _k.CreateVaultThroughTheUiAsync();
        string src = Path.Combine(_k.T.Sub("src"), "a.txt");
        File.WriteAllBytes(src, Data.Bytes(50));
        Shell.Service!.AddFile(src);
        await dashboard.RefreshAsync();
        var pageChanges = new List<string?>();
        Shell.PropertyChanged += (_, e) => pageChanges.Add(e.PropertyName);

        _k.T.Drive.Available = false;     // the stick is pulled out
        bool stillThere = Shell.Service!.CheckUsbNow();

        Assert.False(stillThere);
        Assert.IsType<UnlockViewModel>(Shell.CurrentPage);
        Assert.Contains("CurrentPage", pageChanges);
        Assert.Equal(VaultState.Locked, Shell.Service.State);
        Assert.Empty(dashboard.Items);
        Assert.True(Shell.Banner.IsVisible);
        Assert.Equal(BannerKind.Warning, Shell.Banner.Kind);
        Assert.Contains("removed", Shell.Banner.Message);
        Assert.Throws<VaultLockedException>(() => Shell.Service.ListFiles());
    }

    [Fact]
    public async Task RemovingTheUsb_ClosesDialogsThatShowVaultData()
    {
        await _k.CreateVaultThroughTheUiAsync();
        var settings = new SettingsViewModel(Shell.Settings, Shell.Service!, Shell.Modals, _k.App);
        Task shown = Shell.Modals.ShowModalAsync(settings);
        Assert.True(Shell.Modals.IsOpen);

        _k.T.Drive.Available = false;
        Shell.Service!.CheckUsbNow();
        await shown;

        Assert.False(Shell.Modals.IsOpen);
        Assert.IsType<UnlockViewModel>(Shell.CurrentPage);
    }

    [Fact]
    public async Task AfterReconnectingTheUsb_TheUserCanUnlockAgain()
    {
        await _k.CreateVaultThroughTheUiAsync();
        _k.T.Drive.Available = false;
        Shell.Service!.CheckUsbNow();
        _k.T.Drive.Available = true;

        var unlock = Assert.IsType<UnlockViewModel>(Shell.CurrentPage);
        unlock.Password = Pw.P1;
        await unlock.UnlockCommand.ExecuteAsync();

        Assert.IsType<DashboardViewModel>(Shell.CurrentPage);
    }

    // ------------------------------------------------------------------ auto-lock

    [Fact]
    public async Task AfterTheIdleTime_TheVaultLocksItself()
    {
        await _k.CreateVaultThroughTheUiAsync();
        Shell.Settings.AutoLockMinutes = 1;
        Shell.NotifyActivity();

        _k.T.Time.Advance(TimeSpan.FromSeconds(59));
        await Shell.CheckIdleAsync();
        Assert.IsType<DashboardViewModel>(Shell.CurrentPage);

        _k.T.Time.Advance(TimeSpan.FromSeconds(2));
        await Shell.CheckIdleAsync();

        Assert.IsType<UnlockViewModel>(Shell.CurrentPage);
        Assert.Contains("inactivity", Shell.Banner.Message);
    }

    [Fact]
    public async Task Activity_RestartsTheIdleCountdown()
    {
        await _k.CreateVaultThroughTheUiAsync();
        Shell.Settings.AutoLockMinutes = 1;
        Shell.NotifyActivity();

        _k.T.Time.Advance(TimeSpan.FromSeconds(50));
        Shell.NotifyActivity();
        _k.T.Time.Advance(TimeSpan.FromSeconds(50));
        await Shell.CheckIdleAsync();

        Assert.IsType<DashboardViewModel>(Shell.CurrentPage);
    }

    [Fact]
    public async Task AutoLockCanBeSwitchedOff()
    {
        await _k.CreateVaultThroughTheUiAsync();
        Shell.Settings.AutoLockMinutes = 0;

        _k.T.Time.Advance(TimeSpan.FromHours(5));
        await Shell.CheckIdleAsync();

        Assert.IsType<DashboardViewModel>(Shell.CurrentPage);
    }

    [Fact]
    public async Task AutoLock_DoesNothingWhenNoVaultIsOpen()
    {
        Shell.Initialize();
        _k.T.Time.Advance(TimeSpan.FromHours(5));
        await Shell.CheckIdleAsync();
        Assert.IsType<WelcomeViewModel>(Shell.CurrentPage);
    }

    // ------------------------------------------------------------------ misc

    [Fact]
    public void ChangingTheTheme_IsAppliedToTheWindow()
    {
        Shell.Settings.Theme = ThemeKind.Dark;
        Shell.Settings.Theme = ThemeKind.Light;
        Assert.Equal(new[] { ThemeKind.Dark, ThemeKind.Light }, _k.Theme.Applied);
    }

    [Fact]
    public void BrowsingForAFolder_OpensItAsAVaultLocation()
    {
        Shell.Initialize();
        var welcome = Assert.IsType<WelcomeViewModel>(Shell.CurrentPage);
        _k.Files.FolderToPick = _k.T.Sub("chosen");

        welcome.BrowseCommand.Execute(null);

        Assert.IsType<CreateVaultViewModel>(Shell.CurrentPage);
    }

    [Fact]
    public async Task SwitchingDrives_ClosesTheVaultThatWasOpen()
    {
        await _k.CreateVaultThroughTheUiAsync();
        VaultService previous = Shell.Service!;

        Shell.ShowWelcome();

        Assert.IsType<WelcomeViewModel>(Shell.CurrentPage);
        Assert.Null(Shell.Service);
        Assert.Throws<ObjectDisposedException>(() => previous.ListFiles());
    }

    [Fact]
    public void IfTheVaultServiceCannotBeCreated_ShowsASafeError_AndStaysOnTheChooser()
    {
        _k.Factory.ThrowOnCreate = new IOException(@"Could not open C:\Users\bob\secret path");

        Shell.OpenLocation(_k.AppDrive(true));

        Assert.IsType<WelcomeViewModel>(Shell.CurrentPage);
        Assert.True(Shell.Banner.IsVisible);
        Assert.Equal(BannerKind.Error, Shell.Banner.Kind);
        Assert.DoesNotContain("bob", Shell.Banner.Message);
    }

    [Fact]
    public async Task ClosingTheApplication_LocksTheVaultAndWipesTemporaryFiles()
    {
        DashboardViewModel dashboard = await _k.CreateVaultThroughTheUiAsync();
        string src = Path.Combine(_k.T.Sub("src"), "a.txt");
        File.WriteAllBytes(src, Data.Bytes(50));
        FileEntry entry = Shell.Service!.AddFile(src);
        string temp = Shell.Service.OpenTemporaryCopy(entry.Id);
        VaultService service = Shell.Service;

        Shell.Dispose();

        Assert.False(File.Exists(temp));
        Assert.Throws<ObjectDisposedException>(() => service.ListFiles());
        Assert.Empty(dashboard.Items);
        Assert.Null(Shell.CurrentPage);
    }

    [Fact]
    public void TheBanner_CanBeDismissed()
    {
        Shell.OpenLocation(_k.AppDrive(false));
        _k.Factory.ThrowOnCreate = new IOException("x");
        Shell.OpenLocation(_k.AppDrive(false));
        Assert.True(Shell.Banner.IsVisible);

        Shell.Banner.DismissCommand.Execute(null);

        Assert.False(Shell.Banner.IsVisible);
    }
}
