using SecureUSB.ViewModels.Mvvm;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.ViewModels.Tests;

internal static class Wait
{
    /// <summary>The next queued dialog is shown asynchronously after the previous one closes.</summary>
    public static async Task Until(Func<bool> condition, int milliseconds = 5000)
    {
        DateTime end = DateTime.UtcNow.AddMilliseconds(milliseconds);
        while (!condition())
        {
            if (DateTime.UtcNow > end) throw new TimeoutException("The condition was not met in time.");
            await Task.Delay(10);
        }
    }
}

public class MvvmTests
{
    private sealed class Sample : ObservableObject
    {
        private int _value;
        public int Value { get => _value; set => SetProperty(ref _value, value); }
    }

    [Fact]
    public void PropertyChanged_FiresOnlyWhenTheValueChanges()
    {
        var s = new Sample();
        var names = new List<string?>();
        s.PropertyChanged += (_, e) => names.Add(e.PropertyName);

        s.Value = 5;
        s.Value = 5;
        s.Value = 6;

        Assert.Equal(new[] { "Value", "Value" }, names);
    }

    [Fact]
    public void RelayCommand_RespectsCanExecute_AndRaisesChanged()
    {
        int runs = 0;
        bool allowed = false;
        var cmd = new RelayCommand(() => runs++, () => allowed);
        int raised = 0;
        cmd.CanExecuteChanged += (_, _) => raised++;

        cmd.Execute(null);
        Assert.Equal(0, runs);
        Assert.False(cmd.CanExecute(null));

        allowed = true;
        cmd.RaiseCanExecuteChanged();
        cmd.Execute(null);
        Assert.Equal(1, runs);
        Assert.Equal(1, raised);
    }

    [Fact]
    public void GenericRelayCommand_PassesTheParameter_AndIgnoresWrongTypes()
    {
        string? seen = null;
        var cmd = new RelayCommand<string>(s => seen = s);

        cmd.Execute("hello");
        Assert.Equal("hello", seen);

        cmd.Execute(42);   // wrong type -> default (null), no exception
        Assert.Null(seen);
    }

    [Fact]
    public async Task AsyncCommand_DisablesItselfWhileRunning_AndPreventsReentrancy()
    {
        var gate = new TaskCompletionSource();
        int runs = 0;
        var cmd = new AsyncRelayCommand(async () => { runs++; await gate.Task; });
        var states = new List<bool>();
        cmd.CanExecuteChanged += (_, _) => states.Add(cmd.CanExecute(null));

        Task first = cmd.ExecuteAsync();
        Assert.True(cmd.IsRunning);
        Assert.False(cmd.CanExecute(null));
        await cmd.ExecuteAsync();   // ignored: already running
        Assert.Equal(1, runs);

        gate.SetResult();
        await first;

        Assert.False(cmd.IsRunning);
        Assert.True(cmd.CanExecute(null));
        Assert.Equal(new[] { false, true }, states);
    }

    [Fact]
    public async Task AsyncCommand_SendsExceptionsToTheHandler_AndRecovers()
    {
        Exception? seen = null;
        var cmd = new AsyncRelayCommand(() => throw new InvalidOperationException("boom"))
        {
            ErrorHandler = ex => { seen = ex; return Task.CompletedTask; }
        };

        await cmd.ExecuteAsync();

        Assert.IsType<InvalidOperationException>(seen);
        Assert.True(cmd.CanExecute(null));
    }

    [Fact]
    public async Task AsyncCommand_WithoutHandler_RethrowsToTheCaller()
    {
        var cmd = new AsyncRelayCommand(() => throw new InvalidOperationException("boom"));
        await Assert.ThrowsAsync<InvalidOperationException>(() => cmd.ExecuteAsync());
        Assert.True(cmd.CanExecute(null));
    }

    [Fact]
    public async Task AsyncCommand_HonoursCanExecute()
    {
        int runs = 0;
        var cmd = new AsyncRelayCommand(() => { runs++; return Task.CompletedTask; }, () => false);
        await cmd.ExecuteAsync();
        Assert.Equal(0, runs);
    }
}

public class ModalHostTests
{
    private sealed class TestModal : ModalViewModel
    {
        public TestModal(string title, bool closesOnLock = true)
        {
            Title = title;
            ClosesOnLock = closesOnLock;
        }

        public override string Title { get; }
        public override bool ClosesOnLock { get; }
        public bool ClosedCalled { get; private set; }
        public override void OnClosed() => ClosedCalled = true;
    }

    [Fact]
    public async Task ShowModal_SetsCurrent_UntilItIsClosed()
    {
        var host = new ModalHost();
        var modal = new TestModal("A");
        var changes = new List<string?>();
        host.PropertyChanged += (_, e) => changes.Add(e.PropertyName);

        Task shown = host.ShowModalAsync(modal);
        Assert.Same(modal, host.Current);
        Assert.True(host.IsOpen);
        Assert.False(shown.IsCompleted);

        modal.RequestClose();
        await shown;

        Assert.Null(host.Current);
        Assert.False(host.IsOpen);
        Assert.True(modal.ClosedCalled);
        Assert.Contains("IsOpen", changes);
    }

    [Fact]
    public async Task SecondModal_WaitsForTheFirst()
    {
        var host = new ModalHost();
        var first = new TestModal("first");
        var second = new TestModal("second");

        Task t1 = host.ShowModalAsync(first);
        Task t2 = host.ShowModalAsync(second);
        Assert.Same(first, host.Current);

        first.RequestClose();
        await t1;
        await Wait.Until(() => ReferenceEquals(host.Current, second));

        second.RequestClose();
        await t2;
        Assert.Null(host.Current);
    }

    [Fact]
    public async Task CloseVaultModals_ClosesTheCurrentOne_AndCancelsWaitingVaultModals()
    {
        var host = new ModalHost();
        var current = new TestModal("shows vault data");
        var waitingVault = new TestModal("also vault data");
        var waitingNeutral = new TestModal("neutral", closesOnLock: false);

        Task t1 = host.ShowModalAsync(current);
        Task t2 = host.ShowModalAsync(waitingVault);
        Task t3 = host.ShowModalAsync(waitingNeutral);

        host.CloseVaultModals();
        await t1;
        await t2;   // cancelled: completes without ever being shown

        Assert.True(waitingVault.IsCancelled);
        Assert.True(waitingVault.ClosedCalled);
        await Wait.Until(() => ReferenceEquals(host.Current, waitingNeutral));

        waitingNeutral.RequestClose();
        await t3;
    }

    [Fact]
    public async Task CloseVaultModals_LeavesNeutralDialogsOpen()
    {
        var host = new ModalHost();
        var neutral = new TestModal("neutral", closesOnLock: false);
        Task shown = host.ShowModalAsync(neutral);

        host.CloseVaultModals();

        Assert.Same(neutral, host.Current);
        neutral.RequestClose();
        await shown;
    }

    [Fact]
    public async Task Confirm_ReturnsTheUsersChoice()
    {
        var host = new ModalHost();

        Task<bool> yes = host.ConfirmAsync(new ConfirmRequest("t", "m"));
        ((ConfirmViewModel)host.Current!).ConfirmCommand.Execute(null);
        Assert.True(await yes);

        Task<bool> no = host.ConfirmAsync(new ConfirmRequest("t", "m", IsDestructive: true));
        var vm = (ConfirmViewModel)host.Current!;
        Assert.True(vm.IsDestructive);
        vm.CancelCommand.Execute(null);
        Assert.False(await no);
    }

    [Fact]
    public async Task ClosingAConfirmWithEscape_MeansNo()
    {
        var host = new ModalHost();
        Task<bool> answer = host.ConfirmAsync(new ConfirmRequest("t", "m"));

        host.CloseCurrentCommand.Execute(null);   // the Escape key

        Assert.False(await answer);
    }

    [Fact]
    public async Task Prompt_ReturnsTheText_OrNullWhenCancelled()
    {
        var host = new ModalHost();

        Task<string?> ok = host.PromptAsync(new PromptRequest("Rename", "New name", "old.txt", "Rename"));
        var vm = (PromptViewModel)host.Current!;
        Assert.Equal("old.txt", vm.Text);
        vm.Text = "new.txt";
        vm.ConfirmCommand.Execute(null);
        Assert.Equal("new.txt", await ok);

        Task<string?> cancelled = host.PromptAsync(new PromptRequest("Rename", "New name", "x"));
        ((PromptViewModel)host.Current!).CancelCommand.Execute(null);
        Assert.Null(await cancelled);
    }

    [Fact]
    public async Task Prompt_CannotBeConfirmedWithEmptyText()
    {
        var host = new ModalHost();
        Task<string?> t = host.PromptAsync(new PromptRequest("Rename", "New name", "x"));
        var vm = (PromptViewModel)host.Current!;

        vm.Text = "   ";
        Assert.False(vm.ConfirmCommand.CanExecute(null));
        vm.Text = "name";
        Assert.True(vm.ConfirmCommand.CanExecute(null));

        vm.CancelCommand.Execute(null);
        await t;
    }

    [Fact]
    public async Task Message_ShowsUntilAcknowledged()
    {
        var host = new ModalHost();
        Task shown = host.ShowMessageAsync("Title", "Body", MessageKind.Error);
        var vm = (MessageViewModel)host.Current!;

        Assert.Equal("Body", vm.Message);
        Assert.Equal(MessageKind.Error, vm.Kind);
        vm.CloseCommand.Execute(null);
        await shown;
        Assert.False(host.IsOpen);
    }

    [Fact]
    public void EscapeCommand_IsDisabledWithoutADialog()
    {
        Assert.False(new ModalHost().CloseCurrentCommand.CanExecute(null));
    }

    [Fact]
    public void Banner_ShowsAndHides()
    {
        var banner = new BannerViewModel();
        Assert.False(banner.IsVisible);

        banner.Show(BannerKind.Warning, "careful");
        Assert.True(banner.IsVisible);
        Assert.Equal(BannerKind.Warning, banner.Kind);
        Assert.Equal("careful", banner.Message);

        banner.DismissCommand.Execute(null);
        Assert.False(banner.IsVisible);
        Assert.Equal("", banner.Message);
    }

    [Fact]
    public void SessionSettings_HaveSafeDefaults()
    {
        var s = new SessionSettings();
        Assert.Equal(10, s.AutoLockMinutes);
        Assert.False(s.AllowOpenInOtherPrograms);   // no plaintext copies unless the user opts in
        Assert.True(s.ShowPreview);
        Assert.Equal(ThemeKind.Light, s.Theme);
        s.AutoLockMinutes = -5;
        Assert.Equal(0, s.AutoLockMinutes);
    }
}
