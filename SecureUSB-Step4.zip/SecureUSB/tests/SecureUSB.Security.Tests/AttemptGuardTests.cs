using SecureUSB.Security;

namespace SecureUSB.Security.Tests;

public class AttemptGuardTests : IDisposable
{
    // Documented file layout: magic "SUSBGRD1" (8) | failures u32 (4) | last failure i64 (8) | SHA-256 of those 20 bytes (32)
    private const int ValidRecordLength = 8 + 4 + 8 + 32;   // 52

    private readonly TempDir _dir = new();
    private readonly FixedTime _time = new();
    private string GuardPath => Path.Combine(_dir.Root, "guard.dat");

    public void Dispose() => _dir.Dispose();

    private AttemptGuard NewGuard(AttemptPolicy? policy = null) => new(GuardPath, _time, policy);

    [Fact]
    public void NewGuard_HasNoFailuresAndNoDelay()
    {
        AttemptStatus s = NewGuard().GetStatus();
        Assert.Equal(0, s.ConsecutiveFailures);
        Assert.False(s.IsLockedOut);
        Assert.False(File.Exists(GuardPath));
    }

    [Theory]
    [InlineData(1, 0)]
    [InlineData(2, 0)]
    [InlineData(3, 5)]
    [InlineData(4, 15)]
    [InlineData(5, 30)]
    [InlineData(6, 60)]
    [InlineData(7, 300)]
    [InlineData(8, 900)]
    [InlineData(9, 1800)]
    [InlineData(10, 1800)]
    [InlineData(25, 1800)]
    public void DelaysGrowProgressively_AndStopAtThirtyMinutes(int failures, int expectedSeconds)
    {
        AttemptGuard guard = NewGuard();
        AttemptStatus s = default;
        for (int i = 0; i < failures; i++) s = guard.RecordFailure();

        Assert.Equal(failures, s.ConsecutiveFailures);
        Assert.Equal(TimeSpan.FromSeconds(expectedSeconds), s.RemainingDelay);
        Assert.Equal(expectedSeconds > 0, s.IsLockedOut);
    }

    [Fact]
    public void RemainingDelay_CountsDownWithTheClock()
    {
        AttemptGuard guard = NewGuard();
        for (int i = 0; i < 3; i++) guard.RecordFailure();

        _time.Advance(TimeSpan.FromSeconds(3));
        Assert.Equal(TimeSpan.FromSeconds(2), guard.GetStatus().RemainingDelay);

        _time.Advance(TimeSpan.FromSeconds(2));
        AttemptStatus done = guard.GetStatus();
        Assert.False(done.IsLockedOut);
        Assert.Equal(3, done.ConsecutiveFailures);   // the count is only cleared by a success
    }

    [Fact]
    public void Success_ClearsCounterAndFile()
    {
        AttemptGuard guard = NewGuard();
        for (int i = 0; i < 4; i++) guard.RecordFailure();

        Assert.Equal(4, guard.RecordSuccess());
        Assert.Equal(0, guard.GetStatus().ConsecutiveFailures);
        Assert.False(File.Exists(GuardPath));
        Assert.Equal(0, guard.RecordSuccess());
    }

    [Fact]
    public void Counter_SurvivesRestart()
    {
        AttemptGuard first = NewGuard();
        for (int i = 0; i < 3; i++) first.RecordFailure();

        AttemptStatus s = NewGuard().GetStatus();   // "application restarted"
        Assert.Equal(3, s.ConsecutiveFailures);
        Assert.True(s.IsLockedOut);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(10)]
    [InlineData(51)]   // one byte short of a valid record
    [InlineData(53)]   // one byte too long
    public void DamagedFile_IsPenalisedNotForgiven(int length)
    {
        File.WriteAllBytes(GuardPath, new byte[length]);
        AttemptStatus s = NewGuard().GetStatus();

        Assert.Equal(5, s.ConsecutiveFailures);
        Assert.Equal(TimeSpan.FromSeconds(30), s.RemainingDelay);
        Assert.Equal(ValidRecordLength, new FileInfo(GuardPath).Length);   // rewritten as a valid record
    }

    [Fact]
    public void AnySingleByteChange_IsDetected()
    {
        AttemptGuard guard = NewGuard();
        for (int i = 0; i < 3; i++) guard.RecordFailure();
        byte[] good = File.ReadAllBytes(GuardPath);
        Assert.Equal(ValidRecordLength, good.Length);   // every one of these bytes is covered by the loop below

        for (int i = 0; i < good.Length; i++)
        {
            byte[] bad = (byte[])good.Clone();
            bad[i] ^= 0x01;
            File.WriteAllBytes(GuardPath, bad);
            Assert.Equal(5, NewGuard().GetStatus().ConsecutiveFailures);   // 3 failures were stored; an edit becomes 5
        }
    }

    [Fact]
    public void ClockMovedBackwards_DoesNotShortenTheDelay()
    {
        AttemptGuard guard = NewGuard();
        for (int i = 0; i < 3; i++) guard.RecordFailure();

        _time.Advance(TimeSpan.FromMinutes(-10));
        Assert.Equal(TimeSpan.FromSeconds(5), guard.GetStatus().RemainingDelay);
    }

    [Fact]
    public void KnownLimitation_DeletingTheFileResetsTheCounter()
    {
        // Documented, not a bug: the counter must be readable before any key exists, so it cannot be
        // tamper-proof. Anyone who can delete files on the USB can reset it. Argon2id + password strength
        // are what protect against that attacker.
        AttemptGuard guard = NewGuard();
        for (int i = 0; i < 6; i++) guard.RecordFailure();
        Assert.True(guard.GetStatus().IsLockedOut);

        File.Delete(GuardPath);
        Assert.False(NewGuard().GetStatus().IsLockedOut);
    }

    [Fact]
    public void CustomPolicy_IsHonoured()
    {
        var policy = new AttemptPolicy { FreeFailures = 0, Delays = new[] { TimeSpan.FromSeconds(10) } };
        AttemptGuard guard = NewGuard(policy);

        Assert.Equal(TimeSpan.FromSeconds(10), guard.RecordFailure().RemainingDelay);
        Assert.Equal(TimeSpan.FromSeconds(10), guard.RecordFailure().RemainingDelay);
    }

    [Fact]
    public void ParallelFailures_AreAllCounted()
    {
        AttemptGuard guard = NewGuard();
        Parallel.For(0, 40, new ParallelOptions { MaxDegreeOfParallelism = 8 }, _ => guard.RecordFailure());
        Assert.Equal(40, guard.GetStatus().ConsecutiveFailures);
    }

    [Fact]
    public void Policy_DelayFor_IsPure()
    {
        var p = new AttemptPolicy();
        Assert.Equal(TimeSpan.Zero, p.DelayFor(0));
        Assert.Equal(TimeSpan.Zero, p.DelayFor(2));
        Assert.Equal(TimeSpan.FromSeconds(5), p.DelayFor(3));
        Assert.Equal(TimeSpan.FromMinutes(30), p.DelayFor(1_000_000));
    }
}
