using SecureUSB.Security;

namespace SecureUSB.Security.Tests;

public class TempFileManagerTests : IDisposable
{
    private readonly TempDir _dir = new();
    private readonly List<TempFileManager> _managers = new();

    public void Dispose()
    {
        foreach (TempFileManager m in _managers) m.Dispose();
        _dir.Dispose();
    }

    private TempFileManager NewManager()
    {
        var m = new TempFileManager(_dir.Root);
        _managers.Add(m);
        return m;
    }

    private static string Make(TempFileManager m, string name, byte[]? data = null)
    {
        byte[] bytes = data ?? new byte[] { 1, 2, 3 };
        return m.CreateTempFile(name, s => s.Write(bytes));
    }

    private static IEnumerable<string> PlaintextFiles(string root) =>
        Directory.EnumerateFiles(root, "*", SearchOption.AllDirectories)
                 .Where(f => Path.GetFileName(f) != TempFileManager.MarkerFileName);

    [Fact]
    public void CreateTempFile_WritesContent_KeepsTheRealName_AndIsReadOnly()
    {
        TempFileManager m = NewManager();
        byte[] data = { 9, 8, 7, 6 };
        string path = Make(m, "report.pdf", data);

        Assert.Equal(data, File.ReadAllBytes(path));
        Assert.Equal("report.pdf", Path.GetFileName(path));
        Assert.StartsWith(m.SessionDirectory, path);
        Assert.NotEqual(0, (int)(File.GetAttributes(path) & FileAttributes.ReadOnly));
        Assert.Equal(1, m.ActiveCount);
    }

    [Fact]
    public void HostileNames_CannotEscapeTheSessionDirectory()
    {
        TempFileManager m = NewManager();
        string path = Make(m, "..\\..\\..\\evil.txt");

        Assert.Equal("evil.txt", Path.GetFileName(path));
        Assert.StartsWith(m.SessionDirectory + Path.DirectorySeparatorChar, path);
        Assert.False(File.Exists(Path.Combine(_dir.Root, "evil.txt")));
    }

    [Fact]
    public void EmptyName_FallsBackToSafeName()
    {
        TempFileManager m = NewManager();
        Assert.Equal("file", Path.GetFileName(Make(m, "")));
    }

    [Fact]
    public void SameNameTwice_GetsSeparateFolders()
    {
        TempFileManager m = NewManager();
        string a = Make(m, "same.txt");
        string b = Make(m, "same.txt");

        Assert.NotEqual(a, b);
        Assert.True(File.Exists(a) && File.Exists(b));
        Assert.Equal(2, m.ActiveCount);
    }

    [Fact]
    public void WriterFailure_WipesThePartialFile()
    {
        TempFileManager m = NewManager();
        Assert.Throws<IOException>(() => m.CreateTempFile("x.bin", s =>
        {
            s.Write(new byte[1000]);
            throw new IOException("Simulated: the USB drive was removed while decrypting.");
        }));

        Assert.Empty(PlaintextFiles(m.SessionDirectory));
        Assert.Empty(Directory.GetDirectories(m.SessionDirectory));
        Assert.Equal(0, m.ActiveCount);
    }

    [Fact]
    public void CleanupAll_RemovesEverything_IncludingFilesOtherProgramsCreated()
    {
        TempFileManager m = NewManager();
        string a = Make(m, "a.docx");
        Make(m, "b.xlsx");
        File.WriteAllText(Path.Combine(Path.GetDirectoryName(a)!, "~$a.docx"), "editor lock/autosave");

        CleanupReport report = m.CleanupAll();

        Assert.Equal(3, report.Deleted);
        Assert.True(report.IsComplete);
        Assert.Empty(PlaintextFiles(m.SessionDirectory));
        Assert.Equal(0, m.ActiveCount);

        // the manager stays usable after a cleanup
        string again = Make(m, "c.txt");
        Assert.True(File.Exists(again));
    }

    [Fact]
    public void CleanupAll_WithNothingToDo_IsHarmless()
    {
        TempFileManager m = NewManager();
        CleanupReport r = m.CleanupAll();
        Assert.Equal(0, r.Deleted);
        Assert.True(r.IsComplete);
    }

    [Fact]
    public void Dispose_RemovesTheWholeSessionDirectory_AndRefusesNewFiles()
    {
        TempFileManager m = NewManager();
        Make(m, "a.txt");
        string session = m.SessionDirectory;

        m.Dispose();

        Assert.False(Directory.Exists(session));
        Assert.Throws<ObjectDisposedException>(() => Make(m, "b.txt"));
    }

    [Fact]
    public void Sessions_AreIndependent()
    {
        TempFileManager a = NewManager();
        TempFileManager b = NewManager();
        Assert.NotEqual(a.SessionDirectory, b.SessionDirectory);

        string fa = Make(a, "a.txt");
        string fb = Make(b, "b.txt");
        a.Dispose();

        Assert.False(File.Exists(fa));
        Assert.True(File.Exists(fb));
    }

    [Fact]
    public void SweepStale_RemovesSessionsAbandonedByACrashedRun()
    {
        string stale = Path.Combine(_dir.Root, TempFileManager.SessionPrefix + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(Path.Combine(stale, "inner"));
        File.WriteAllText(Path.Combine(stale, TempFileManager.MarkerFileName), "marker");
        File.WriteAllBytes(Path.Combine(stale, "inner", "plaintext.docx"), new byte[500]);

        CleanupReport r = TempFileManager.SweepStale(_dir.Root);

        Assert.False(Directory.Exists(stale));
        Assert.Equal(2, r.Deleted);
        Assert.True(r.IsComplete);
    }

    [Fact]
    public void SweepStale_NeverTouchesLiveSessionsOrForeignFolders()
    {
        TempFileManager live = NewManager();
        string liveFile = Make(live, "inuse.txt");

        string noMarker = Path.Combine(_dir.Root, TempFileManager.SessionPrefix + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(noMarker);
        File.WriteAllText(Path.Combine(noMarker, "keep.txt"), "x");

        string wrongName = Path.Combine(_dir.Root, TempFileManager.SessionPrefix + "notes");
        Directory.CreateDirectory(wrongName);
        File.WriteAllText(Path.Combine(wrongName, TempFileManager.MarkerFileName), "x");
        File.WriteAllText(Path.Combine(wrongName, "keep.txt"), "x");

        string documents = _dir.Sub("Documents");
        File.WriteAllText(Path.Combine(documents, "important.docx"), "x");

        TempFileManager.SweepStale(_dir.Root);

        Assert.True(File.Exists(liveFile));
        Assert.True(File.Exists(Path.Combine(noMarker, "keep.txt")));
        Assert.True(File.Exists(Path.Combine(wrongName, "keep.txt")));
        Assert.True(File.Exists(Path.Combine(documents, "important.docx")));
    }

    [Fact]
    public void SweepStale_OnMissingRoot_DoesNothing()
    {
        CleanupReport r = TempFileManager.SweepStale(Path.Combine(_dir.Root, "does-not-exist"));
        Assert.Equal(0, r.Deleted);
    }

    [Fact]
    public void FileStillOpenInAnotherProgram_IsReportedThenRemovedLater()
    {
        if (!OperatingSystem.IsWindows()) return;   // other systems let you delete open files

        TempFileManager m = NewManager();
        string path = Make(m, "open.docx");

        CleanupReport blocked;
        using (new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))   // "Word has it open"
        {
            blocked = m.CleanupAll();
        }

        Assert.False(blocked.IsComplete);
        Assert.Contains(blocked.Failed, f => string.Equals(f, path, StringComparison.OrdinalIgnoreCase));

        CleanupReport retry = m.CleanupAll();
        Assert.True(retry.IsComplete);
        Assert.False(File.Exists(path));
    }

    [Fact]
    public void ParallelCreation_ThenCleanup_LeavesNothing()
    {
        TempFileManager m = NewManager();
        Parallel.For(0, 20, new ParallelOptions { MaxDegreeOfParallelism = 8 }, i => Make(m, $"f{i}.bin", new byte[100]));
        Assert.Equal(20, m.ActiveCount);

        CleanupReport r = m.CleanupAll();
        Assert.Equal(20, r.Deleted);
        Assert.Empty(PlaintextFiles(m.SessionDirectory));
    }
}
