using SecureUSB.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Storage.Tests;

public class HeaderStoreTests : IDisposable
{
    private readonly TempVault _t = new();

    public void Dispose() => _t.Dispose();

    private (VaultHeaderStore Store, VaultHeader Header) CreateStored()
    {
        NewVault nv = Harness.NewVault();
        nv.Keys.Dispose();
        var store = new VaultHeaderStore(_t.Paths);
        store.Create(nv.Header);
        return (store, nv.Header);
    }

    private static VaultHeader ChangePassword(VaultHeader old) =>
        VaultKeyManager.ChangePassword(Harness.Password, Harness.OtherPassword, old);

    [Fact]
    public void Create_WritesIdenticalPrimaryAndBackup()
    {
        var (store, header) = CreateStored();
        Assert.True(store.Exists);
        Assert.Equal(header.ToBytes(), File.ReadAllBytes(_t.Paths.HeaderPath));
        Assert.Equal(header.ToBytes(), File.ReadAllBytes(_t.Paths.HeaderBackupPath));
        Assert.False(File.Exists(_t.Paths.HeaderTempPath));

        HeaderLoadResult loaded = store.Load();
        Assert.Equal(HeaderSource.Primary, loaded.Source);
        Assert.Equal(header.ToBytes(), loaded.Header.ToBytes());
    }

    [Fact]
    public void Exists_IsFalseBeforeCreate_AndCreateTwiceThrows()
    {
        var store = new VaultHeaderStore(_t.Paths);
        Assert.False(store.Exists);
        Assert.Throws<VaultCorruptException>(() => store.Load());

        var (created, _) = CreateStored();
        NewVault other = Harness.NewVault();
        other.Keys.Dispose();
        Assert.Throws<InvalidOperationException>(() => created.Create(other.Header));
    }

    [Fact]
    public void Commit_ReplacesPrimaryAndBackup_AndOldPasswordStopsWorking()
    {
        var (store, header) = CreateStored();
        VaultHeader changed = ChangePassword(header);
        store.Commit(changed);

        HeaderLoadResult loaded = store.Load();
        Assert.Equal(HeaderSource.Primary, loaded.Source);
        VaultKeyManager.Unlock(Harness.OtherPassword, loaded.Header).Dispose();
        Assert.Throws<VaultAuthenticationException>(() => VaultKeyManager.Unlock(Harness.Password, loaded.Header));

        // The backup must NOT keep the old password alive.
        Assert.Equal(File.ReadAllBytes(_t.Paths.HeaderPath), File.ReadAllBytes(_t.Paths.HeaderBackupPath));
        VaultHeader backup = store.TryReadBackup()!;
        Assert.Throws<VaultAuthenticationException>(() => VaultKeyManager.Unlock(Harness.Password, backup));
        Assert.False(File.Exists(_t.Paths.HeaderTempPath));
    }

    [Fact]
    public void Crash_AfterTempWritten_KeepsOldHeader_AndHealRemovesTemp()
    {
        var (store, header) = CreateStored();
        VaultHeader changed = ChangePassword(header);
        File.WriteAllBytes(_t.Paths.HeaderTempPath, changed.ToBytes());   // state after step 1 of Commit

        HeaderLoadResult loaded = store.Load();
        Assert.Equal(HeaderSource.Primary, loaded.Source);
        Assert.Equal(header.ToBytes(), loaded.Header.ToBytes());
        Assert.True(store.Inspect().TempPresent);

        store.Heal(loaded.Header);
        Assert.False(File.Exists(_t.Paths.HeaderTempPath));
        VaultKeyManager.Unlock(Harness.Password, store.Load().Header).Dispose();
    }

    [Fact]
    public void Crash_BetweenDeleteAndRename_UsesPendingTemp()
    {
        var (store, header) = CreateStored();
        VaultHeader changed = ChangePassword(header);
        File.WriteAllBytes(_t.Paths.HeaderTempPath, changed.ToBytes());
        File.Delete(_t.Paths.HeaderPath);                                  // non-atomic FAT-style replace gap

        HeaderLoadResult loaded = store.Load();
        Assert.Equal(HeaderSource.PendingTemp, loaded.Source);
        VaultKeyManager.Unlock(Harness.OtherPassword, loaded.Header).Dispose();

        store.Heal(loaded.Header);
        Assert.Equal(changed.ToBytes(), File.ReadAllBytes(_t.Paths.HeaderPath));
        Assert.Equal(changed.ToBytes(), File.ReadAllBytes(_t.Paths.HeaderBackupPath));
        Assert.False(File.Exists(_t.Paths.HeaderTempPath));
    }

    [Fact]
    public void Crash_AfterPrimaryReplaced_BackupStale_PrimaryWins_AndHealFixesBackup()
    {
        var (store, header) = CreateStored();
        VaultHeader changed = ChangePassword(header);
        File.WriteAllBytes(_t.Paths.HeaderPath, changed.ToBytes());        // state after step 2, before step 3

        HeaderLoadResult loaded = store.Load();
        Assert.Equal(HeaderSource.Primary, loaded.Source);
        Assert.False(store.Inspect().InSync);
        Assert.Throws<VaultAuthenticationException>(() => VaultKeyManager.Unlock(Harness.Password, loaded.Header));

        store.Heal(loaded.Header);
        Assert.True(store.Inspect().InSync);
        Assert.Throws<VaultAuthenticationException>(() =>
            VaultKeyManager.Unlock(Harness.Password, store.TryReadBackup()!));
    }

    [Fact]
    public void StructurallyDamagedPrimary_FallsBackToBackup()
    {
        var (store, header) = CreateStored();
        Harness.FlipByte(_t.Paths.HeaderPath, 0);   // magic

        HeaderLoadResult loaded = store.Load();
        Assert.Equal(HeaderSource.Backup, loaded.Source);
        Assert.Equal(header.ToBytes(), loaded.Header.ToBytes());
        VaultKeyManager.Unlock(Harness.Password, loaded.Header).Dispose();
    }

    [Fact]
    public void TruncatedPrimary_FallsBackToBackup()
    {
        var (store, _) = CreateStored();
        byte[] half = File.ReadAllBytes(_t.Paths.HeaderPath).AsSpan(0, 50).ToArray();
        File.WriteAllBytes(_t.Paths.HeaderPath, half);
        Assert.Equal(HeaderSource.Backup, store.Load().Source);
    }

    [Fact]
    public void OversizedPrimary_IsIgnoredWithoutReadingIt()
    {
        var (store, _) = CreateStored();
        File.WriteAllBytes(_t.Paths.HeaderPath, new byte[5 * 1024 * 1024]);
        Assert.Equal(HeaderSource.Backup, store.Load().Source);
    }

    [Fact]
    public void BitRotInsideWrappedKey_LooksLikeWrongPassword_ButBackupRecoveryWorks()
    {
        var (store, _) = CreateStored();
        Harness.FlipByte(_t.Paths.HeaderPath, VaultHeader.WrappedKeyOffset + 5);

        HeaderLoadResult loaded = store.Load();
        Assert.Equal(HeaderSource.Primary, loaded.Source);   // structurally valid, so it is used
        Assert.Throws<VaultAuthenticationException>(() => VaultKeyManager.Unlock(Harness.Password, loaded.Header));

        // explicit, user-confirmed recovery path
        VaultHeader backup = store.TryReadBackup()!;
        VaultKeyManager.Unlock(Harness.Password, backup).Dispose();
        store.Heal(backup);
        VaultKeyManager.Unlock(Harness.Password, store.Load().Header).Dispose();
    }

    [Fact]
    public void AllCopiesInvalid_Throws()
    {
        var (store, _) = CreateStored();
        File.WriteAllBytes(_t.Paths.HeaderPath, Harness.Data(131));
        File.WriteAllBytes(_t.Paths.HeaderBackupPath, Harness.Data(10));
        Assert.Throws<VaultCorruptException>(() => store.Load());
        Assert.Null(store.TryReadBackup());
    }

    [Fact]
    public void Inspect_ReportsStateOfEachCopy()
    {
        var (store, _) = CreateStored();
        HeaderState ok = store.Inspect();
        Assert.True(ok.PrimaryValid && ok.BackupValid && ok.InSync);
        Assert.False(ok.TempPresent);

        File.Delete(_t.Paths.HeaderBackupPath);
        HeaderState noBackup = store.Inspect();
        Assert.True(noBackup.PrimaryValid);
        Assert.False(noBackup.BackupValid);
        Assert.False(noBackup.InSync);
    }

    [Fact]
    public void Heal_RebuildsMissingCopies()
    {
        var (store, header) = CreateStored();
        File.Delete(_t.Paths.HeaderPath);
        File.WriteAllBytes(_t.Paths.HeaderBackupPath, new byte[3]);
        store.Heal(header);
        Assert.Equal(header.ToBytes(), File.ReadAllBytes(_t.Paths.HeaderPath));
        Assert.Equal(header.ToBytes(), File.ReadAllBytes(_t.Paths.HeaderBackupPath));
    }

    [Fact]
    public void Commit_FailureLeavesPrimaryAndBackupUntouched()
    {
        var (store, header) = CreateStored();
        VaultHeader changed = ChangePassword(header);
        Directory.CreateDirectory(_t.Paths.HeaderTempPath);   // simulated write failure

        Assert.ThrowsAny<Exception>(() => store.Commit(changed));

        Assert.Equal(header.ToBytes(), File.ReadAllBytes(_t.Paths.HeaderPath));
        Assert.Equal(header.ToBytes(), File.ReadAllBytes(_t.Paths.HeaderBackupPath));
    }
}
