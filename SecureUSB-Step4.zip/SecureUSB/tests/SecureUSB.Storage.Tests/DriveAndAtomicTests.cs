namespace SecureUSB.Storage.Tests;

public class DriveAndAtomicTests
{
    [Theory]
    [InlineData(0L, "0 B")]
    [InlineData(1023L, "1023 B")]
    [InlineData(1024L, "1.0 KB")]
    [InlineData(1536L, "1.5 KB")]
    [InlineData(1048576L, "1.0 MB")]
    [InlineData(1073741824L, "1.0 GB")]
    [InlineData(1099511627776L, "1.0 TB")]
    public void ByteSize_FormatsLikeWindowsExplorer(long bytes, string expected)
    {
        Assert.Equal(expected, ByteSize.Format(bytes));
    }

    [Fact]
    public void SystemDriveInfo_ReportsRealCapacity()
    {
        var service = new SystemDriveInfoService();
        DriveCapacity cap = service.GetCapacity(Path.GetTempPath());
        Assert.True(cap.TotalBytes > 0);
        Assert.InRange(cap.FreeBytes, 0, cap.TotalBytes);
        Assert.Equal(cap.TotalBytes - cap.FreeBytes, cap.UsedBytes);
        Assert.False(string.IsNullOrEmpty(cap.FileSystem));
        Assert.True(service.IsAvailable(Path.GetTempPath()));
    }

    [Theory]
    [InlineData("FAT32", true)]
    [InlineData("FAT", true)]
    [InlineData("vfat", true)]
    [InlineData("exFAT", false)]
    [InlineData("NTFS", false)]
    public void Fat32_HasFourGibFileLimit(string fileSystem, bool limited)
    {
        var cap = new DriveCapacity("E:\\", "X", fileSystem, DriveType.Removable, 100, 50);
        if (limited) Assert.Equal(4294967295L, cap.MaxFileSizeBytes);
        else Assert.Null(cap.MaxFileSizeBytes);
        Assert.True(cap.IsRemovable);
    }

    // ---------------------------------------------------------------- storage usage categories

    [Fact]
    public void StorageUsage_SeparatesPhysicalVaultApplicationAndOther()
    {
        using var t = new TempVault();
        Directory.CreateDirectory(t.Paths.BlobsDirectory);
        File.WriteAllBytes(Path.Combine(t.Paths.DataDirectory, "vault.hdr"), new byte[100]);
        File.WriteAllBytes(Path.Combine(t.Paths.BlobsDirectory, "x.blob"), new byte[1000]);

        string appDir = t.NewSubfolder("SecureUSB_App");
        File.WriteAllBytes(Path.Combine(appDir, "app.dll"), new byte[500]);
        string exe = Path.Combine(t.Root, "SecureUSB.exe");
        File.WriteAllBytes(exe, new byte[200]);

        t.Drive.Total = 10_000;
        t.Drive.Free = 6_000;

        // an "application path" located inside the vault must never be counted twice
        var apps = new[] { appDir, exe, Path.Combine(t.Paths.BlobsDirectory, "x.blob") };
        StorageUsage usage = StorageUsageCalculator.Calculate(t.Paths, apps, t.Drive);

        Assert.Equal(10_000, usage.TotalBytes);
        Assert.Equal(6_000, usage.FreeBytes);
        Assert.Equal(4_000, usage.UsedBytes);
        Assert.Equal(1_100, usage.VaultBytes);
        Assert.Equal(700, usage.ApplicationBytes);
        Assert.Equal(2_200, usage.OtherBytes);
    }

    [Fact]
    public void StorageUsage_OtherNeverNegative_AndMissingFoldersAreZero()
    {
        using var t = new TempVault();
        t.Drive.Total = 1000;
        t.Drive.Free = 900;
        Directory.CreateDirectory(t.Paths.DataDirectory);
        File.WriteAllBytes(Path.Combine(t.Paths.DataDirectory, "big"), new byte[5000]);

        StorageUsage usage = StorageUsageCalculator.Calculate(t.Paths, new[] { Path.Combine(t.Root, "nope") }, t.Drive);
        Assert.Equal(0, usage.ApplicationBytes);
        Assert.Equal(0, usage.OtherBytes);
        Assert.Equal(0, StorageUsageCalculator.DirectorySize(Path.Combine(t.Root, "missing")));
    }

    // ---------------------------------------------------------------- AtomicFile / FileWiper

    [Fact]
    public void AtomicWrite_CreatesAndReplaces_WithoutLeavingTemp()
    {
        using var t = new TempVault();
        string target = Path.Combine(t.Root, "data.bin");

        AtomicFile.WriteAllBytes(target, new byte[] { 1, 2, 3 });
        Assert.Equal(new byte[] { 1, 2, 3 }, File.ReadAllBytes(target));

        AtomicFile.WriteAllBytes(target, new byte[] { 9, 9 });
        Assert.Equal(new byte[] { 9, 9 }, File.ReadAllBytes(target));
        Assert.False(File.Exists(AtomicFile.TempPath(target)));
    }

    [Fact]
    public void AtomicWrite_Failure_LeavesOriginalIntact()
    {
        using var t = new TempVault();
        string target = Path.Combine(t.Root, "data.bin");
        File.WriteAllBytes(target, new byte[] { 1, 2, 3 });

        // Make the temp path unusable: the write fails before the original is touched.
        Directory.CreateDirectory(AtomicFile.TempPath(target));
        Assert.ThrowsAny<Exception>(() => AtomicFile.WriteAllBytes(target, new byte[] { 9 }));

        Assert.Equal(new byte[] { 1, 2, 3 }, File.ReadAllBytes(target));
    }

    [Fact]
    public void TryDelete_MissingFile_ReturnsTrue()
    {
        using var t = new TempVault();
        Assert.True(AtomicFile.TryDelete(Path.Combine(t.Root, "nothing")));
    }

    [Fact]
    public void Wiper_RemovesFiles_IncludingReadOnlyAndMissing()
    {
        using var t = new TempVault();
        string normal = Path.Combine(t.Root, "plain.tmp");
        File.WriteAllBytes(normal, Harness.Data(100_000));
        Assert.True(FileWiper.TryWipeAndDelete(normal));
        Assert.False(File.Exists(normal));

        string ro = Path.Combine(t.Root, "readonly.tmp");
        File.WriteAllBytes(ro, new byte[10]);
        File.SetAttributes(ro, FileAttributes.ReadOnly);
        Assert.True(FileWiper.TryWipeAndDelete(ro));
        Assert.False(File.Exists(ro));

        Assert.True(FileWiper.TryWipeAndDelete(Path.Combine(t.Root, "never-existed")));
    }

    [Fact]
    public void BlobFileNames_ParseOnlyExactForms()
    {
        Guid id = Guid.NewGuid();
        Assert.True(VaultPaths.TryParseBlobFileName(id.ToString("N") + ".blob", out Guid parsed, out bool temp));
        Assert.Equal(id, parsed);
        Assert.False(temp);

        Assert.True(VaultPaths.TryParseBlobFileName(id.ToString("N") + ".blob.tmp", out parsed, out temp));
        Assert.True(temp);

        Assert.False(VaultPaths.TryParseBlobFileName("notes.txt", out _, out _));
        Assert.False(VaultPaths.TryParseBlobFileName("abc.blob", out _, out _));
        Assert.False(VaultPaths.TryParseBlobFileName(id.ToString("N") + ".blob.bak", out _, out _));
    }
}
