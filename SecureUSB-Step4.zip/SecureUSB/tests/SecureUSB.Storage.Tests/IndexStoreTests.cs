using System.Security.Cryptography;
using System.Text;
using SecureUSB.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Storage.Tests;

public class IndexStoreTests : IDisposable
{
    private readonly TempVault _t = new();
    private readonly VaultKeys _keys = Harness.NewKeys();
    private readonly EncryptedIndexStore _store;
    private static readonly DateTimeOffset Now = new(2026, 1, 1, 12, 0, 0, TimeSpan.Zero);

    public IndexStoreTests()
    {
        _t.Paths.EnsureDirectories();
        _store = new EncryptedIndexStore(_t.Paths);
    }

    public void Dispose()
    {
        _keys.Dispose();
        _t.Dispose();
    }

    private static FileEntry Entry(string name, string folder = "") => new()
    {
        Id = Guid.NewGuid(), Name = name, FolderPath = folder, SizeBytes = 1, ChunkSize = 1 << 20,
        AddedUtc = Now, ModifiedUtc = Now
    };

    private VaultIndex Rev1() => VaultIndex.CreateEmpty(_keys.VaultId, Now);
    private VaultIndex Next(VaultIndex i, params FileEntry[] files) => i.WithFiles(i.Files.Concat(files).ToList(), Now);

    [Fact]
    public void SaveThenLoad_RoundTrips()
    {
        VaultIndex idx = Next(Rev1(), Entry("a.txt"), Entry("b.pdf", "Legal/2026"));
        _store.Save(idx, _keys);

        IndexLoadResult loaded = _store.Load(_keys)!;
        Assert.Equal(IndexSource.Primary, loaded.Source);
        Assert.Equal(idx.Revision, loaded.Index.Revision);
        Assert.Equal(idx.Files.Select(f => f.FullPath), loaded.Index.Files.Select(f => f.FullPath));
        Assert.Equal(idx.Files[0], loaded.Index.Files[0]);
    }

    [Fact]
    public void Load_NoFiles_ReturnsNull()
    {
        Assert.Null(_store.Load(_keys));
        Assert.False(_store.AnyCandidateExists);
    }

    [Fact]
    public void SecondSave_KeepsPreviousRevision_AndLeavesNoTemp()
    {
        VaultIndex r1 = Rev1();
        VaultIndex r2 = Next(r1, Entry("a.txt"));
        _store.Save(r1, _keys);
        _store.Save(r2, _keys);

        Assert.True(File.Exists(_t.Paths.IndexPath));
        Assert.True(File.Exists(_t.Paths.IndexPrevPath));
        Assert.False(File.Exists(_t.Paths.IndexTempPath));
        Assert.Equal(1, _store.Decode(File.ReadAllBytes(_t.Paths.IndexPrevPath), _keys).Revision);
        Assert.Equal(2, _store.Decode(File.ReadAllBytes(_t.Paths.IndexPath), _keys).Revision);
    }

    [Fact]
    public void IndexFile_ContainsNoReadableNames()
    {
        VaultIndex idx = Next(Rev1(), Entry("TopSecretProject.docx", "Legal/Merger2026"));
        _store.Save(idx, _keys);
        byte[] file = File.ReadAllBytes(_t.Paths.IndexPath);

        foreach (string needle in new[] { "TopSecretProject", "Merger2026", "docx" })
        {
            Assert.True(file.AsSpan().IndexOf(Encoding.ASCII.GetBytes(needle)) < 0, needle + " (ASCII)");
            Assert.True(file.AsSpan().IndexOf(Encoding.Unicode.GetBytes(needle)) < 0, needle + " (UTF-16)");
        }
    }

    [Fact]
    public void IndexSize_IsPaddedToBuckets_HidingExactFileCount()
    {
        byte[] few = _store.Encode(Next(Rev1(), Entry("a.txt"), Entry("b.txt"), Entry("c.txt")), _keys);
        byte[] more = _store.Encode(Next(Rev1(), Enumerable.Range(0, 10).Select(i => Entry($"file-{i}.txt")).ToArray()), _keys);

        Assert.Equal(few.Length, more.Length);
        Assert.Equal(0, (few.Length - 16 - Aead.Overhead) % EncryptedIndexStore.BucketSize);
    }

    [Fact]
    public void EveryBitFlip_IsRejected()
    {
        byte[] file = _store.Encode(Next(Rev1(), Entry("a.txt")), _keys);
        for (int i = 0; i < file.Length; i++)
        {
            byte[] bad = (byte[])file.Clone();
            bad[i] ^= 0x01;
            try
            {
                _store.Decode(bad, _keys);
                Assert.Fail($"Tampering at byte {i} was not detected.");
            }
            catch (Exception e) when (e is CryptographicException or InvalidVaultFormatException)
            {
                // expected
            }
        }
    }

    [Fact]
    public void EveryTruncation_IsRejected()
    {
        byte[] file = _store.Encode(Next(Rev1(), Entry("a.txt")), _keys);
        for (int length = 0; length < file.Length; length++)
        {
            byte[] cut = file.AsSpan(0, length).ToArray();
            try
            {
                _store.Decode(cut, _keys);
                Assert.Fail($"Truncation to {length} bytes was not detected.");
            }
            catch (Exception e) when (e is CryptographicException or InvalidVaultFormatException)
            {
                // expected
            }
        }
    }

    [Fact]
    public void RevisionIsAuthenticated_CannotRelabelAnOldIndexAsNewer()
    {
        byte[] file = _store.Encode(Next(Rev1(), Entry("a.txt")), _keys);   // revision 2
        file[15] = 9;                                                       // claim revision 9
        Assert.ThrowsAny<CryptographicException>(() => _store.Decode(file, _keys));
    }

    [Fact]
    public void IndexOfAnotherVault_IsRejected()
    {
        byte[] file = _store.Encode(Next(Rev1(), Entry("a.txt")), _keys);
        using VaultKeys other = Harness.NewKeys();
        Assert.ThrowsAny<CryptographicException>(() => _store.Decode(file, other));

        File.WriteAllBytes(_t.Paths.IndexPath, file);
        Assert.Throws<VaultCorruptException>(() => _store.Load(other));
    }

    [Fact]
    public void Encode_RefusesIndexOfAnotherVault()
    {
        VaultIndex foreign = VaultIndex.CreateEmpty(Guid.NewGuid(), Now);
        Assert.Throws<ArgumentException>(() => _store.Encode(foreign, _keys));
    }

    // ------------------------------------------------------------ crash windows of the save protocol

    [Fact]
    public void Crash_AfterTempWritten_NewerTempWins_AndHealCompletesCommit()
    {
        VaultIndex r1 = Rev1();
        VaultIndex r2 = Next(r1, Entry("a.txt"));
        _store.Save(r1, _keys);
        File.WriteAllBytes(_t.Paths.IndexTempPath, _store.Encode(r2, _keys));

        IndexLoadResult loaded = _store.Load(_keys)!;
        Assert.Equal(IndexSource.PendingTemp, loaded.Source);
        Assert.Equal(2, loaded.Index.Revision);

        _store.Heal(loaded);
        Assert.False(File.Exists(_t.Paths.IndexTempPath));
        Assert.Equal(IndexSource.Primary, _store.Load(_keys)!.Source);
        Assert.Equal(2, _store.Load(_keys)!.Index.Revision);
    }

    [Fact]
    public void Crash_AfterOldMovedToPrev_PrimaryMissing_TempIsRecovered()
    {
        VaultIndex r1 = Rev1();
        VaultIndex r2 = Next(r1, Entry("a.txt"));
        VaultIndex r3 = Next(r2, Entry("b.txt"));
        _store.Save(r1, _keys);
        _store.Save(r2, _keys);

        File.Move(_t.Paths.IndexPath, _t.Paths.IndexPrevPath, overwrite: true);   // protocol step 2
        File.WriteAllBytes(_t.Paths.IndexTempPath, _store.Encode(r3, _keys));     // step 1 result
        Assert.False(File.Exists(_t.Paths.IndexPath));

        IndexLoadResult loaded = _store.Load(_keys)!;
        Assert.Equal(IndexSource.PendingTemp, loaded.Source);
        Assert.Equal(3, loaded.Index.Revision);
        Assert.Equal(2, loaded.Index.Files.Count);

        _store.Heal(loaded);
        Assert.True(File.Exists(_t.Paths.IndexPath));
        Assert.Equal(3, _store.Load(_keys)!.Index.Revision);
    }

    [Fact]
    public void TornTemp_IsIgnored_PrimaryStillWins()
    {
        VaultIndex r1 = Rev1();
        VaultIndex r2 = Next(r1, Entry("a.txt"));
        _store.Save(r1, _keys);
        byte[] full = _store.Encode(r2, _keys);
        File.WriteAllBytes(_t.Paths.IndexTempPath, full.AsSpan(0, full.Length / 2).ToArray());

        IndexLoadResult loaded = _store.Load(_keys)!;
        Assert.Equal(IndexSource.Primary, loaded.Source);
        Assert.Equal(1, loaded.Index.Revision);

        _store.Heal(loaded);
        Assert.False(File.Exists(_t.Paths.IndexTempPath));
    }

    [Fact]
    public void CorruptPrimary_FallsBackToPrevious_AndHealRestoresPrimary()
    {
        VaultIndex r1 = Rev1();
        VaultIndex r2 = Next(r1, Entry("a.txt"));
        _store.Save(r1, _keys);
        _store.Save(r2, _keys);
        Harness.FlipByte(_t.Paths.IndexPath, 100);

        IndexLoadResult loaded = _store.Load(_keys)!;
        Assert.Equal(IndexSource.Previous, loaded.Source);
        Assert.Equal(1, loaded.Index.Revision);

        _store.Heal(loaded);
        IndexLoadResult again = _store.Load(_keys)!;
        Assert.Equal(IndexSource.Primary, again.Source);
        Assert.Equal(1, again.Index.Revision);
    }

    [Fact]
    public void AllCopiesCorrupt_Throws()
    {
        _store.Save(Rev1(), _keys);
        _store.Save(Next(Rev1(), Entry("a.txt")), _keys);
        Harness.FlipByte(_t.Paths.IndexPath, 100);
        Harness.FlipByte(_t.Paths.IndexPrevPath, 100);
        Assert.Throws<VaultCorruptException>(() => _store.Load(_keys));
    }

    [Fact]
    public void OversizedIndexFile_IsRejectedWithoutBeingRead()
    {
        using (var fs = new FileStream(_t.Paths.IndexPath, FileMode.Create))
            fs.SetLength(EncryptedIndexStore.MaxFileBytes + 1024 * 1024);
        Assert.Throws<VaultCorruptException>(() => _store.Load(_keys));
    }

    [Fact]
    public void SaveFailure_LeavesExistingIndexUntouched()
    {
        VaultIndex r1 = Rev1();
        _store.Save(r1, _keys);
        byte[] before = File.ReadAllBytes(_t.Paths.IndexPath);

        Directory.CreateDirectory(_t.Paths.IndexTempPath);   // simulated device failure at step 1
        Assert.ThrowsAny<Exception>(() => _store.Save(Next(r1, Entry("a.txt")), _keys));

        Assert.Equal(before, File.ReadAllBytes(_t.Paths.IndexPath));
    }

    [Fact]
    public void LargeIndex_RoundTrips()
    {
        VaultIndex idx = Next(Rev1(), Enumerable.Range(0, 2000).Select(i => Entry($"file-{i:D4}.txt", "Bulk")).ToArray());
        _store.Save(idx, _keys);
        IndexLoadResult loaded = _store.Load(_keys)!;
        Assert.Equal(2000, loaded.Index.Files.Count);
        Assert.Equal("file-1999.txt", loaded.Index.Files[1999].Name);
    }
}
