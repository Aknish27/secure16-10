using System.Text;
using SecureUSB.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Storage.Tests;

public class BlobStoreTests : IDisposable
{
    private const int Chunk = 1024;
    private readonly TempVault _t = new();
    private readonly VaultKeys _keys = Harness.NewKeys();
    private readonly BlobStore _blobs;

    public BlobStoreTests() => _blobs = new BlobStore(_t.Paths, _t.Drive);

    public void Dispose()
    {
        _keys.Dispose();
        _t.Dispose();
    }

    private (FileEntry Entry, BlobWriteResult Result) Store(byte[] data, int chunk = Chunk)
    {
        Guid id = SecureRandom.NewGuid();
        using var ms = new MemoryStream(data);
        BlobWriteResult r = _blobs.WriteTemp(id, ms, _keys, chunk);
        _blobs.CommitTemp(id);
        var entry = new FileEntry { Id = id, Name = "x.bin", SizeBytes = data.Length, ChunkSize = chunk };
        return (entry, r);
    }

    private byte[] Read(FileEntry entry, VaultKeys? keys = null)
    {
        using var ms = new MemoryStream();
        _blobs.Read(entry, keys ?? _keys, ms);
        return ms.ToArray();
    }

    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(1500)]
    [InlineData(5000)]
    public void WriteThenRead_RoundTrips_AndLengthMatchesFormula(int length)
    {
        byte[] data = Harness.Data(length);
        var (entry, result) = Store(data);

        Assert.Equal(data, Read(entry));
        Assert.Equal(length, result.PlaintextBytes);
        Assert.Equal(BlobFormat.BlobLength(length, Chunk), result.BlobBytes);
        Assert.Equal(result.BlobBytes, new FileInfo(_t.Paths.BlobPath(entry.Id)).Length);
        Assert.Equal(result.BlobBytes, _blobs.GetLength(entry.Id));
    }

    [Fact]
    public void BlobFile_ContainsNoPlaintext_AndHasRandomName()
    {
        byte[] marker = Encoding.ASCII.GetBytes("CONFIDENTIAL-MARKER-0123456789");
        byte[] data = new byte[4000];
        for (int i = 0; i + marker.Length <= data.Length; i += marker.Length) marker.CopyTo(data, i);

        var (entry, _) = Store(data);
        byte[] disk = File.ReadAllBytes(_t.Paths.BlobPath(entry.Id));
        Assert.True(disk.AsSpan().IndexOf(marker) < 0);
        Assert.Matches("^[0-9a-f]{32}\\.blob$", Path.GetFileName(_t.Paths.BlobPath(entry.Id)));
    }

    [Fact]
    public void TempBlob_IsNotAVisibleBlobUntilCommitted()
    {
        Guid id = SecureRandom.NewGuid();
        using var ms = new MemoryStream(Harness.Data(100));
        _blobs.WriteTemp(id, ms, _keys, Chunk);

        Assert.True(File.Exists(_t.Paths.BlobTempPath(id)));
        Assert.False(_blobs.Exists(id));
        Assert.Empty(_blobs.EnumerateBlobIds());

        _blobs.CommitTemp(id);
        Assert.False(File.Exists(_t.Paths.BlobTempPath(id)));
        Assert.True(_blobs.Exists(id));
        Assert.Equal(new[] { id }, _blobs.EnumerateBlobIds().ToArray());
    }

    [Fact]
    public void SourceFailure_MidWrite_LeavesNoTempFile()
    {
        Guid id = SecureRandom.NewGuid();
        using var failing = new FailingReadStream(3 * 1024 * 1024, failAt: 1_500_000);

        Assert.Throws<IOException>(() => _blobs.WriteTemp(id, failing, _keys, ChunkedFileCipher.DefaultChunkSize));

        Assert.False(File.Exists(_t.Paths.BlobTempPath(id)));
        Assert.False(File.Exists(_t.Paths.BlobPath(id)));
    }

    [Fact]
    public void Cancellation_LeavesNoTempFile()
    {
        Guid id = SecureRandom.NewGuid();
        using var cts = new CancellationTokenSource();
        cts.Cancel();
        using var ms = new MemoryStream(Harness.Data(5000));

        Assert.Throws<OperationCanceledException>(() => _blobs.WriteTemp(id, ms, _keys, Chunk, cts.Token));
        Assert.False(File.Exists(_t.Paths.BlobTempPath(id)));
    }

    [Fact]
    public void EverySingleByteFlip_IsDetected()
    {
        byte[] data = Harness.Data(2500);
        var (entry, _) = Store(data);
        string path = _t.Paths.BlobPath(entry.Id);
        byte[] good = File.ReadAllBytes(path);

        for (int i = 0; i < good.Length; i++)
        {
            byte[] bad = (byte[])good.Clone();
            bad[i] ^= 0x01;
            File.WriteAllBytes(path, bad);
            try
            {
                Read(entry);
                Assert.Fail($"Tampering at byte {i} of the blob was not detected.");
            }
            catch (DataIntegrityException)
            {
                // expected
            }
        }
    }

    [Fact]
    public void EveryTruncation_IsDetected()
    {
        byte[] data = Harness.Data(2500);
        var (entry, _) = Store(data);
        string path = _t.Paths.BlobPath(entry.Id);
        byte[] good = File.ReadAllBytes(path);

        for (int length = 0; length < good.Length; length++)
        {
            File.WriteAllBytes(path, good.AsSpan(0, length).ToArray());
            try
            {
                Read(entry);
                Assert.Fail($"Truncation to {length} bytes was not detected.");
            }
            catch (DataIntegrityException)
            {
                // expected
            }
        }
    }

    [Fact]
    public void AppendedBytes_AreDetected()
    {
        var (entry, _) = Store(Harness.Data(2500));
        using (var fs = new FileStream(_t.Paths.BlobPath(entry.Id), FileMode.Append))
            fs.WriteByte(0x42);
        Assert.Throws<DataIntegrityException>(() => Read(entry));
    }

    [Fact]
    public void BlobSwappedBetweenFiles_IsDetected()
    {
        var (a, _) = Store(Harness.Data(2000, seed: 1));
        var (b, _) = Store(Harness.Data(2000, seed: 2));
        File.Copy(_t.Paths.BlobPath(b.Id), _t.Paths.BlobPath(a.Id), overwrite: true);   // attacker swaps ciphertexts

        Assert.Throws<DataIntegrityException>(() => Read(a));
    }

    [Fact]
    public void BlobFromAnotherVault_CannotBeOpened()
    {
        var (entry, _) = Store(Harness.Data(2000));
        using VaultKeys other = Harness.NewKeys();
        Assert.Throws<DataIntegrityException>(() => Read(entry, other));
    }

    [Fact]
    public void IndexClaimingWrongSize_IsDetected()
    {
        var (entry, _) = Store(Harness.Data(2000));
        Assert.Throws<DataIntegrityException>(() => Read(entry with { SizeBytes = 1999 }));
    }

    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(1024)]
    [InlineData(1025)]
    [InlineData(5000)]
    public void ReadInfo_DerivesChunkSizeAndPlaintextLengthFromTheBlobAlone(int length)
    {
        var (entry, result) = Store(Harness.Data(length));
        BlobInfo info = _blobs.ReadInfo(entry.Id)!;

        Assert.Equal(entry.Id, info.FileId);
        Assert.Equal(Chunk, info.ChunkSize);
        Assert.Equal(length, info.PlaintextBytes);
        Assert.Equal(result.BlobBytes, info.BlobBytes);
        Assert.Equal(BlobFormat.WrappedKeyLength, info.WrappedKey.Length);
    }

    [Fact]
    public void ReadInfo_OfGarbageOrMissing_IsNull()
    {
        Guid id = SecureRandom.NewGuid();
        Assert.Null(_blobs.ReadInfo(id));

        _t.Paths.EnsureDirectories();
        File.WriteAllBytes(_t.Paths.BlobPath(id), Harness.Data(500));
        Assert.Null(_blobs.ReadInfo(id));
    }

    [Fact]
    public void Delete_RemovesBlob_AndToleratesMissing()
    {
        var (entry, _) = Store(Harness.Data(100));
        Assert.True(_blobs.TryDelete(entry.Id));
        Assert.False(_blobs.Exists(entry.Id));
        Assert.True(_blobs.TryDelete(entry.Id));
    }

    [Fact]
    public void EnumerateBlobIds_IgnoresTempAndForeignFiles()
    {
        var (entry, _) = Store(Harness.Data(10));
        File.WriteAllText(Path.Combine(_t.Paths.BlobsDirectory, "notes.txt"), "x");
        File.WriteAllBytes(_t.Paths.BlobTempPath(SecureRandom.NewGuid()), new byte[5]);
        Assert.Equal(new[] { entry.Id }, _blobs.EnumerateBlobIds().ToArray());
    }

    // ------------------------------------------------------------ drive preflight

    [Fact]
    public void Preflight_RefusesFileBiggerThanFat32Limit()
    {
        _t.Drive.FileSystem = "FAT32";
        Guid id = SecureRandom.NewGuid();
        using var huge = new HugeStream(5L * 1024 * 1024 * 1024);

        Assert.Throws<FileTooLargeException>(() => _blobs.WriteTemp(id, huge, _keys, ChunkedFileCipher.DefaultChunkSize));
        Assert.False(File.Exists(_t.Paths.BlobTempPath(id)));
    }

    [Fact]
    public void Preflight_RefusesWhenDriveIsTooFull()
    {
        _t.Drive.Free = 1024 * 1024;   // 1 MiB free, but 8 MiB are reserved for metadata
        Guid id = SecureRandom.NewGuid();
        using var ms = new MemoryStream(Harness.Data(100_000));

        var ex = Assert.Throws<InsufficientSpaceException>(() => _blobs.WriteTemp(id, ms, _keys, Chunk));
        Assert.True(ex.NeededBytes > ex.FreeBytes);
        Assert.False(File.Exists(_t.Paths.BlobTempPath(id)));
    }

    [Fact]
    public void Preflight_DriveRemoved_FailsCleanly()
    {
        _t.Drive.Available = false;
        Guid id = SecureRandom.NewGuid();
        using var ms = new MemoryStream(Harness.Data(1000));

        Assert.Throws<IOException>(() => _blobs.WriteTemp(id, ms, _keys, Chunk));
        Assert.False(File.Exists(_t.Paths.BlobTempPath(id)));
    }

    [Fact]
    public void LockedKeys_CannotWriteOrRead()
    {
        var (entry, _) = Store(Harness.Data(100));
        VaultKeys locked = Harness.NewKeys();
        locked.Dispose();   // "Lock USB"

        using var ms = new MemoryStream(Harness.Data(10));
        Assert.Throws<ObjectDisposedException>(() => _blobs.WriteTemp(SecureRandom.NewGuid(), ms, locked, Chunk));
        Assert.Throws<ObjectDisposedException>(() => Read(entry, locked));
    }
}
