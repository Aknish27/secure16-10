using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using SecureUSB.Core;
using SecureUSB.UI.Controls;
using SecureUSB.UI.Converters;
using SecureUSB.UI.Services;
using SecureUSB.UI.Views;
using SecureUSB.ViewModels;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.UI.Tests;

public class ResourceTests
{
    private static HashSet<object> Keys(string path) =>
        WpfHost.Run(() => WpfHost.Load(path).Keys.Cast<object>().ToHashSet());

    [Fact]
    public void LightAndDarkThemes_DefineExactlyTheSameKeys()
    {
        HashSet<object> light = Keys("Themes/Light.xaml");
        HashSet<object> dark = Keys("Themes/Dark.xaml");

        Assert.NotEmpty(light);
        Assert.Empty(light.Except(dark));
        Assert.Empty(dark.Except(light));
    }

    [Fact]
    public void TheStyleAndConverterDictionaries_Load()
    {
        Assert.NotEmpty(Keys("Styles/Controls.xaml"));
        Assert.NotEmpty(Keys("Styles/Converters.xaml"));
    }

    [Theory]
    [InlineData(typeof(WelcomeViewModel))]
    [InlineData(typeof(CreateVaultViewModel))]
    [InlineData(typeof(UnlockViewModel))]
    [InlineData(typeof(DashboardViewModel))]
    [InlineData(typeof(ChangePasswordViewModel))]
    [InlineData(typeof(ActivityLogViewModel))]
    [InlineData(typeof(HealthViewModel))]
    [InlineData(typeof(SettingsViewModel))]
    [InlineData(typeof(ConfirmViewModel))]
    [InlineData(typeof(PromptViewModel))]
    [InlineData(typeof(MessageViewModel))]
    public void EveryViewModel_HasAView(Type viewModel)
    {
        bool found = WpfHost.Run(() => Application.Current.TryFindResource(new DataTemplateKey(viewModel)) is DataTemplate);
        Assert.True(found, $"No DataTemplate for {viewModel.Name}.");
    }

    [Fact]
    public void ApplyingTheDarkTheme_ChangesTheColours()
    {
        Color before = WpfHost.Run(() => ((SolidColorBrush)Application.Current.FindResource("AppBackground")).Color);

        WpfHost.Run(() => new ThemeService().Apply(ThemeKind.Dark));
        Color dark = WpfHost.Run(() => ((SolidColorBrush)Application.Current.FindResource("AppBackground")).Color);
        WpfHost.Run(() => new ThemeService().Apply(ThemeKind.Light));
        Color after = WpfHost.Run(() => ((SolidColorBrush)Application.Current.FindResource("AppBackground")).Color);

        Assert.NotEqual(before, dark);
        Assert.Equal(before, after);
    }
}

public class ViewCreationTests
{
    [Theory]
    [InlineData(typeof(WelcomeView))]
    [InlineData(typeof(CreateVaultView))]
    [InlineData(typeof(UnlockView))]
    [InlineData(typeof(DashboardView))]
    [InlineData(typeof(ChangePasswordView))]
    [InlineData(typeof(ActivityLogView))]
    [InlineData(typeof(HealthView))]
    [InlineData(typeof(SettingsView))]
    [InlineData(typeof(ConfirmView))]
    [InlineData(typeof(PromptView))]
    [InlineData(typeof(MessageView))]
    [InlineData(typeof(PasswordInput))]
    [InlineData(typeof(StrengthMeter))]
    public void EveryView_LoadsItsXamlAndStyles(Type viewType)
    {
        // a missing resource key, a duplicate property or a bad binding syntax fails here
        FrameworkElement view = WpfHost.Run(() =>
        {
            var element = (FrameworkElement)Activator.CreateInstance(viewType)!;
            element.Measure(new Size(800, 600));
            element.Arrange(new Rect(0, 0, 800, 600));
            element.UpdateLayout();
            return element;
        });
        Assert.NotNull(view);
    }
}

public class ConverterAndControlTests
{
    private static byte[] TinyPng()
    {
        BitmapSource source = BitmapSource.Create(2, 2, 96, 96, PixelFormats.Bgra32, null, new byte[16], 8);
        var encoder = new PngBitmapEncoder();
        encoder.Frames.Add(BitmapFrame.Create(source));
        using var ms = new MemoryStream();
        encoder.Save(ms);
        return ms.ToArray();
    }

    [Fact]
    public void InverseBooleanConverters_FlipTheirInput()
    {
        var inverse = new InverseBooleanConverter();
        Assert.Equal(false, inverse.Convert(true, typeof(bool), null!, null!));
        Assert.Equal(true, inverse.Convert(false, typeof(bool), null!, null!));

        var vis = new InverseBooleanToVisibilityConverter();
        Assert.Equal(Visibility.Collapsed, vis.Convert(true, typeof(Visibility), null!, null!));
        Assert.Equal(Visibility.Visible, vis.Convert(false, typeof(Visibility), null!, null!));
    }

    [Fact]
    public void ImageConverter_DecodesRealImages_AndIgnoresEverythingElse()
    {
        var converter = new BytesToImageSourceConverter();
        object? image = WpfHost.Run(() => converter.Convert(TinyPng(), typeof(ImageSource), null!, null!));
        Assert.IsAssignableFrom<BitmapSource>(image);
        Assert.Equal(2, ((BitmapSource)image!).PixelWidth);

        Assert.Null(WpfHost.Run(() => converter.Convert(new byte[] { 1, 2, 3 }, typeof(ImageSource), null!, null!)));
        Assert.Null(WpfHost.Run(() => converter.Convert(Array.Empty<byte>(), typeof(ImageSource), null!, null!)));
        Assert.Null(WpfHost.Run(() => converter.Convert(null!, typeof(ImageSource), null!, null!)));
    }

    [Fact]
    public void PasswordInput_KeepsTheHiddenAndVisibleBoxesInSync()
    {
        WpfHost.Run(() =>
        {
            var input = new PasswordInput();
            var hidden = (PasswordBox)input.FindName("HiddenBox");
            var visible = (TextBox)input.FindName("VisibleBox");

            input.Password = "abc";
            Assert.Equal("abc", hidden.Password);
            Assert.Equal("abc", visible.Text);

            hidden.Password = "typed";
            Assert.Equal("typed", input.Password);

            visible.Text = "edited";
            Assert.Equal("edited", input.Password);
            Assert.Equal("edited", hidden.Password);
        });
    }

    [Fact]
    public void PasswordInput_ShowsThePlainTextOnlyWhenAsked()
    {
        WpfHost.Run(() =>
        {
            var input = new PasswordInput();
            var hidden = (PasswordBox)input.FindName("HiddenBox");
            var visible = (TextBox)input.FindName("VisibleBox");

            Assert.Equal(Visibility.Visible, hidden.Visibility);
            Assert.Equal(Visibility.Collapsed, visible.Visibility);

            input.IsPasswordVisible = true;
            Assert.Equal(Visibility.Collapsed, hidden.Visibility);
            Assert.Equal(Visibility.Visible, visible.Visibility);

            input.IsPasswordVisible = false;
            Assert.Equal(Visibility.Visible, hidden.Visibility);
        });
    }
}

public class MainWindowTests
{
    private sealed class NoFactory : IVaultServiceFactory
    {
        public VaultService Create(VaultLocation location) => throw new NotSupportedException();
    }

    private sealed class NoDrives : ILocationProvider
    {
        public IReadOnlyList<VaultLocation> Discover() => Array.Empty<VaultLocation>();
        public VaultLocation FromFolder(string root) => new(root, "x", "x", false, false, false);
    }

    private sealed class NoFiles : IFileDialogService
    {
        public IReadOnlyList<string> PickFiles(string title) => Array.Empty<string>();
        public string? PickFolder(string title) => null;
    }

    private sealed class NoLauncher : IShellLauncher
    {
        public void OpenFile(string path) { }
    }

    private sealed class InlineUi : IUiScheduler
    {
        public void Post(Action action) => action();
        public IDisposable Every(TimeSpan interval, Action tick) => new Nothing();
        private sealed class Nothing : IDisposable { public void Dispose() { } }
    }

    private sealed class NoTheme : IThemeService
    {
        public void Apply(ThemeKind theme) { }
    }

    private static ShellViewModel NewShell() => new(new ShellServices
    {
        Factory = new NoFactory(), Locations = new NoDrives(), Modals = new ModalHost(), Files = new NoFiles(),
        Launcher = new NoLauncher(), Ui = new InlineUi(), Theme = new NoTheme(), App = new AppInfo("SecureUSB", "0.0.0-test")
    });

    private static T? FindDescendant<T>(DependencyObject root) where T : DependencyObject
    {
        for (int i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
        {
            DependencyObject child = VisualTreeHelper.GetChild(root, i);
            if (child is T match) return match;
            T? deeper = FindDescendant<T>(child);
            if (deeper is not null) return deeper;
        }
        return null;
    }

    private static void Layout(Window window)
    {
        window.Measure(new Size(1200, 800));
        window.Arrange(new Rect(0, 0, 1200, 800));
        window.UpdateLayout();
    }

    [Fact]
    public void TheWindow_ShowsTheWelcomePage_ThroughItsViewTemplate()
    {
        WpfHost.Run(() =>
        {
            ShellViewModel shell = NewShell();
            shell.Initialize();
            var window = new MainWindow(shell);
            Layout(window);

            Assert.NotNull(FindDescendant<WelcomeView>(window));
            shell.Dispose();
        });
    }

    [Fact]
    public async Task ADialog_AppearsOverTheWindow_AndGoesAway()
    {
        ShellViewModel shell = NewShell();
        Task shown = WpfHost.Run(() =>
        {
            shell.Initialize();
            var window = new MainWindow(shell);
            Layout(window);
            Task t = shell.Modals.ShowModalAsync(new MessageViewModel("Title", "Body", MessageKind.Warning));
            Layout(window);
            Assert.NotNull(FindDescendant<MessageView>(window));
            return t;
        });

        WpfHost.Run(() => shell.Modals.Current!.RequestClose());
        await shown;
        Assert.False(WpfHost.Run(() => shell.Modals.IsOpen));
        WpfHost.Run(() => shell.Dispose());
    }
}
