using System.Windows;
using System.Windows.Threading;

namespace SecureUSB.UI.Tests;

/// <summary>One long-lived STA thread with a WPF Application and the same resource dictionaries as App.xaml.</summary>
internal static class WpfHost
{
    private static readonly object Gate = new();
    private static Dispatcher? _dispatcher;
    private static Exception? _startupError;

    private static void EnsureStarted()
    {
        lock (Gate)
        {
            if (_dispatcher is not null) return;
            using var ready = new ManualResetEventSlim();
            var thread = new Thread(() =>
            {
                try
                {
                    var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
                    foreach (string path in new[] { "Themes/Light.xaml", "Styles/Converters.xaml", "Styles/Controls.xaml", "Views/ViewTemplates.xaml" })
                        app.Resources.MergedDictionaries.Add(Load(path));
                }
                catch (Exception ex)
                {
                    _startupError = ex;
                }
                _dispatcher = Dispatcher.CurrentDispatcher;
                ready.Set();
                Dispatcher.Run();
            }) { IsBackground = true, Name = "WPF test host" };
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            ready.Wait();
        }
    }

    public static ResourceDictionary Load(string path) =>
        new() { Source = new Uri($"pack://application:,,,/SecureUSB.UI;component/{path}", UriKind.Absolute) };

    public static T Run<T>(Func<T> work)
    {
        EnsureStarted();
        if (_startupError is not null) throw new InvalidOperationException("The application resources failed to load: " + _startupError, _startupError);
        return _dispatcher!.Invoke(work);
    }

    public static void Run(Action work) => Run<int>(() => { work(); return 0; });
}
