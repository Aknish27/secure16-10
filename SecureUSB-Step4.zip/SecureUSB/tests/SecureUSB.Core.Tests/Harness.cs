using SecureUSB.Cryptography;
using SecureUSB.Models;
using SecureUSB.Security;
using SecureUSB.Storage;

namespace SecureUSB.Core.Tests;

internal sealed class FakeDrive : IDriveInfoService
{
    public long Total = 32L << 30;
    public long Free = 20L << 30;
    public string FileSystem = "exFAT";
    public bool Available = true;

    public DriveCapacity GetCapacity(string path)
    {
        if (!Available) throw new IOException("Simulated: the USB drive was removed.");
        return new DriveCapacity("E:\\", "TESTUSB", FileSystem, DriveType.Removable, Total, Free);
    }

    public bool IsAvailable(string path) => Available;
}

internal sealed class FixedTime : TimeProvider
{
    public DateTimeOffset Now = new(2026, 1, 1, 12, 0, 0, TimeSpan.Zero);
    public override DateTimeOffset GetUtcNow() => Now;
    public void Advance(TimeSpan span) => Now += span;
}

internal sealed class SyncProgress<T> : IProgress<T>
{
    private readonly Action<T> _action;
    public SyncProgress(Action<T> action) => _action = action;
    public void Report(T value) => _action(value);
}

internal sealed class TempVault : IDisposable
{
    public string Root { get; } = Path.Combine(Path.GetTempPath(), "secureusb-core-tests-" + Guid.NewGuid().ToString("N"));
    public VaultPaths Paths { get; }
    public FakeDrive Drive { get; } = new();
    public FixedTime Time { get; } = new();

    public TempVault()
    {
        Directory.CreateDirectory(Root);
        Paths = new VaultPaths(Path.Combine(Root, VaultPaths.DataFolderName));
    }

    public string NewSubfolder(string name)
    {
        string p = Path.Combine(Root, name);
        Directory.CreateDirectory(p);
        return p;
    }

    public void Dispose()
    {
        try { Directory.Delete(Root, recursive: true); } catch { /* best effort */ }
    }
}

internal static class Harness
{
    public const string P1 = "correct horse battery staple";
    public const string P2 = "tulip granite harbor violin mosaic";
    public const string P3 = "quantum lantern orchid velvet meadow";
    public const string Wrong = "this is definitely the wrong password";

    public static readonly KdfParams FastKdf = new(KdfParams.MinMemoryKiB, 1, 1);

    public static byte[] Data(int length, int seed = 1)
    {
        var data = new byte[length];
        new Random(seed).NextBytes(data);
        return data;
    }

    public static VaultKeys NewKeys() => VaultKeyManager.CreateVault(P1, FastKdf).Keys;

    public static void FlipByte(string path, int offset)
    {
        byte[] b = File.ReadAllBytes(path);
        b[offset] ^= 0x01;
        File.WriteAllBytes(path, b);
    }
}

/// <summary>A scratch USB drive plus a VaultService wired to it (fast KDF, no background polling).</summary>
internal sealed class ServiceFixture : IDisposable
{
    private readonly List<VaultService> _services = new();

    public TempVault T { get; } = new();
    public string TempRoot { get; }
    public VaultService Service { get; }

    public ServiceFixture(TimeSpan? pollInterval = null)
    {
        TempRoot = T.NewSubfolder("hostTemp");
        Service = Create(pollInterval);
    }

    public VaultService Create(TimeSpan? pollInterval = null)
    {
        var service = new VaultService(new VaultServiceOptions
        {
            Paths = T.Paths,
            Drive = T.Drive,
            TempRoot = TempRoot,
            Time = T.Time,
            Kdf = Harness.FastKdf,
            UsbPollInterval = pollInterval ?? TimeSpan.Zero,
            LockDrainTimeout = TimeSpan.FromMilliseconds(300),
            ApplicationPaths = new[] { Path.Combine(T.Root, "SecureUSB.exe") }
        });
        _services.Add(service);
        return service;
    }

    /// <summary>Creates the vault with password P1; the service is left unlocked.</summary>
    public VaultService Unlocked()
    {
        Service.CreateVault(Harness.P1, Harness.P1);
        return Service;
    }

    public string Source(string name, byte[]? data = null)
    {
        string dir = T.NewSubfolder("src");
        string path = Path.Combine(dir, name);
        File.WriteAllBytes(path, data ?? Harness.Data(1000));
        return path;
    }

    public void Dispose()
    {
        for (int i = _services.Count - 1; i >= 0; i--) _services[i].Dispose();
        T.Dispose();
    }
}
