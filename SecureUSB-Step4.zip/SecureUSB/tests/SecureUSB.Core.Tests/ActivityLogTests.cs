using System.Buffers.Binary;
using System.Text;
using SecureUSB.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Core.Tests;

public class ActivityLogTests : IDisposable
{
    private readonly TempVault _t = new();
    private readonly VaultKeys _keys = Harness.NewKeys();

    public ActivityLogTests() => _t.Paths.EnsureDirectories();

    public void Dispose()
    {
        _keys.Dispose();
        _t.Dispose();
    }

    private ActivityLog NewLog(VaultKeys? keys = null, long maxBytes = ActivityLog.DefaultMaxFileBytes, int keep = ActivityLog.DefaultKeepAfterCompaction) =>
        new(_t.Paths, keys ?? _keys, _t.Time, maxBytes, keep);

    private string LogPath => _t.Paths.LogPath;

    /// <summary>(start offset, total bytes) of every record in the file.</summary>
    private static List<(int Start, int Length)> Records(byte[] file)
    {
        var list = new List<(int, int)>();
        int pos = 8;
        while (pos + 4 <= file.Length)
        {
            int len = (int)BinaryPrimitives.ReadUInt32BigEndian(file.AsSpan(pos, 4));
            if (pos + 4 + len > file.Length) break;
            list.Add((pos, 4 + len));
            pos += 4 + len;
        }
        return list;
    }

    private void AppendThree()
    {
        ActivityLog log = NewLog();
        log.Append(ActivityKind.VaultCreated, "one");
        _t.Time.Advance(TimeSpan.FromMinutes(1));
        log.Append(ActivityKind.FileAdded, "two");
        _t.Time.Advance(TimeSpan.FromMinutes(1));
        log.Append(ActivityKind.FileDeleted, "three");
    }

    [Fact]
    public void AppendThenRead_ReturnsEventsInOrder()
    {
        AppendThree();
        ActivityLogReadResult r = NewLog().Read();

        Assert.False(r.TamperDetected);
        Assert.False(r.TornTail);
        Assert.Equal(new[] { "one", "two", "three" }, r.Events.Select(e => e.Message).ToArray());
        Assert.Equal(new[] { ActivityKind.VaultCreated, ActivityKind.FileAdded, ActivityKind.FileDeleted }, r.Events.Select(e => e.Kind).ToArray());
        Assert.True(r.Events[2].TimestampUtc > r.Events[0].TimestampUtc);
    }

    [Fact]
    public void MissingFile_ReadsAsEmpty()
    {
        ActivityLogReadResult r = NewLog().Read();
        Assert.Empty(r.Events);
        Assert.False(r.TamperDetected);
    }

    [Fact]
    public void LogFile_ContainsNoReadableText()
    {
        NewLog().Append(ActivityKind.FileAdded, "Added file 'TopSecretProject.docx'");
        byte[] file = File.ReadAllBytes(LogPath);

        foreach (string needle in new[] { "TopSecretProject", "Added file" })
        {
            Assert.True(file.AsSpan().IndexOf(Encoding.ASCII.GetBytes(needle)) < 0);
            Assert.True(file.AsSpan().IndexOf(Encoding.Unicode.GetBytes(needle)) < 0);
        }
    }

    [Fact]
    public void ContinuesNumbering_AfterReopen()
    {
        AppendThree();
        NewLog().Append(ActivityKind.Warning, "four");   // a new instance, as after a restart

        ActivityLogReadResult r = NewLog().Read();
        Assert.False(r.TamperDetected);
        Assert.Equal(4, r.Events.Count);
        Assert.Equal("four", r.Events[3].Message);
    }

    [Fact]
    public void HalfWrittenLastRecord_IsDetected_AndRepairedOnNextAppend()
    {
        AppendThree();
        byte[] file = File.ReadAllBytes(LogPath);
        File.WriteAllBytes(LogPath, file.AsSpan(0, file.Length - 5).ToArray());   // power loss during the last write

        ActivityLogReadResult torn = NewLog().Read();
        Assert.True(torn.TornTail);
        Assert.False(torn.TamperDetected);
        Assert.Equal(2, torn.Events.Count);

        NewLog().Append(ActivityKind.Warning, "after crash");
        ActivityLogReadResult healed = NewLog().Read();
        Assert.False(healed.TornTail);
        Assert.False(healed.TamperDetected);
        Assert.Equal(new[] { "one", "two", "after crash" }, healed.Events.Select(e => e.Message).ToArray());
    }

    [Fact]
    public void CutInsideTheLengthPrefix_IsATornTail()
    {
        AppendThree();
        byte[] file = File.ReadAllBytes(LogPath);
        var recs = Records(file);
        File.WriteAllBytes(LogPath, file.AsSpan(0, recs[1].Start + recs[1].Length + 2).ToArray());

        ActivityLogReadResult r = NewLog().Read();
        Assert.True(r.TornTail);
        Assert.Equal(2, r.Events.Count);
    }

    [Fact]
    public void ModifiedRecord_IsDetected()
    {
        AppendThree();
        byte[] file = File.ReadAllBytes(LogPath);
        var recs = Records(file);
        file[recs[1].Start + 4 + 20] ^= 0x01;
        File.WriteAllBytes(LogPath, file);

        ActivityLogReadResult r = NewLog().Read();
        Assert.True(r.TamperDetected);
        Assert.Equal(new[] { "one" }, r.Events.Select(e => e.Message).ToArray());
    }

    [Fact]
    public void RemovedMiddleRecord_IsDetected()
    {
        AppendThree();
        byte[] file = File.ReadAllBytes(LogPath);
        var recs = Records(file);
        byte[] forged = file.Take(recs[1].Start).Concat(file.Skip(recs[2].Start)).ToArray();
        File.WriteAllBytes(LogPath, forged);

        ActivityLogReadResult r = NewLog().Read();
        Assert.True(r.TamperDetected);
        Assert.Equal(1, r.Events.Count);
    }

    [Fact]
    public void ReorderedRecords_AreDetected()
    {
        AppendThree();
        byte[] file = File.ReadAllBytes(LogPath);
        var recs = Records(file);
        byte[] forged = file.Take(recs[1].Start)
            .Concat(file.Skip(recs[2].Start).Take(recs[2].Length))
            .Concat(file.Skip(recs[1].Start).Take(recs[1].Length))
            .ToArray();
        File.WriteAllBytes(LogPath, forged);

        ActivityLogReadResult r = NewLog().Read();
        Assert.True(r.TamperDetected);
        Assert.Equal(1, r.Events.Count);
    }

    [Fact]
    public void DuplicatedRecord_IsDetected()
    {
        AppendThree();
        byte[] file = File.ReadAllBytes(LogPath);
        var recs = Records(file);
        byte[] forged = file.Take(recs[0].Start + recs[0].Length)
            .Concat(file.Skip(recs[0].Start).Take(recs[0].Length))
            .ToArray();
        File.WriteAllBytes(LogPath, forged);

        ActivityLogReadResult r = NewLog().Read();
        Assert.True(r.TamperDetected);
        Assert.Equal(1, r.Events.Count);
    }

    [Fact]
    public void LogOfAnotherVault_CannotBeRead()
    {
        AppendThree();
        using VaultKeys other = Harness.NewKeys();
        ActivityLogReadResult r = NewLog(other).Read();
        Assert.True(r.TamperDetected);
        Assert.Empty(r.Events);
    }

    [Fact]
    public void NotALogFile_IsTamper()
    {
        File.WriteAllBytes(LogPath, Harness.Data(100));
        Assert.True(NewLog().Read().TamperDetected);
    }

    [Fact]
    public void DamagedLog_IsSetAside_AndANewLogStarts()
    {
        AppendThree();
        Harness.FlipByte(LogPath, 30);

        NewLog().Append(ActivityKind.Warning, "fresh start");

        Assert.True(File.Exists(LogPath + ".damaged"));
        ActivityLogReadResult r = NewLog().Read();
        Assert.False(r.TamperDetected);
        Assert.Equal(2, r.Events.Count);
        Assert.Contains("set aside", r.Events[0].Message);
        Assert.Equal("fresh start", r.Events[1].Message);
    }

    [Fact]
    public void BigLog_IsCompacted_KeepingTheNewestEvents()
    {
        ActivityLog log = NewLog(maxBytes: 3000, keep: 5);
        for (int i = 0; i < 40; i++) log.Append(ActivityKind.FileAdded, $"event {i}");

        ActivityLogReadResult r = NewLog(maxBytes: 3000, keep: 5).Read();
        Assert.False(r.TamperDetected);
        Assert.True(r.Events.Count < 40);
        Assert.Contains(r.Events, e => e.Message == "event 39");   // the newest event always survives compaction
        Assert.Contains(r.Events, e => e.Message.Contains("compacted"));
        Assert.True(new FileInfo(LogPath).Length < 6000);

        log.Append(ActivityKind.Warning, "still appendable");   // numbering stayed consistent
        Assert.False(NewLog().Read().TamperDetected);
    }

    [Fact]
    public void LongMessages_AreTruncated_AndUnicodeSurvives()
    {
        ActivityLog log = NewLog();
        log.Append(ActivityKind.Warning, new string('x', 5000));
        log.Append(ActivityKind.Warning, "\u65E5\u672C\u8A9E \u00FC\u00F1\u00EE \U0001F600");

        ActivityLogReadResult r = NewLog().Read();
        Assert.Equal(ActivityLog.MaxMessageLength, r.Events[0].Message.Length);
        Assert.Equal("\u65E5\u672C\u8A9E \u00FC\u00F1\u00EE \U0001F600", r.Events[1].Message);
    }

    [Fact]
    public void ParallelAppends_AreAllRecorded()
    {
        ActivityLog log = NewLog();
        Parallel.For(0, 50, new ParallelOptions { MaxDegreeOfParallelism = 8 }, i => log.Append(ActivityKind.FileAdded, $"item {i}"));

        ActivityLogReadResult r = NewLog().Read();
        Assert.False(r.TamperDetected);
        Assert.Equal(50, r.Events.Count);
        Assert.Equal(50, r.Events.Select(e => e.Message).Distinct().Count());
    }
}
