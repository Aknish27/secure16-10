# Step 2 — Storage design (V1: one password, no key file)

Storage never sees a password. After Core unlocks the vault it hands `VaultRepository` the unlocked `VaultKeys`;
disposing those keys is "locking".

## On-disk layout of `SecureUSB_Data/`
| Path | Content | Readable in Explorer? |
|---|---|---|
| `vault.hdr`, `vault.hdr.bak` | 131-byte header (salt, Argon2 cost, wrapped master key) | opaque binary |
| `index.sdb`, `index.sdb.prev` | encrypted file index (names, sizes, folders, dates), padded to 4 KiB buckets | opaque |
| `blobs/{32 hex}.blob` | one encrypted file each, random names | opaque |
| `*.tmp` | in-flight replacement of the file with the same base name | transient |
| `vault.lock` | held open exclusively while the vault is in use (second app instance gets an error) | empty |

File names, folders, dates and the exact file count never appear in plaintext. File *sizes* are visible
approximately (ciphertext length = plaintext + 20 + 86 + 16 per MiB), and file-system timestamps of the blobs are visible.

## Write protocols (why an interruption cannot lose or expose data)
**Header (password change)** — `Commit`:
1. write `vault.hdr.tmp`, flush to device, read back and compare
2. move it over `vault.hdr`
3. rewrite `vault.hdr.bak` with the same bytes

`Load` uses the first *structurally valid* copy in the order primary → tmp → backup. It does **not** fall back to
another copy just because the password failed, otherwise a stale backup would keep the OLD password working.
Bit-rot inside the wrapped key looks exactly like a wrong password, so the UI (Step 4) offers an explicit,
user-confirmed "recover from backup header" that calls `TryReadBackup`. After any successful unlock, `Heal` makes
primary and backup identical and removes leftovers.

**Index** — `Save`: write `index.sdb.tmp` (flushed) → move `index.sdb` to `index.sdb.prev` → move tmp to `index.sdb`.
`Load` decrypts all three candidates and takes the **highest authenticated revision**, so a crash between any two
steps is recoverable; `Heal` then restores the canonical state. The revision is authenticated (it is part of the AES-GCM
associated data), so an old file cannot be relabelled as newer.

**Add file**: encrypt to `blobs/{id}.blob.tmp` → flush → rename to `.blob` → commit index.
A crash before the commit leaves an *orphan* blob (found and optionally recovered by the scanner), never a dangling index entry.
If the index save fails, the new blob is deleted unless a pending index copy may already reference it.
**Delete**: commit the index without the entry first, then delete the blob. **Rename**: index only.
The in-memory index is replaced only after the new index is safely on disk (copy-on-write), so a failed save changes nothing.

**Export**: decrypt to `name.{guid}.part`, flush, rename. On any failure (tampering, USB removal, cancellation) the
partial plaintext is zero-overwritten and deleted. "Open in memory" (`ReadAllBytes`) never writes plaintext to disk.

## Self-describing blobs
Each blob header carries the file ID and the wrapped file key, so if **every** index copy is lost the data is still
recoverable by someone who can unlock the vault: `VaultRepository.RebuildIndexFromBlobs` authenticates each blob's key
and creates generic entries `Recovered/Recovered-xxxx.bin`. Original names, folders and dates are *not* recoverable.
Blobs of another vault are ignored.

## Integrity scanner
* **Shallow** (no key needed, fast): header copies, leftover temp files, every blob exists with the exact expected size,
  orphan blobs, unexpected files.
* **Deep** (needs the unlocked keys, slow): additionally authenticates every chunk of every file.
* **Repair** is a separate explicit step with options: delete stale temp files (default), keep/delete/recover orphans
  (default keep), remove index entries whose blob is missing (default **no**), re-sync the backup header.
  Repair only deletes files inside the vault's data directory, and never touches unexpected foreign files.

## Drive capacity
`SystemDriveInfoService` asks the OS (`DriveInfo`) for the real total/free bytes, file system and drive type.
`StorageUsage` reports four separate numbers: physical capacity, SecureUSB vault bytes, application bytes
(`SecureUSB.exe`, `SecureUSB_App\`), and "other" (everything else on the stick). The vault is never reported as the whole drive.
`FAT32`/`FAT` drives cannot store a single file of 4 GiB or more; this is detected *before* encrypting
(`FileTooLargeException`), as is insufficient free space (`InsufficientSpaceException`, 8 MiB reserved for metadata).

## Input validation
* Names are display data only, but are validated (`EntryNames`): no path separators, `..`, control characters,
  invisible/bidi formatting characters (extension spoofing), reserved device names (`CON`, `NUL`, ...), trailing dots/spaces, >255 chars.
* Folder paths: `/`-separated, same rules per segment, depth ≤ 32.
* Files added from disk must exist, must not be links/junctions (reparse points), and must be files; folder import skips links.
* The decrypted index is re-validated (duplicate IDs/names, bad sizes, traversal names) even after it authenticates.
* Index file size is capped (64 MiB) before reading; header files must be exactly 131 bytes.

## Limitations (read these)
* **Password change does not revoke old copies.** It re-wraps the same master key. Anyone who copied the drive *before*
  the change and knows the *old* password can still open that old copy. If a password may have been exposed, the data
  must be re-encrypted under a new master key (a "rekey" feature is not in V1). Old header bytes may also physically remain in flash blocks.
* **Rollback is undetectable**: replacing the whole vault with an older consistent snapshot cannot be detected without trusted external state.
* **Deleting is not shredding**: deleted blobs are only ciphertext (safe without the key), but flash wear-levelling keeps old blocks; wiping
  of plaintext temp files is best-effort.
* **FAT32/exFAT are not atomic file systems** and the directory entry is not fsynced from .NET: the recovery logic above covers the
  non-atomic replace gap, but a power loss can still lose the most recent change (never corrupt older data).
* An attacker with write access to the drive can delete or destroy files (denial of service); this layer detects, it cannot prevent.
* Sizes and timestamps of blobs leak roughly how much and when you stored.
* Capacity on Linux/macOS reports the volume containing the path as seen by .NET; the product target is Windows.

## Not in Step 2 (Step 3)
Failed-attempt counter and delay, filename sanitizer for user input, temp-file manager for "open externally", activity log,
VaultService (unlock → heal header → open repository), USB-removal monitor (the storage layer already fails cleanly and leaves a recoverable state).
