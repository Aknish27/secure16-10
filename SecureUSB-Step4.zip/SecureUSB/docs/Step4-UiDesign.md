# Step 4 - User interface (V1: one password, no key file, no 2FA)

## Architecture
`UI (WPF) -> ViewModels -> Core (VaultService) -> Security/Storage -> Cryptography -> Models`
* **SecureUSB.ViewModels** (plain `net8.0`, no WPF): all behaviour. It calls only `VaultService`; there is no cryptography or storage logic in the UI layers. Hand-written MVVM base (observable object, relay/async commands), manual constructor injection (no container needed).
* **SecureUSB.UI** (WPF): Views, themes (Light/Dark), styles, converters, and thin Windows adapters (file dialogs, dispatcher, drive discovery, shell launch). Dialogs are in-window overlays (testable, keyboard-contained), not separate windows.

## Screens
Welcome / drive chooser -> Create vault -> Unlock -> Dashboard, plus dialogs: change password, activity log, health (quick/full check + repair), settings and about, confirmations, rename prompt, messages.
If the drive SecureUSB runs from already holds a vault, the app opens straight on the unlock screen (USB -> open -> ONE password -> unlock).

## Security behaviour of the UI
* Passwords are hidden unless the user presses Show; they are cleared from view-models after success and when leaving a page. Messages never contain the password. (Limit: .NET strings cannot be wiped from memory.)
* Wrong password: counter and progressive cooldown come from Core (`AttemptGuard`); the button is disabled during the cooldown with a live countdown; the delay survives restarts.
* Lock (button, Ctrl+L, auto-lock after idle, USB removal, exit) always goes through `VaultService.Lock`; the single `Locked` event makes the shell empty the unlocked screens (file list, preview bytes zeroed), close dialogs that show vault data, and show the unlock page with a plain explanation. USB removal is detected within 500 ms by the Core monitor.
* **No plaintext copies by default.** Previews (text, images) are decrypted in memory only and zeroed when the selection changes. "Open in another program" is OFF by default, needs an informed yes, and the temporary path is never displayed. Export always warns that the copy is unprotected (stronger warning on the same drive), never overwrites existing files, and goes through Core's sanitized export.
* Error messages are mapped by `ErrorMessages`: only SecureUSB's own sentences pass through; host paths, file names from the OS and exception text never reach the screen.
* Destructive actions (delete, destructive repair) use a confirmation whose default button is the safe one. Long operations show a progress overlay with Cancel; locking cancels them.
* Auto-lock never interrupts a running import/export. Settings are per-run only; nothing is saved to the PC.

## Keyboard
Ctrl+O add files, Ctrl+Shift+O add folder, Ctrl+E export, Ctrl+L lock, Ctrl+F search, F5 refresh, Alt+Up / Backspace up a folder, Enter open folder / selected file, F2 rename, Del delete (in the file list), Esc closes the dialog. Dialogs trap Tab focus; controls have screen-reader names.

## Known limitations of Step 4
* Written without a compiler or Windows: expect small build/XAML fixes on the first run. The UI tests exist to find exactly those.
* Folders cannot be renamed (Core has no folder-rename API); empty folders are not stored.
* Edits to a temporary copy are not saved back into the vault.
* Theme/auto-lock/preview choices are not remembered between runs.
* No inactivity prompt before auto-lock; no WM_DEVICECHANGE hook (the 500 ms poll is used).
* Icons use the built-in Segoe MDL2 Assets font (Windows 10/11); on other systems they show placeholder boxes.
* The launcher (`SecureUSB.exe`), self-contained publish and the user manual are Step 5.
