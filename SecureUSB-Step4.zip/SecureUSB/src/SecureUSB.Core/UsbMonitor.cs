using SecureUSB.Storage;

namespace SecureUSB.Core;

/// <summary>
/// Detects that the USB drive holding the vault has gone away. The drive counts as present only if the
/// OS reports the volume as ready, the vault folder exists, AND this process's vault.lock file is still there
/// (so a different stick inserted under the same drive letter is also treated as "removed").
/// The event fires once. Polling is used because it works without a window handle; the UI may additionally
/// call <see cref="CheckNow"/> from a WM_DEVICECHANGE handler for an instant reaction.
/// </summary>
public sealed class UsbMonitor : IDisposable
{
    private readonly IDriveInfoService _drive;
    private readonly VaultPaths _paths;
    private readonly int _failuresRequired;
    private Timer? _timer;
    private int _consecutiveFailures;
    private int _removed;
    private int _checking;
    private volatile bool _disposed;

    public UsbMonitor(IDriveInfoService drive, VaultPaths paths, int consecutiveFailuresRequired = 1)
    {
        _drive = drive ?? throw new ArgumentNullException(nameof(drive));
        _paths = paths ?? throw new ArgumentNullException(nameof(paths));
        _failuresRequired = Math.Max(1, consecutiveFailuresRequired);
    }

    /// <summary>Raised at most once, possibly on a timer thread.</summary>
    public event EventHandler? DriveRemoved;

    public bool IsRemoved => Volatile.Read(ref _removed) == 1;

    public void Start(TimeSpan interval)
    {
        if (interval <= TimeSpan.Zero) throw new ArgumentOutOfRangeException(nameof(interval));
        _timer = new Timer(_ => CheckNow(), null, interval, interval);
    }

    /// <returns>true if the drive is present.</returns>
    public bool CheckNow()
    {
        if (_disposed) return true;
        if (Interlocked.Exchange(ref _checking, 1) == 1) return !IsRemoved;   // a check is already running

        try
        {
            if (Probe())
            {
                Volatile.Write(ref _consecutiveFailures, 0);
                return true;
            }

            int failures = Interlocked.Increment(ref _consecutiveFailures);
            if (failures >= _failuresRequired && Interlocked.Exchange(ref _removed, 1) == 0)
            {
                try { DriveRemoved?.Invoke(this, EventArgs.Empty); }
                catch { /* a faulty handler must never kill the monitor thread */ }
            }
            return false;
        }
        finally
        {
            Volatile.Write(ref _checking, 0);
        }
    }

    private bool Probe()
    {
        try
        {
            return _drive.IsAvailable(_paths.DataDirectory)
                   && Directory.Exists(_paths.DataDirectory)
                   && File.Exists(_paths.LockPath);
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException)
        {
            return false;
        }
    }

    public void Dispose()
    {
        _disposed = true;
        _timer?.Dispose();
        _timer = null;
    }
}
