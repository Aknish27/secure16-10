using System.Security.Cryptography;
using SecureUSB.Cryptography;
using SecureUSB.Models;
using SecureUSB.Security;
using SecureUSB.Storage;

namespace SecureUSB.Core;

public enum VaultState { NotInitialized = 0, Locked = 1, Unlocked = 2 }

public enum LockReason { User, UsbRemoved, Shutdown }

public enum UnlockStatus
{
    Success,
    // Wrong password OR a damaged/tampered header: cryptographically indistinguishable.
    WrongPasswordOrDamagedVault,
    // Too many recent failures: the attempt was refused without checking the password.
    LockedOut,
    PasswordRequired,
    VaultNotInitialized,
    HeaderUnreadable,
    // The password was right, but the file index is damaged. Offer RebuildIndexAndUnlock.
    IndexDamaged,
    // Another SecureUSB process has this vault open.
    VaultInUse,
    UsbUnavailable,
    StorageError
}

public sealed record UnlockResult(
    UnlockStatus Status,
    int FailedAttempts = 0,
    TimeSpan RetryAfter = default,
    string Message = "",
    // true when a different, valid backup header exists: offer UnlockUsingBackupHeader.
    bool BackupHeaderAvailable = false)
{
    public bool Succeeded => Status == UnlockStatus.Success;
}

public enum ChangePasswordStatus { Success, WrongCurrentPassword, LockedOut }

public sealed record ChangePasswordResult(ChangePasswordStatus Status, TimeSpan RetryAfter = default)
{
    public bool Succeeded => Status == ChangePasswordStatus.Success;
}

public sealed class VaultLockedEventArgs : EventArgs
{
    public VaultLockedEventArgs(LockReason reason, CleanupReport tempCleanup)
    {
        Reason = reason;
        TempCleanup = tempCleanup;
    }

    public LockReason Reason { get; }

    /// <summary>If not complete, some decrypted temporary files are still open in another program: warn the user.</summary>
    public CleanupReport TempCleanup { get; }
}

public sealed class VaultLockedException : InvalidOperationException
{
    public VaultLockedException(string message = "The vault is locked.") : base(message) { }
}

public sealed class PasswordRejectedException : Exception
{
    public PasswordRejectedException(IReadOnlyList<string> issues) : base(string.Join(" ", issues)) => Issues = issues;
    public IReadOnlyList<string> Issues { get; }
}

public sealed class VaultServiceOptions
{
    public required VaultPaths Paths { get; init; }
    public required IDriveInfoService Drive { get; init; }
    /// <summary>Folder for decrypted temporary copies. Recommended: a folder under the host PC's temp directory.</summary>
    public required string TempRoot { get; init; }

    public TimeProvider Time { get; init; } = TimeProvider.System;
    public KdfParams Kdf { get; init; } = KdfParams.Default;
    public AttemptPolicy AttemptPolicy { get; init; } = new();
    /// <summary>SecureUSB.exe, SecureUSB_App\ ... (counted as "application files" in the storage display).</summary>
    public IReadOnlyList<string> ApplicationPaths { get; init; } = Array.Empty<string>();
    /// <summary>Zero disables automatic polling (tests / UIs that call <see cref="VaultService.CheckUsbNow"/> themselves).</summary>
    public TimeSpan UsbPollInterval { get; init; } = TimeSpan.FromMilliseconds(500);
    /// <summary>How long Lock waits for running operations to stop before it wipes the keys anyway.</summary>
    public TimeSpan LockDrainTimeout { get; init; } = TimeSpan.FromSeconds(3);
}

/// <summary>
/// The application's brain: ONE password in, a usable vault out.
///
///   NotInitialized --CreateVault--> Unlocked --Lock / USB removed--> Locked --Unlock--> Unlocked
///
/// Everything the UI does goes through here. The service enforces the attempt delays, validates every name and
/// path, keeps decrypted temporary files under control, writes the activity log, and when the USB drive disappears
/// it locks immediately: running operations are cancelled, temporary plaintext is wiped, and all keys are zeroed.
/// Methods are synchronous and may take seconds (Argon2id, large files): call them from a background task.
/// </summary>
public sealed class VaultService : IDisposable
{
    private enum UnlockMode { Normal, Backup, Rebuild }

    private sealed class Session
    {
        public required VaultRepository Repo { get; init; }
        public required VaultKeys Keys { get; init; }
        public required ActivityLog Log { get; init; }
        public required UsbMonitor Monitor { get; init; }
        public required CancellationTokenSource Cts { get; init; }
        public int ActiveOperations;
    }

    private readonly VaultServiceOptions _options;
    private readonly VaultHeaderStore _headerStore;
    private readonly AttemptGuard _guard;
    private readonly TempFileManager _temp;
    private readonly object _gate = new();
    private readonly Queue<string> _pendingNotices = new();
    private Session? _session;
    private VaultState _state;
    private bool _unlockInProgress;
    private bool _disposed;
    private int _logWriteFailures;

    public VaultService(VaultServiceOptions options)
    {
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _headerStore = new VaultHeaderStore(options.Paths);
        _guard = new AttemptGuard(options.Paths.GuardPath, options.Time, options.AttemptPolicy);

        // remove decrypted leftovers of crashed/killed earlier runs BEFORE this run creates its own session
        CleanupReport stale = TempFileManager.SweepStale(options.TempRoot);
        StaleTempFilesCleanedAtStartup = stale.Deleted;
        _temp = new TempFileManager(options.TempRoot);

        _state = _headerStore.Exists ? VaultState.Locked : VaultState.NotInitialized;
    }

    public event EventHandler<VaultLockedEventArgs>? Locked;

    public int StaleTempFilesCleanedAtStartup { get; }

    /// <summary>Number of times writing to the activity log failed (e.g. drive trouble).</summary>
    public int LogWriteFailures => Volatile.Read(ref _logWriteFailures);

    public VaultState State
    {
        get
        {
            lock (_gate)
            {
                if (_state == VaultState.NotInitialized && !_disposed && _headerStore.Exists) _state = VaultState.Locked;
                return _state;
            }
        }
    }

    public bool IsUnlocked => State == VaultState.Unlocked;

    public Guid? VaultId
    {
        get { lock (_gate) return _session?.Keys.VaultId; }
    }

    public AttemptStatus GetLoginStatus() => _guard.GetStatus();

    // ================================================================== create

    /// <summary>First-time setup: validates the password, creates the vault and leaves it unlocked.</summary>
    /// <exception cref="PasswordRejectedException">Mismatch or too weak (the issues explain why).</exception>
    public void CreateVault(string password, string confirmation, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(password);
        ArgumentNullException.ThrowIfNull(confirmation);

        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            if (_state == VaultState.Unlocked || _headerStore.Exists)
                throw new InvalidOperationException("A vault already exists on this USB drive.");
        }

        ValidateNewPassword(password, confirmation);
        ct.ThrowIfCancellationRequested();

        NewVault created = VaultKeyManager.CreateVault(password, _options.Kdf);
        VaultRepository? repo = null;
        try
        {
            repo = VaultRepository.Initialize(_options.Paths, created.Header, created.Keys, _options.Drive, _options.Time);
            BecomeUnlocked(created.Keys, repo, ActivityKind.VaultCreated, "Vault created.", priorFailures: 0);
        }
        catch
        {
            repo?.Dispose();
            created.Keys.Dispose();
            throw;
        }
    }

    // ================================================================== unlock

    public UnlockResult Unlock(string password, CancellationToken ct = default) =>
        UnlockCore(password, UnlockMode.Normal, ct);

    /// <summary>
    /// Explicit recovery: use the backup copy of the header. Offer this only when <see cref="UnlockResult.BackupHeaderAvailable"/>
    /// is set (the password failed although the user is sure it is right, e.g. after bit-rot). Counts as an attempt.
    /// </summary>
    public UnlockResult UnlockUsingBackupHeader(string password, CancellationToken ct = default) =>
        UnlockCore(password, UnlockMode.Backup, ct);

    /// <summary>Last resort when <see cref="UnlockStatus.IndexDamaged"/>: rebuilds a generic index from the encrypted files themselves.</summary>
    public UnlockResult RebuildIndexAndUnlock(string password, CancellationToken ct = default) =>
        UnlockCore(password, UnlockMode.Rebuild, ct);

    private UnlockResult UnlockCore(string password, UnlockMode mode, CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(password);

        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            if (_state == VaultState.Unlocked) throw new InvalidOperationException("The vault is already unlocked.");
            if (_unlockInProgress) throw new InvalidOperationException("An unlock is already in progress.");
            _unlockInProgress = true;
        }

        try
        {
            return UnlockWorker(password, mode, ct);
        }
        finally
        {
            lock (_gate) _unlockInProgress = false;
        }
    }

    private UnlockResult UnlockWorker(string password, UnlockMode mode, CancellationToken ct)
    {
        VaultPaths paths = _options.Paths;

        if (!_options.Drive.IsAvailable(paths.DataDirectory) || !Directory.Exists(paths.DataDirectory))
        {
            return State == VaultState.NotInitialized
                ? new UnlockResult(UnlockStatus.VaultNotInitialized, Message: "No vault was found on this USB drive.")
                : new UnlockResult(UnlockStatus.UsbUnavailable, Message: "The SecureUSB drive is not available.");
        }
        if (State == VaultState.NotInitialized)
            return new UnlockResult(UnlockStatus.VaultNotInitialized, Message: "No vault was found on this USB drive.");

        AttemptStatus attempts;
        try { attempts = _guard.GetStatus(); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException)
        {
            return new UnlockResult(UnlockStatus.StorageError, Message: "The USB drive could not be read: " + e.Message);
        }

        if (attempts.IsLockedOut)
        {
            return new UnlockResult(UnlockStatus.LockedOut, attempts.ConsecutiveFailures, attempts.RemainingDelay,
                $"Too many failed attempts. Try again in {FormatDelay(attempts.RemainingDelay)}.");
        }
        if (password.Length == 0)
            return new UnlockResult(UnlockStatus.PasswordRequired, attempts.ConsecutiveFailures, Message: "Enter your password.");

        ct.ThrowIfCancellationRequested();

        HeaderLoadResult loaded;
        try { loaded = _headerStore.Load(); }
        catch (VaultCorruptException e) { return new UnlockResult(UnlockStatus.HeaderUnreadable, Message: e.Message); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException)
        {
            return new UnlockResult(UnlockStatus.StorageError, Message: "The USB drive could not be read: " + e.Message);
        }

        VaultHeader header = loaded.Header;
        if (mode == UnlockMode.Backup)
        {
            VaultHeader? backup = _headerStore.TryReadBackup();
            if (backup is null)
                return new UnlockResult(UnlockStatus.HeaderUnreadable, Message: "There is no valid backup header.");
            header = backup;
        }

        VaultKeys keys;
        try
        {
            keys = VaultKeyManager.Unlock(password, header);   // Argon2id: this is the slow part
        }
        catch (VaultAuthenticationException)
        {
            AttemptStatus after = SafeRecordFailure();
            return new UnlockResult(UnlockStatus.WrongPasswordOrDamagedVault, after.ConsecutiveFailures, after.RemainingDelay,
                after.IsLockedOut
                    ? $"Wrong password, or the vault is damaged. Try again in {FormatDelay(after.RemainingDelay)}."
                    : "Wrong password, or the vault is damaged.",
                BackupHeaderAvailable: mode == UnlockMode.Normal && BackupDiffersFrom(header));
        }

        // The password is right. Repair the header copies, then open the storage engine.
        try { _headerStore.Heal(header); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException) { /* surfaced later by the integrity check */ }

        VaultRepository repo;
        try
        {
            repo = mode == UnlockMode.Rebuild
                ? VaultRepository.RebuildIndexFromBlobs(paths, keys, _options.Drive, _options.Time)
                : VaultRepository.Open(paths, keys, _options.Drive, _options.Time);
        }
        catch (VaultCorruptException e)
        {
            keys.Dispose();
            return new UnlockResult(UnlockStatus.IndexDamaged, Message: e.Message);
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException)
        {
            keys.Dispose();
            bool inUse = File.Exists(paths.LockPath) && _options.Drive.IsAvailable(paths.DataDirectory);
            return inUse
                ? new UnlockResult(UnlockStatus.VaultInUse, Message: "This vault is already open in another SecureUSB window.")
                : new UnlockResult(UnlockStatus.StorageError, Message: "The USB drive could not be read: " + e.Message);
        }

        int priorFailures = 0;
        try { priorFailures = _guard.RecordSuccess(); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException) { }

        ActivityKind kind = mode switch
        {
            UnlockMode.Rebuild => ActivityKind.IndexRebuilt,
            UnlockMode.Backup => ActivityKind.HeaderRecoveredFromBackup,
            _ => ActivityKind.UnlockSucceeded
        };
        string text = mode switch
        {
            UnlockMode.Rebuild => "Unlocked after rebuilding the file index from the encrypted files.",
            UnlockMode.Backup => "Unlocked using the backup vault header; the header copies were repaired.",
            _ => "Vault unlocked."
        };

        BecomeUnlocked(keys, repo, kind, text, priorFailures);
        return new UnlockResult(UnlockStatus.Success);
    }

    private bool BackupDiffersFrom(VaultHeader used)
    {
        try
        {
            VaultHeader? backup = _headerStore.TryReadBackup();
            return backup is not null && !backup.ToBytes().AsSpan().SequenceEqual(used.ToBytes());
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException)
        {
            return false;
        }
    }

    private AttemptStatus SafeRecordFailure()
    {
        try { return _guard.RecordFailure(); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException) { return default; }
    }

    private void BecomeUnlocked(VaultKeys keys, VaultRepository repo, ActivityKind kind, string message, int priorFailures)
    {
        var monitor = new UsbMonitor(_options.Drive, _options.Paths);
        var session = new Session
        {
            Repo = repo,
            Keys = keys,
            Log = new ActivityLog(_options.Paths, keys, _options.Time),
            Monitor = monitor,
            Cts = new CancellationTokenSource()
        };

        lock (_gate)
        {
            _session = session;
            _state = VaultState.Unlocked;
        }

        if (priorFailures > 0)
            TryLog(session, ActivityKind.UnlockFailuresReported, $"{priorFailures} failed unlock attempt(s) since the last successful unlock.");
        while (true)
        {
            string? notice;
            lock (_gate) notice = _pendingNotices.Count > 0 ? _pendingNotices.Dequeue() : null;
            if (notice is null) break;
            TryLog(session, ActivityKind.UsbRemoved, notice);
        }
        TryLog(session, kind, message);

        monitor.DriveRemoved += OnDriveRemoved;
        if (_options.UsbPollInterval > TimeSpan.Zero) monitor.Start(_options.UsbPollInterval);
    }

    // ================================================================== lock / USB removal

    public void Lock() => LockCore(LockReason.User);

    /// <summary>Checks the drive immediately (call from a device-change notification). Locks the vault if it is gone.</summary>
    /// <returns>true if the drive is present (or the vault is not unlocked).</returns>
    public bool CheckUsbNow()
    {
        UsbMonitor? monitor;
        lock (_gate) monitor = _session?.Monitor;
        return monitor?.CheckNow() ?? true;
    }

    private void OnDriveRemoved(object? sender, EventArgs e) => LockCore(LockReason.UsbRemoved);

    private void LockCore(LockReason reason)
    {
        Session? session;
        lock (_gate)
        {
            if (_session is null) return;
            session = _session;
            _session = null;
            _state = VaultState.Locked;   // from this moment every new operation is refused
            if (reason == LockReason.UsbRemoved)
                _pendingNotices.Enqueue("The vault was locked automatically because the USB drive was removed.");
        }

        // 1. stop running operations, and remove decrypted plaintext from the PC right away
        session.Cts.Cancel();
        CleanupReport cleanup = _temp.CleanupAll();

        // 2. let running operations leave the storage engine (bounded wait), then clean up again for stragglers
        TimeSpan wait = reason == LockReason.UsbRemoved
            ? TimeSpan.FromMilliseconds(Math.Min(_options.LockDrainTimeout.TotalMilliseconds, 1000))
            : _options.LockDrainTimeout;
        DateTime deadline = DateTime.UtcNow + wait;
        lock (_gate)
        {
            while (Volatile.Read(ref session.ActiveOperations) > 0)
            {
                TimeSpan left = deadline - DateTime.UtcNow;
                if (left <= TimeSpan.Zero) break;
                Monitor.Wait(_gate, left);
            }
        }
        CleanupReport finalCleanup = _temp.CleanupAll();
        if (!finalCleanup.IsComplete) cleanup = finalCleanup;
        else cleanup = new CleanupReport(cleanup.Deleted + finalCleanup.Deleted, Array.Empty<string>());

        // 3. a normal lock is logged (the drive is still there); after a removal logging is pointless
        if (reason != LockReason.UsbRemoved)
            TryLog(session, ActivityKind.VaultLocked, reason == LockReason.User ? "Vault locked." : "Vault locked (application closing).");

        // 4. wipe the keys: nothing can be decrypted from this moment on
        session.Monitor.Dispose();
        session.Repo.Dispose();
        session.Keys.Dispose();

        try { Locked?.Invoke(this, new VaultLockedEventArgs(reason, cleanup)); }
        catch { /* a faulty UI handler must not break the lock */ }
    }

    // ================================================================== file operations

    public IReadOnlyList<FileEntry> ListFiles() => Run((s, _) => s.Repo.List());

    public IReadOnlyList<FileEntry> SearchFiles(string query) => Run((s, _) => s.Repo.Search(query ?? ""));

    /// <summary>Adds a file from disk. Names and folders are sanitized; the vault's own files cannot be added.</summary>
    public FileEntry AddFile(string sourcePath, string folderPath = "", ConflictPolicy conflict = ConflictPolicy.AutoRename,
        CancellationToken ct = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(sourcePath);
        if (_options.Paths.IsInsideDataDirectory(sourcePath))
            throw new ArgumentException("SecureUSB's own data files cannot be added to the vault.", nameof(sourcePath));

        string name = FilenameSanitizer.SanitizeFileName(Path.GetFileName(sourcePath));
        string folder = FilenameSanitizer.SanitizeFolderPath(folderPath);

        FileEntry entry = Run((s, token) => s.Repo.AddFileFromPath(sourcePath, folder, name, conflict, token), ct);
        TryLog($"Added file '{entry.FullPath}' ({ByteSize.Format(entry.SizeBytes)}).", ActivityKind.FileAdded);
        return entry;
    }

    public AddFolderResult AddFolder(string sourceDirectory, string targetFolderPath = "",
        ConflictPolicy conflict = ConflictPolicy.AutoRename, IProgress<string>? progress = null, CancellationToken ct = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(sourceDirectory);
        string source = Path.TrimEndingDirectorySeparator(Path.GetFullPath(sourceDirectory));
        string data = Path.TrimEndingDirectorySeparator(_options.Paths.DataDirectory);
        string sourcePrefix = source.EndsWith(Path.DirectorySeparatorChar) ? source : source + Path.DirectorySeparatorChar;
        if (string.Equals(source, data, StringComparison.OrdinalIgnoreCase) ||
            data.StartsWith(sourcePrefix, StringComparison.OrdinalIgnoreCase) ||
            _options.Paths.IsInsideDataDirectory(source))
            throw new ArgumentException("This folder contains the SecureUSB vault itself and cannot be added.", nameof(sourceDirectory));

        string target = FilenameSanitizer.SanitizeFolderPath(targetFolderPath);
        AddFolderResult result = Run((s, token) => s.Repo.AddFolder(source, target, conflict, progress, token), ct);
        TryLog($"Added folder '{Path.GetFileName(source)}': {result.Added} file(s), {result.Failures.Count} skipped.", ActivityKind.FolderAdded);
        return result;
    }

    /// <summary>User-typed names are validated, not silently changed.</summary>
    /// <exception cref="InvalidEntryNameException">The name is not allowed (the message says why).</exception>
    public FileEntry RenameFile(Guid id, string newName)
    {
        FileEntry before = Run((s, _) => s.Repo.Find(id)) ?? throw new EntryNotFoundException(id);
        FileEntry after = Run((s, _) => s.Repo.Rename(id, newName));
        TryLog($"Renamed '{before.FullPath}' to '{after.Name}'.", ActivityKind.FileRenamed);
        return after;
    }

    public void DeleteFile(Guid id)
    {
        FileEntry entry = Run((s, _) => s.Repo.Find(id)) ?? throw new EntryNotFoundException(id);
        Run((s, _) => { s.Repo.Delete(id); return 0; });
        TryLog($"Deleted '{entry.FullPath}'.", ActivityKind.FileDeleted);
    }

    /// <summary>
    /// Decrypts a file into <paramref name="destinationDirectory"/> (the name is sanitized and proven to stay inside it).
    /// The plaintext copy is YOUR responsibility afterwards: it is no longer protected by the vault.
    /// </summary>
    /// <returns>The full path that was written.</returns>
    public string ExportFile(Guid id, string destinationDirectory, string? fileName = null, bool overwrite = false,
        CancellationToken ct = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(destinationDirectory);
        FileEntry entry = Run((s, _) => s.Repo.Find(id)) ?? throw new EntryNotFoundException(id);

        string dir = Path.GetFullPath(destinationDirectory);
        if (!Directory.Exists(dir)) throw new DirectoryNotFoundException("The destination folder does not exist.");
        string target = FilenameSanitizer.CombineInsideDirectory(dir, fileName ?? entry.Name);
        if (_options.Paths.IsInsideDataDirectory(target))
            throw new ArgumentException("Files cannot be exported into the vault's own data folder.", nameof(destinationDirectory));

        Run((s, token) => { s.Repo.ExportToFile(id, target, overwrite, token); return 0; }, ct);
        TryLog($"Exported '{entry.FullPath}' to '{dir}'.", ActivityKind.FileExported);
        return target;
    }

    /// <summary>
    /// Decrypts into a managed temporary file so another program can open it. It is wiped when the vault locks,
    /// when the USB drive is removed, and on exit. Edits are not saved back into the vault.
    /// </summary>
    public string OpenTemporaryCopy(Guid id, CancellationToken ct = default)
    {
        FileEntry entry = Run((s, _) => s.Repo.Find(id)) ?? throw new EntryNotFoundException(id);
        string path = Run((s, token) => _temp.CreateTempFile(entry.Name, stream => s.Repo.ExportToStream(id, stream, token)), ct);
        TryLog($"Opened a temporary decrypted copy of '{entry.FullPath}'.", ActivityKind.FileOpenedExternally);
        return path;
    }

    /// <summary>Decrypts into memory only (no plaintext touches the disk). The caller should zero the array when done.</summary>
    public byte[] ReadFileForPreview(Guid id, long maxBytes, CancellationToken ct = default) =>
        Run((s, token) => s.Repo.ReadAllBytes(id, maxBytes, token), ct);

    /// <summary>Wipes all decrypted temporary copies now.</summary>
    public CleanupReport CleanTemporaryFiles()
    {
        CleanupReport report = _temp.CleanupAll();
        if (report.Deleted > 0 && IsUnlocked)
            TryLog($"Removed {report.Deleted} temporary decrypted file(s).", ActivityKind.TempFilesCleaned);
        return report;
    }

    public int TemporaryFileCount => _temp.ActiveCount;

    public StorageUsage GetStorageUsage() => Run((s, _) => s.Repo.GetStorageUsage(_options.ApplicationPaths));

    public IntegrityReport CheckIntegrity(bool deep, IProgress<IntegrityProgress>? progress = null, CancellationToken ct = default)
    {
        IntegrityReport report = Run((s, token) => s.Repo.CheckIntegrity(deep, progress, token), ct);
        int errors = report.Issues.Count(i => i.Severity == IssueSeverity.Error);
        TryLog($"{(deep ? "Full" : "Quick")} integrity check: {report.FilesChecked} file(s), {report.Issues.Count} issue(s), {errors} error(s).",
            ActivityKind.IntegrityChecked);
        return report;
    }

    public RepairResult RepairIntegrity(IntegrityReport report, RepairOptions options, CancellationToken ct = default)
    {
        RepairResult result = Run((s, token) => s.Repo.Repair(report, options, token), ct);
        TryLog($"Repair: {result.TempFilesDeleted} temp file(s) removed, {result.OrphansRecovered} recovered, " +
               $"{result.OrphansDeleted} orphan(s) deleted, {result.EntriesRemoved} entr(ies) removed, header backup synced: {result.HeaderBackupSynced}.",
            ActivityKind.IntegrityRepaired);
        return result;
    }

    public ActivityLogReadResult ReadActivityLog() => Run((s, _) => s.Log.Read());

    // ================================================================== change password

    /// <summary>
    /// Safe sequence: verify the current password (counts toward the attempt delays) -> build the new header ->
    /// PROVE the new header opens with the new password and yields the same master key -> only then replace
    /// the header atomically (backup rewritten last). Files are not re-encrypted. A failure at any point leaves the
    /// old password working.
    /// </summary>
    /// <exception cref="PasswordRejectedException">New password too weak, unchanged, or the confirmation differs.</exception>
    public ChangePasswordResult ChangePassword(string currentPassword, string newPassword, string confirmation)
    {
        ArgumentNullException.ThrowIfNull(currentPassword);
        ArgumentNullException.ThrowIfNull(newPassword);
        ArgumentNullException.ThrowIfNull(confirmation);

        ValidateNewPassword(newPassword, confirmation);
        if (string.Equals(currentPassword, newPassword, StringComparison.Ordinal))
            throw new PasswordRejectedException(new[] { "The new password must be different from the current password." });

        ChangePasswordResult result = Run((s, token) =>
        {
            AttemptStatus attempts = _guard.GetStatus();
            if (attempts.IsLockedOut) return new ChangePasswordResult(ChangePasswordStatus.LockedOut, attempts.RemainingDelay);
            if (currentPassword.Length == 0) return new ChangePasswordResult(ChangePasswordStatus.WrongCurrentPassword);

            VaultHeader current = _headerStore.Load().Header;
            VaultHeader replacement;
            try
            {
                replacement = VaultKeyManager.ChangePassword(currentPassword, newPassword, current, _options.Kdf);
            }
            catch (VaultAuthenticationException)
            {
                AttemptStatus after = SafeRecordFailure();
                return new ChangePasswordResult(
                    after.IsLockedOut ? ChangePasswordStatus.LockedOut : ChangePasswordStatus.WrongCurrentPassword, after.RemainingDelay);
            }

            token.ThrowIfCancellationRequested();

            using (VaultKeys check = VaultKeyManager.Unlock(newPassword, replacement))
            using (SecureBytes a = check.DeriveKey(KeyPurpose.Index))
            using (SecureBytes b = s.Keys.DeriveKey(KeyPurpose.Index))
            {
                if (!CryptographicOperations.FixedTimeEquals(a.Span, b.Span))
                    throw new InvalidOperationException("The new header failed verification; the password was NOT changed.");
            }

            _headerStore.Commit(replacement);   // atomic; throws before touching the old header if the drive misbehaves
            _guard.RecordSuccess();
            return new ChangePasswordResult(ChangePasswordStatus.Success);
        });

        if (result.Succeeded) TryLog("Password changed.", ActivityKind.PasswordChanged);
        else if (result.Status == ChangePasswordStatus.WrongCurrentPassword)
            TryLog("A password change was attempted with a wrong current password.", ActivityKind.Warning);
        return result;
    }

    // ================================================================== plumbing

    private static void ValidateNewPassword(string password, string confirmation)
    {
        if (!string.Equals(password, confirmation, StringComparison.Ordinal))
            throw new PasswordRejectedException(new[] { "The passwords do not match." });

        PasswordAssessment assessment = PasswordPolicy.Evaluate(password);
        if (!assessment.MeetsPolicy)
            throw new PasswordRejectedException(assessment.Issues.Concat(assessment.Suggestions).ToList());
    }

    private static string FormatDelay(TimeSpan t) =>
        t.TotalMinutes >= 1 ? $"{(int)Math.Ceiling(t.TotalMinutes)} minute(s)" : $"{(int)Math.Ceiling(t.TotalSeconds)} second(s)";

    private T Run<T>(Func<Session, CancellationToken, T> action, CancellationToken userToken = default)
    {
        Session session;
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            session = _session ?? throw new VaultLockedException();
            Interlocked.Increment(ref session.ActiveOperations);
        }

        CancellationToken lockToken = session.Cts.Token;
        try
        {
            using var linked = CancellationTokenSource.CreateLinkedTokenSource(lockToken, userToken);
            return action(session, linked.Token);
        }
        catch (ObjectDisposedException) when (!IsStillCurrent(session))
        {
            throw new VaultLockedException("The vault was locked while the operation was running.");
        }
        catch (OperationCanceledException) when (lockToken.IsCancellationRequested && !userToken.IsCancellationRequested)
        {
            throw new VaultLockedException("The vault was locked while the operation was running.");
        }
        finally
        {
            lock (_gate)
            {
                Interlocked.Decrement(ref session.ActiveOperations);
                Monitor.PulseAll(_gate);
            }
        }
    }

    private bool IsStillCurrent(Session session)
    {
        lock (_gate) return ReferenceEquals(_session, session);
    }

    private void TryLog(string message, ActivityKind kind)
    {
        Session? session;
        lock (_gate) session = _session;
        if (session is not null) TryLog(session, kind, message);
    }

    private void TryLog(Session session, ActivityKind kind, string message)
    {
        try
        {
            session.Log.Append(kind, message);
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or ObjectDisposedException)
        {
            Interlocked.Increment(ref _logWriteFailures);
        }
    }

    public void Dispose()
    {
        lock (_gate)
        {
            if (_disposed) return;
        }
        LockCore(LockReason.Shutdown);
        lock (_gate) _disposed = true;
        _temp.Dispose();
    }
}
