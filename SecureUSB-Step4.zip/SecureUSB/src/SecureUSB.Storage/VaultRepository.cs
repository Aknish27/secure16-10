using System.Security.Cryptography;
using SecureUSB.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Storage;

public enum ConflictPolicy { Reject, AutoRename }
public enum OrphanAction { Keep, Delete, Recover }

public sealed record RepairOptions
{
    public OrphanAction Orphans { get; init; } = OrphanAction.Keep;
    public bool RemoveEntriesWithMissingBlobs { get; init; }
    public bool DeleteStaleTemps { get; init; } = true;
    public bool SyncHeaderBackup { get; init; } = true;
}

public sealed record RepairResult(int TempFilesDeleted, int OrphansDeleted, int OrphansRecovered, int EntriesRemoved, bool HeaderBackupSynced);

public sealed record AddFolderFailure(string Path, string Reason);
public sealed record AddFolderResult(int Added, IReadOnlyList<AddFolderFailure> Failures);

/// <summary>
/// The vault's storage engine, used by Core after a successful unlock. It never sees a password: it is given
/// the unlocked <see cref="VaultKeys"/> (which the caller owns and disposes to lock the vault).
///
/// Ordering rules that make interruptions safe:
///   add     : encrypt to .tmp -> flush -> rename to .blob -> commit index.   Crash before the commit = orphan blob.
///   delete  : commit index without the entry -> delete blob.                 Crash between = orphan blob.
///   rename  : index only.
/// Index changes are copy-on-write: the in-memory index is replaced only after the new one is safely on disk.
/// A single process may hold the vault at a time (exclusive vault.lock).
/// </summary>
public sealed class VaultRepository : IDisposable
{
    private const int FolderCommitInterval = 25;

    private readonly VaultPaths _paths;
    private readonly VaultKeys _keys;
    private readonly IDriveInfoService _drive;
    private readonly TimeProvider _time;
    private readonly EncryptedIndexStore _indexStore;
    private readonly VaultHeaderStore _headerStore;
    private readonly BlobStore _blobs;
    private readonly object _gate = new();
    private FileStream? _lockStream;
    private VaultIndex _index = null!;
    private bool _disposed;

    private VaultRepository(VaultPaths paths, VaultKeys keys, IDriveInfoService drive, TimeProvider time)
    {
        _paths = paths ?? throw new ArgumentNullException(nameof(paths));
        _keys = keys ?? throw new ArgumentNullException(nameof(keys));
        _drive = drive ?? throw new ArgumentNullException(nameof(drive));
        _time = time;
        _indexStore = new EncryptedIndexStore(paths);
        _headerStore = new VaultHeaderStore(paths);
        _blobs = new BlobStore(paths, drive);

        paths.EnsureDirectories();
        // Exclusive lock: a second SecureUSB instance cannot open (and corrupt) the same vault.
        _lockStream = new FileStream(paths.LockPath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None, 1, FileOptions.DeleteOnClose);
    }

    // ------------------------------------------------------------------ creation / opening

    /// <summary>Creates a brand-new vault on disk: header + backup, then an empty encrypted index.</summary>
    public static VaultRepository Initialize(VaultPaths paths, VaultHeader header, VaultKeys keys, IDriveInfoService drive, TimeProvider? time = null)
    {
        ArgumentNullException.ThrowIfNull(header);
        ArgumentNullException.ThrowIfNull(keys);
        if (header.VaultId != keys.VaultId) throw new ArgumentException("Header and keys belong to different vaults.");

        var repo = new VaultRepository(paths, keys, drive, time ?? TimeProvider.System);
        try
        {
            if (repo._headerStore.Exists) throw new InvalidOperationException("A vault already exists in this location.");
            repo._headerStore.Create(header);
            repo._index = VaultIndex.CreateEmpty(keys.VaultId, repo._time.GetUtcNow());
            repo._indexStore.Save(repo._index, keys);
            return repo;
        }
        catch
        {
            repo.Dispose();
            throw;
        }
    }

    /// <summary>Opens an existing vault with already-unlocked keys; recovers from interrupted writes.</summary>
    /// <exception cref="VaultCorruptException">Index unreadable (see <see cref="RebuildIndexFromBlobs"/>).</exception>
    /// <exception cref="IOException">Another process has the vault open.</exception>
    public static VaultRepository Open(VaultPaths paths, VaultKeys keys, IDriveInfoService drive, TimeProvider? time = null)
    {
        var repo = new VaultRepository(paths, keys, drive, time ?? TimeProvider.System);
        try
        {
            repo.LoadIndex();
            repo.CleanupStaleBlobTemps();
            return repo;
        }
        catch
        {
            repo.Dispose();
            throw;
        }
    }

    /// <summary>
    /// Last-resort recovery when every index copy is lost: authenticates each blob's embedded file key and
    /// creates generic entries (Recovered/Recovered-xxxx.bin). Original names, folders and dates are NOT recoverable.
    /// </summary>
    public static VaultRepository RebuildIndexFromBlobs(VaultPaths paths, VaultKeys keys, IDriveInfoService drive, TimeProvider? time = null)
    {
        var repo = new VaultRepository(paths, keys, drive, time ?? TimeProvider.System);
        try
        {
            repo.CleanupStaleBlobTemps();
            var entries = new List<FileEntry>();
            foreach (Guid id in repo._blobs.EnumerateBlobIds().ToList())
            {
                FileEntry? recovered = repo.TryBuildRecoveredEntry(id, entries);
                if (recovered is not null) entries.Add(recovered);
            }

            DateTimeOffset now = repo._time.GetUtcNow();
            repo._index = VaultIndex.CreateEmpty(keys.VaultId, now) with { Files = entries };
            repo._indexStore.Save(repo._index, keys);
            return repo;
        }
        catch
        {
            repo.Dispose();
            throw;
        }
    }

    private void LoadIndex()
    {
        IndexLoadResult? loaded = _indexStore.Load(_keys);
        if (loaded is null)
        {
            if (HasAnyBlobs())
                throw new VaultCorruptException("The file index is missing but encrypted data exists. Index recovery is required.");

            // Interrupted first-time initialisation: finish it.
            _index = VaultIndex.CreateEmpty(_keys.VaultId, _time.GetUtcNow());
            _indexStore.Save(_index, _keys);
            return;
        }
        _indexStore.Heal(loaded);
        _index = loaded.Index;
    }

    private bool HasAnyBlobs() => _blobs.EnumerateBlobIds().Any();

    private void CleanupStaleBlobTemps()
    {
        if (!Directory.Exists(_paths.BlobsDirectory)) return;
        foreach (string file in Directory.EnumerateFiles(_paths.BlobsDirectory).ToList())
        {
            if (VaultPaths.TryParseBlobFileName(Path.GetFileName(file), out _, out bool isTemp) && isTemp)
                AtomicFile.TryDelete(file);   // ciphertext only: no wiping needed
        }
    }

    // ------------------------------------------------------------------ queries

    public Guid VaultId => _keys.VaultId;

    public long Revision { get { lock (_gate) { ThrowIfDisposed(); return _index.Revision; } } }

    public IReadOnlyList<FileEntry> List()
    {
        lock (_gate)
        {
            ThrowIfDisposed();
            return _index.Files;   // immutable snapshot
        }
    }

    public FileEntry? Find(Guid id)
    {
        lock (_gate)
        {
            ThrowIfDisposed();
            return _index.Files.FirstOrDefault(f => f.Id == id);
        }
    }

    public IReadOnlyList<FileEntry> Search(string query)
    {
        lock (_gate)
        {
            ThrowIfDisposed();
            if (string.IsNullOrWhiteSpace(query)) return _index.Files;
            string q = query.Trim();
            return _index.Files
                .Where(f => f.Name.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                            f.FolderPath.Contains(q, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }
    }

    public StorageUsage GetStorageUsage(IEnumerable<string> applicationPaths)
    {
        ThrowIfDisposed();
        return StorageUsageCalculator.Calculate(_paths, applicationPaths, _drive);
    }

    // ------------------------------------------------------------------ add

    public FileEntry AddFile(Stream content, string name, string folderPath = "", DateTimeOffset? modifiedUtc = null,
        ConflictPolicy conflict = ConflictPolicy.Reject, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(content);
        return AddCore(content, name, EntryNames.NormalizeFolderPath(folderPath), modifiedUtc, conflict, commitIndex: true, ct);
    }

    /// <summary>Validates and adds a file from disk. Links (reparse points) and non-files are refused.</summary>
    public FileEntry AddFileFromPath(string sourcePath, string folderPath = "", string? nameOverride = null,
        ConflictPolicy conflict = ConflictPolicy.Reject, CancellationToken ct = default) =>
        AddFileFromPathCore(sourcePath, EntryNames.NormalizeFolderPath(folderPath), nameOverride, conflict, commitIndex: true, ct);

    private FileEntry AddFileFromPathCore(string sourcePath, string folderPath, string? nameOverride,
        ConflictPolicy conflict, bool commitIndex, CancellationToken ct)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(sourcePath);
        var info = new FileInfo(sourcePath);
        if (!info.Exists) throw new FileNotFoundException("Source file not found.", sourcePath);
        if ((info.Attributes & FileAttributes.ReparsePoint) != 0)
            throw new InvalidOperationException("Links and junctions are not added to the vault; add the real file instead.");
        if ((info.Attributes & FileAttributes.Directory) != 0)
            throw new InvalidOperationException("Use AddFolder to add a folder.");

        using var fs = new FileStream(info.FullName, FileMode.Open, FileAccess.Read, FileShare.Read, 81920, FileOptions.SequentialScan);
        return AddCore(fs, nameOverride ?? info.Name, folderPath, new DateTimeOffset(info.LastWriteTimeUtc, TimeSpan.Zero), conflict, commitIndex, ct);
    }

    private FileEntry AddCore(Stream content, string name, string folderPath, DateTimeOffset? modifiedUtc,
        ConflictPolicy conflict, bool commitIndex, CancellationToken ct)
    {
        ValidateName(name);
        ValidateFolder(folderPath);

        // Fail fast on a duplicate before spending time encrypting a large file.
        lock (_gate)
        {
            ThrowIfDisposed();
            if (conflict == ConflictPolicy.Reject && NameExists(_index, folderPath, name, null))
                throw new DuplicateEntryException(Combine(folderPath, name));
            if (_index.Files.Count >= VaultIndex.MaxEntries)
                throw new InvalidOperationException("The vault has reached its maximum number of files.");
        }

        Guid id = SecureRandom.NewGuid();
        BlobWriteResult written = _blobs.WriteTemp(id, content, _keys, ChunkedFileCipher.DefaultChunkSize, ct);

        bool blobCommitted = false;
        try
        {
            lock (_gate)
            {
                ThrowIfDisposed();
                string finalName = name;
                if (NameExists(_index, folderPath, name, null))
                {
                    if (conflict == ConflictPolicy.Reject) throw new DuplicateEntryException(Combine(folderPath, name));
                    finalName = UniqueName(_index, folderPath, name);
                }

                DateTimeOffset now = _time.GetUtcNow();
                var entry = new FileEntry
                {
                    Id = id,
                    Name = finalName,
                    FolderPath = folderPath,
                    SizeBytes = written.PlaintextBytes,
                    ChunkSize = ChunkedFileCipher.DefaultChunkSize,
                    AddedUtc = now,
                    ModifiedUtc = modifiedUtc ?? now
                };

                _blobs.CommitTemp(id);
                blobCommitted = true;

                VaultIndex next = _index.WithFiles(_index.Files.Append(entry).ToList(), now);
                if (commitIndex) _indexStore.Save(next, _keys);
                _index = next;
                return entry;
            }
        }
        catch
        {
            if (!blobCommitted)
            {
                _blobs.DiscardTemp(id);
            }
            else if (!File.Exists(_paths.IndexTempPath))
            {
                // The index save failed before a pending index copy was written: nothing can reference the blob.
                _blobs.TryDelete(id);
            }
            // else: a pending index copy (index.sdb.tmp) may already list this file. Keep the blob so that copy
            // stays consistent; at worst it is an orphan that the integrity scanner reports.
            throw;
        }
    }

    /// <summary>
    /// Adds a folder tree. Links are skipped, per-file problems are collected (not fatal), the index is
    /// committed in batches, and everything added before a cancellation/failure is committed.
    /// </summary>
    public AddFolderResult AddFolder(string sourceDirectory, string targetFolderPath = "",
        ConflictPolicy conflict = ConflictPolicy.AutoRename, IProgress<string>? progress = null, CancellationToken ct = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(sourceDirectory);
        var root = new DirectoryInfo(sourceDirectory);
        if (!root.Exists) throw new DirectoryNotFoundException("Source folder not found.");
        if ((root.Attributes & FileAttributes.ReparsePoint) != 0)
            throw new InvalidOperationException("Links and junctions are not added to the vault.");

        var failures = new List<AddFolderFailure>();
        int added = 0, sinceCommit = 0;
        var pending = new Stack<(DirectoryInfo Dir, string Target)>();
        pending.Push((root, Combine(EntryNames.NormalizeFolderPath(targetFolderPath), root.Name)));

        try
        {
            while (pending.Count > 0)
            {
                (DirectoryInfo dir, string target) = pending.Pop();
                if (!EntryNames.IsValidFolderPath(target, out string folderReason))
                {
                    failures.Add(new AddFolderFailure(dir.FullName, folderReason));
                    continue;
                }

                IEnumerable<FileSystemInfo> children;
                try { children = dir.EnumerateFileSystemInfos().ToList(); }
                catch (Exception e) when (e is IOException or UnauthorizedAccessException)
                {
                    failures.Add(new AddFolderFailure(dir.FullName, e.Message));
                    continue;
                }

                foreach (FileSystemInfo child in children)
                {
                    ct.ThrowIfCancellationRequested();
                    if ((child.Attributes & FileAttributes.ReparsePoint) != 0)
                    {
                        failures.Add(new AddFolderFailure(child.FullName, "Skipped: link or junction."));
                        continue;
                    }
                    if (child is DirectoryInfo sub)
                    {
                        pending.Push((sub, Combine(target, sub.Name)));
                        continue;
                    }

                    progress?.Report(child.FullName);
                    try
                    {
                        AddFileFromPathCore(child.FullName, target, null, conflict, commitIndex: false, ct);
                        added++;
                        if (++sinceCommit >= FolderCommitInterval) { CommitIndex(); sinceCommit = 0; }
                    }
                    catch (Exception e) when (e is IOException or UnauthorizedAccessException or InvalidOperationException or ArgumentException)
                    {
                        if (e is InsufficientSpaceException or ObjectDisposedException) throw;
                        failures.Add(new AddFolderFailure(child.FullName, e.Message));
                    }
                }
            }
        }
        finally
        {
            if (sinceCommit > 0)
            {
                try { CommitIndex(); } catch (Exception e) when (e is IOException or UnauthorizedAccessException) { /* surfaced by the next operation */ }
            }
        }
        return new AddFolderResult(added, failures);
    }

    private void CommitIndex()
    {
        lock (_gate)
        {
            ThrowIfDisposed();
            _indexStore.Save(_index, _keys);
        }
    }

    // ------------------------------------------------------------------ rename / delete

    public FileEntry Rename(Guid id, string newName)
    {
        ValidateName(newName);
        lock (_gate)
        {
            ThrowIfDisposed();
            FileEntry entry = _index.Files.FirstOrDefault(f => f.Id == id) ?? throw new EntryNotFoundException(id);
            if (entry.Name == newName) return entry;
            if (NameExists(_index, entry.FolderPath, newName, id))
                throw new DuplicateEntryException(Combine(entry.FolderPath, newName));

            FileEntry renamed = entry with { Name = newName };
            VaultIndex next = _index.WithFiles(_index.Files.Select(f => f.Id == id ? renamed : f).ToList(), _time.GetUtcNow());
            _indexStore.Save(next, _keys);
            _index = next;
            return renamed;
        }
    }

    public void Delete(Guid id)
    {
        lock (_gate)
        {
            ThrowIfDisposed();
            if (_index.Files.All(f => f.Id != id)) throw new EntryNotFoundException(id);

            VaultIndex next = _index.WithFiles(_index.Files.Where(f => f.Id != id).ToList(), _time.GetUtcNow());
            _indexStore.Save(next, _keys);   // 1. the entry disappears durably
            _index = next;
            _blobs.TryDelete(id);            // 2. then the ciphertext (a failure here only leaves an orphan)
        }
    }

    // ------------------------------------------------------------------ export / read

    /// <summary>Decrypts into <paramref name="destination"/>. On exception the caller must discard partial output.</summary>
    public long ExportToStream(Guid id, Stream destination, CancellationToken ct = default)
    {
        FileEntry entry = GetEntry(id);
        try
        {
            return _blobs.Read(entry, _keys, destination, ct);
        }
        catch (FileNotFoundException ex)
        {
            throw new VaultCorruptException($"The encrypted data for '{entry.FullPath}' is missing.", ex);
        }
    }

    /// <summary>
    /// Decrypts to a file. Writes to a temporary ".part" file first and renames on success; on any failure the
    /// partial plaintext is wiped and removed, so a damaged/tampered file never appears at the destination.
    /// </summary>
    public void ExportToFile(Guid id, string destinationPath, bool overwrite = false, CancellationToken ct = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(destinationPath);
        string dest = Path.GetFullPath(destinationPath);
        string? dir = Path.GetDirectoryName(dest);
        if (dir is null || !Directory.Exists(dir)) throw new DirectoryNotFoundException("Destination folder does not exist.");
        if (!overwrite && File.Exists(dest)) throw new IOException("The destination file already exists.");

        string part = dest + "." + Guid.NewGuid().ToString("N") + ".part";
        try
        {
            using (var fs = new FileStream(part, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, FileOptions.SequentialScan))
            {
                ExportToStream(id, fs, ct);
                fs.Flush(flushToDisk: true);
            }
            File.Move(part, dest, overwrite);
        }
        catch
        {
            FileWiper.TryWipeAndDelete(part);
            throw;
        }
    }

    /// <summary>Decrypts into memory only (previews: no plaintext touches the disk). Caller should zero the array.</summary>
    public byte[] ReadAllBytes(Guid id, long maxBytes, CancellationToken ct = default)
    {
        FileEntry entry = GetEntry(id);
        if (entry.SizeBytes > maxBytes || entry.SizeBytes > int.MaxValue - 64)
            throw new InvalidOperationException("The file is too large to open in memory.");

        byte[] buffer = new byte[entry.SizeBytes];
        try
        {
            using var ms = new MemoryStream(buffer, writable: true);
            ExportToStream(id, ms, ct);
            return buffer;
        }
        catch (NotSupportedException ex)
        {
            CryptographicOperations.ZeroMemory(buffer);
            throw new DataIntegrityException("Decrypted data is larger than the index claims.", ex);
        }
        catch
        {
            CryptographicOperations.ZeroMemory(buffer);
            throw;
        }
    }

    // ------------------------------------------------------------------ integrity

    public IntegrityReport CheckIntegrity(bool deep, IProgress<IntegrityProgress>? progress = null, CancellationToken ct = default)
    {
        lock (_gate)
        {
            ThrowIfDisposed();
            return IntegrityScanner.Scan(_paths, _blobs, _index.Files, deep ? _keys : null, progress, ct);
        }
    }

    public RepairResult Repair(IntegrityReport report, RepairOptions options, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(report);
        ArgumentNullException.ThrowIfNull(options);

        lock (_gate)
        {
            ThrowIfDisposed();
            int temps = 0, deleted = 0, recovered = 0, removed = 0;
            bool headerNeeded = false;
            var removeIds = new HashSet<Guid>();
            var newEntries = new List<FileEntry>();

            foreach (IntegrityIssue issue in report.Issues)
            {
                ct.ThrowIfCancellationRequested();
                switch (issue.Kind)
                {
                    case IssueKind.StaleBlobTemp:
                    case IssueKind.IndexTempLeftover:
                        // Only ever touch files inside this vault's data directory.
                        if (options.DeleteStaleTemps && issue.Path is not null && _paths.IsInsideDataDirectory(issue.Path)
                            && File.Exists(issue.Path) && AtomicFile.TryDelete(issue.Path))
                            temps++;
                        break;

                    case IssueKind.OrphanBlob:
                        if (issue.FileId is Guid orphan && _index.Files.All(f => f.Id != orphan) && _blobs.Exists(orphan))
                        {
                            if (options.Orphans == OrphanAction.Delete)
                            {
                                if (_blobs.TryDelete(orphan)) deleted++;
                            }
                            else if (options.Orphans == OrphanAction.Recover)
                            {
                                FileEntry? entry = TryBuildRecoveredEntry(orphan, _index.Files.Concat(newEntries));
                                if (entry is not null) { newEntries.Add(entry); recovered++; }
                            }
                        }
                        break;

                    case IssueKind.BlobMissing:
                        if (options.RemoveEntriesWithMissingBlobs && issue.FileId is Guid missing) removeIds.Add(missing);
                        break;

                    case IssueKind.HeaderPrimaryDamaged:
                    case IssueKind.HeaderBackupMissing:
                    case IssueKind.HeaderBackupOutOfSync:
                    case IssueKind.HeaderTempLeftover:
                        headerNeeded = true;
                        break;
                }
            }

            if (removeIds.Count > 0 || newEntries.Count > 0)
            {
                List<FileEntry> files = _index.Files.Where(f => !removeIds.Contains(f.Id)).Concat(newEntries).ToList();
                removed = _index.Files.Count - (files.Count - newEntries.Count);
                VaultIndex next = _index.WithFiles(files, _time.GetUtcNow());
                _indexStore.Save(next, _keys);
                _index = next;
            }

            bool headerSynced = false;
            if (options.SyncHeaderBackup && headerNeeded)
            {
                HeaderLoadResult loaded = _headerStore.Load();
                _headerStore.Heal(loaded.Header);
                headerSynced = true;
            }

            return new RepairResult(temps, deleted, recovered, removed, headerSynced);
        }
    }

    private FileEntry? TryBuildRecoveredEntry(Guid id, IEnumerable<FileEntry> existing)
    {
        BlobInfo? info = _blobs.ReadInfo(id);
        if (info is null) return null;
        try
        {
            using SecureBytes probe = _keys.UnwrapFileKey(info.WrappedKey, id);   // proves the blob belongs to THIS vault
        }
        catch (CryptographicException)
        {
            return null;
        }

        DateTimeOffset now = _time.GetUtcNow();
        const string folder = "Recovered";
        string name = "Recovered-" + id.ToString("N")[..12] + ".bin";
        var snapshot = new VaultIndex { Files = existing.ToList() };
        if (NameExists(snapshot, folder, name, null)) name = UniqueName(snapshot, folder, name);

        return new FileEntry
        {
            Id = id,
            Name = name,
            FolderPath = folder,
            SizeBytes = info.PlaintextBytes,
            ChunkSize = info.ChunkSize,
            AddedUtc = now,
            ModifiedUtc = now
        };
    }

    // ------------------------------------------------------------------ helpers

    private FileEntry GetEntry(Guid id)
    {
        lock (_gate)
        {
            ThrowIfDisposed();
            return _index.Files.FirstOrDefault(f => f.Id == id) ?? throw new EntryNotFoundException(id);
        }
    }

    private static void ValidateName(string name)
    {
        if (!EntryNames.IsValidName(name, out string reason)) throw new InvalidEntryNameException(reason, nameof(name));
    }

    private static void ValidateFolder(string folderPath)
    {
        if (!EntryNames.IsValidFolderPath(folderPath, out string reason)) throw new InvalidEntryNameException(reason, nameof(folderPath));
    }

    private static string Combine(string folder, string name) => folder.Length == 0 ? name : folder + "/" + name;

    private static bool NameExists(VaultIndex index, string folder, string name, Guid? exceptId) =>
        index.Files.Any(f => f.Id != exceptId &&
                             string.Equals(f.FolderPath, folder, StringComparison.OrdinalIgnoreCase) &&
                             string.Equals(f.Name, name, StringComparison.OrdinalIgnoreCase));

    /// <summary>"report.pdf" -> "report (2).pdf", "report (3).pdf", ...</summary>
    internal static string UniqueName(VaultIndex index, string folder, string name)
    {
        string ext = Path.GetExtension(name);
        string stem = name.Substring(0, name.Length - ext.Length);
        for (int i = 2; i < 100_000; i++)
        {
            string suffix = $" ({i}){ext}";
            string trimmedStem = stem.Length + suffix.Length > EntryNames.MaxNameLength
                ? stem.Substring(0, EntryNames.MaxNameLength - suffix.Length)
                : stem;
            string candidate = trimmedStem + suffix;
            if (!NameExists(index, folder, candidate, null)) return candidate;
        }
        throw new InvalidOperationException("Could not find a unique name.");
    }

    private void ThrowIfDisposed() => ObjectDisposedException.ThrowIf(_disposed, this);

    /// <summary>Releases the vault lock. Does not dispose the keys: the caller owns them (disposing them = locking).</summary>
    public void Dispose()
    {
        lock (_gate)
        {
            if (_disposed) return;
            _disposed = true;
            _lockStream?.Dispose();
            _lockStream = null;
        }
    }
}
