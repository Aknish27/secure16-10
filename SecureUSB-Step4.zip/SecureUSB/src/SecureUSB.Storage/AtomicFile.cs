namespace SecureUSB.Storage;

/// <summary>
/// Crash-safe file primitives. A file is written completely to "name.tmp", flushed to the device
/// (FlushFileBuffers), and only then moved over the real name. A reader therefore sees either the old
/// content or the new content, never a half-written file - provided the OS rename is atomic
/// (NTFS: yes; FAT32/exFAT: delete+rename, so the recovery logic in the stores also handles the gap).
/// Limitation: the containing directory entry is not fsynced (not possible from .NET on Windows).
/// </summary>
public static class AtomicFile
{
    public const string TempSuffix = ".tmp";

    public static string TempPath(string path) => path + TempSuffix;

    /// <summary>Writes <paramref name="data"/> to <paramref name="path"/> atomically.</summary>
    public static void WriteAllBytes(string path, ReadOnlySpan<byte> data)
    {
        string tmp = TempPath(path);
        try
        {
            WriteDurable(tmp, data);
            Replace(tmp, path);
        }
        catch
        {
            TryDelete(tmp);
            throw;
        }
    }

    /// <summary>Writes a file and flushes it to the physical device before returning.</summary>
    public static void WriteDurable(string path, ReadOnlySpan<byte> data)
    {
        using var fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough);
        fs.Write(data);
        fs.Flush(flushToDisk: true);
    }

    /// <summary>Moves <paramref name="source"/> over <paramref name="destination"/>, replacing it.</summary>
    public static void Replace(string source, string destination) => File.Move(source, destination, overwrite: true);

    /// <returns>true if the file no longer exists afterwards.</returns>
    public static bool TryDelete(string path)
    {
        try
        {
            File.Delete(path);
            return !File.Exists(path);
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException)
        {
            return false;
        }
    }
}
