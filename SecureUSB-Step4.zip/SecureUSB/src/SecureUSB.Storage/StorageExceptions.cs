namespace SecureUSB.Storage;

/// <summary>Vault metadata or data is missing/damaged in a way that needs recovery (or the key is wrong).</summary>
public sealed class VaultCorruptException : Exception
{
    public VaultCorruptException(string message, Exception? inner = null) : base(message, inner) { }
}

public sealed class InsufficientSpaceException : IOException
{
    public InsufficientSpaceException(long neededBytes, long freeBytes)
        : base($"Not enough free space on the USB drive (need {ByteSize.Format(neededBytes)}, have {ByteSize.Format(freeBytes)}).")
    {
        NeededBytes = neededBytes;
        FreeBytes = freeBytes;
    }
    public long NeededBytes { get; }
    public long FreeBytes { get; }
}

public sealed class FileTooLargeException : IOException
{
    public FileTooLargeException(long sizeBytes, long maxBytes, string fileSystem)
        : base($"This file ({ByteSize.Format(sizeBytes)}) exceeds the {fileSystem} per-file limit ({ByteSize.Format(maxBytes)}) of this USB drive.") { }
}

public sealed class DuplicateEntryException : InvalidOperationException
{
    public DuplicateEntryException(string path) : base($"A file named '{path}' already exists in the vault.") { }
}

public sealed class EntryNotFoundException : InvalidOperationException
{
    public EntryNotFoundException(Guid id) : base($"No vault entry with ID {id:N}.") { }
}

public sealed class InvalidEntryNameException : ArgumentException
{
    public InvalidEntryNameException(string reason, string paramName) : base(reason, paramName) { }
}
