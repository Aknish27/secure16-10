namespace SecureUSB.Storage;

/// <summary>
/// Best-effort removal of PLAINTEXT temporary files (partial exports, decrypted previews):
/// overwrite with zeros, flush, delete.
/// LIMITATION: on flash media (USB sticks, SSDs) wear-levelling may leave the old data in other physical
/// blocks, and journaling file systems may keep copies. This reduces exposure; it is not a guarantee.
/// The real mitigation is to minimise plaintext on disk (decrypt to memory where possible).
/// </summary>
public static class FileWiper
{
    /// <returns>true if the file is gone afterwards.</returns>
    public static bool TryWipeAndDelete(string path)
    {
        try
        {
            if (!File.Exists(path)) return true;
            try { File.SetAttributes(path, FileAttributes.Normal); } catch { /* ignore */ }

            try
            {
                using var fs = new FileStream(path, FileMode.Open, FileAccess.Write, FileShare.None);
                long remaining = fs.Length;
                byte[] zeros = new byte[64 * 1024];
                while (remaining > 0)
                {
                    int n = (int)Math.Min(zeros.Length, remaining);
                    fs.Write(zeros, 0, n);
                    remaining -= n;
                }
                fs.Flush(flushToDisk: true);
            }
            catch
            {
                // could not overwrite (locked, device error): still try to delete below
            }

            File.Delete(path);
            return !File.Exists(path);
        }
        catch
        {
            return false;
        }
    }
}
