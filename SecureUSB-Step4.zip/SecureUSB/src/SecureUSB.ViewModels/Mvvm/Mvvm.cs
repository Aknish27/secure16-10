using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace SecureUSB.ViewModels.Mvvm;

public abstract class ObservableObject : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;

    protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return false;
        field = value;
        OnPropertyChanged(propertyName);
        return true;
    }

    protected void OnPropertyChanged([CallerMemberName] string? propertyName = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}

public interface IRaisableCommand : ICommand
{
    void RaiseCanExecuteChanged();
}

public sealed class RelayCommand : IRaisableCommand
{
    private readonly Action _execute;
    private readonly Func<bool>? _canExecute;

    public RelayCommand(Action execute, Func<bool>? canExecute = null)
    {
        _execute = execute ?? throw new ArgumentNullException(nameof(execute));
        _canExecute = canExecute;
    }

    public event EventHandler? CanExecuteChanged;
    public bool CanExecute(object? parameter) => _canExecute?.Invoke() ?? true;

    public void Execute(object? parameter)
    {
        if (CanExecute(parameter)) _execute();
    }

    public void RaiseCanExecuteChanged() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
}

public sealed class RelayCommand<T> : IRaisableCommand
{
    private readonly Action<T?> _execute;
    private readonly Func<T?, bool>? _canExecute;

    public RelayCommand(Action<T?> execute, Func<T?, bool>? canExecute = null)
    {
        _execute = execute ?? throw new ArgumentNullException(nameof(execute));
        _canExecute = canExecute;
    }

    public event EventHandler? CanExecuteChanged;
    public bool CanExecute(object? parameter) => _canExecute?.Invoke(Cast(parameter)) ?? true;

    public void Execute(object? parameter)
    {
        if (CanExecute(parameter)) _execute(Cast(parameter));
    }

    public void RaiseCanExecuteChanged() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);

    private static T? Cast(object? parameter) => parameter is T value ? value : default;
}

/// <summary>
/// Runs an async action without blocking the UI and without re-entrancy (the button is disabled while it runs).
/// Exceptions never escape to the dispatcher: they go to <see cref="ErrorHandler"/>.
/// </summary>
public sealed class AsyncRelayCommand : IRaisableCommand
{
    private readonly Func<Task> _execute;
    private readonly Func<bool>? _canExecute;
    private bool _running;

    public AsyncRelayCommand(Func<Task> execute, Func<bool>? canExecute = null)
    {
        _execute = execute ?? throw new ArgumentNullException(nameof(execute));
        _canExecute = canExecute;
    }

    public Func<Exception, Task>? ErrorHandler { get; set; }
    public bool IsRunning => _running;

    public event EventHandler? CanExecuteChanged;
    public bool CanExecute(object? parameter) => !_running && (_canExecute?.Invoke() ?? true);

    public async void Execute(object? parameter)
    {
        try { await ExecuteAsync(); }
        catch { /* ErrorHandler is always set by ViewModelBase; nothing may escape an async void */ }
    }

    public async Task ExecuteAsync()
    {
        if (!CanExecute(null)) return;
        _running = true;
        RaiseCanExecuteChanged();
        try
        {
            await _execute();
        }
        catch (Exception ex)
        {
            if (ErrorHandler is null) throw;
            await ErrorHandler(ex);
        }
        finally
        {
            _running = false;
            RaiseCanExecuteChanged();
        }
    }

    public void RaiseCanExecuteChanged() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
}

public abstract class ViewModelBase : ObservableObject
{
    protected AsyncRelayCommand AsyncCommand(Func<Task> execute, Func<bool>? canExecute = null) =>
        new(execute, canExecute) { ErrorHandler = OnCommandErrorAsync };

    /// <summary>Called when an async command throws. Default: ignore (override to show a message).</summary>
    protected virtual Task OnCommandErrorAsync(Exception ex) => Task.CompletedTask;

    protected static void Raise(IEnumerable<IRaisableCommand> commands)
    {
        foreach (IRaisableCommand c in commands) c.RaiseCanExecuteChanged();
    }
}
