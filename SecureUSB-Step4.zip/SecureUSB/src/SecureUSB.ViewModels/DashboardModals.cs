using System.Collections.ObjectModel;
using System.Globalization;
using SecureUSB.Core;
using SecureUSB.Models;
using SecureUSB.Security;
using SecureUSB.Storage;
using SecureUSB.ViewModels.Mvvm;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.ViewModels;

// ===================================================================== change password

public sealed class ChangePasswordViewModel : ModalViewModel
{
    private static readonly string[] StrengthNames = { "Very weak", "Weak", "Fair", "Strong", "Very strong" };

    private readonly VaultService _service;
    private string _current = "", _new = "", _confirm = "", _error = "";
    private bool _show, _busy;
    private PasswordAssessment _assessment = PasswordPolicy.Evaluate("");

    public ChangePasswordViewModel(VaultService service)
    {
        _service = service;
        ChangeCommand = AsyncCommand(ChangeAsync, () => CanChange);
        ToggleShowPasswordsCommand = new RelayCommand(() => ShowPasswords = !ShowPasswords);
    }

    public override string Title => "Change password";
    public AsyncRelayCommand ChangeCommand { get; }
    public RelayCommand ToggleShowPasswordsCommand { get; }
    public bool Succeeded { get; private set; }

    public string CurrentPassword { get => _current; set { if (SetProperty(ref _current, value)) Changed(); } }

    public string NewPassword
    {
        get => _new;
        set
        {
            if (!SetProperty(ref _new, value)) return;
            _assessment = PasswordPolicy.Evaluate(value);
            OnPropertyChanged(nameof(StrengthLevel));
            OnPropertyChanged(nameof(StrengthText));
            OnPropertyChanged(nameof(StrengthFraction));
            OnPropertyChanged(nameof(PolicyMessages));
            Changed();
        }
    }

    public string Confirmation { get => _confirm; set { if (SetProperty(ref _confirm, value)) Changed(); } }
    public bool ShowPasswords { get => _show; set => SetProperty(ref _show, value); }
    public bool IsBusy { get => _busy; private set { if (SetProperty(ref _busy, value)) Changed(clearError: false); } }
    public string ErrorMessage { get => _error; private set { if (SetProperty(ref _error, value)) OnPropertyChanged(nameof(HasError)); } }
    public bool HasError => ErrorMessage.Length > 0;

    public int StrengthLevel => NewPassword.Length == 0 ? -1 : (int)_assessment.Strength;
    public string StrengthText => NewPassword.Length == 0 ? "" : StrengthNames[(int)_assessment.Strength];
    public double StrengthFraction => NewPassword.Length == 0 ? 0 : ((int)_assessment.Strength + 1) / 5.0;
    public IReadOnlyList<string> PolicyMessages =>
        NewPassword.Length == 0 ? Array.Empty<string>() : _assessment.Issues.Concat(_assessment.Suggestions).ToList();

    public string MismatchText =>
        Confirmation.Length > 0 && !string.Equals(NewPassword, Confirmation, StringComparison.Ordinal) ? "The passwords do not match." : "";

    public bool CanChange =>
        !IsBusy && CurrentPassword.Length > 0 && _assessment.MeetsPolicy &&
        string.Equals(NewPassword, Confirmation, StringComparison.Ordinal) &&
        !string.Equals(NewPassword, CurrentPassword, StringComparison.Ordinal);

    private void Changed(bool clearError = true)
    {
        if (clearError) ErrorMessage = "";
        OnPropertyChanged(nameof(MismatchText));
        OnPropertyChanged(nameof(CanChange));
        ChangeCommand.RaiseCanExecuteChanged();
    }

    private async Task ChangeAsync()
    {
        ErrorMessage = "";
        IsBusy = true;
        ChangePasswordResult? result = null;
        try
        {
            string cur = CurrentPassword, nw = NewPassword, conf = Confirmation;
            result = await Task.Run(() => _service.ChangePassword(cur, nw, conf));
        }
        catch (VaultLockedException)
        {
            RequestClose();   // the vault locked meanwhile (USB removed, auto-lock): nothing left to do here
            return;
        }
        catch (Exception ex)
        {
            ErrorMessage = ErrorMessages.Describe(ex);
        }
        finally
        {
            IsBusy = false;
        }

        if (result is null) return;
        switch (result.Status)
        {
            case ChangePasswordStatus.Success:
                Succeeded = true;
                Clear();
                RequestClose();
                break;
            case ChangePasswordStatus.WrongCurrentPassword:
                ErrorMessage = "The current password is incorrect.";
                break;
            default:
                ErrorMessage = $"Too many failed attempts. Try again in {FormatDelay(result.RetryAfter)}.";
                break;
        }
    }

    private void Clear()
    {
        _current = _new = _confirm = "";
        _assessment = PasswordPolicy.Evaluate("");
        OnPropertyChanged(nameof(CurrentPassword));
        OnPropertyChanged(nameof(NewPassword));
        OnPropertyChanged(nameof(Confirmation));
        OnPropertyChanged(nameof(StrengthLevel));
        OnPropertyChanged(nameof(StrengthText));
        OnPropertyChanged(nameof(StrengthFraction));
        OnPropertyChanged(nameof(PolicyMessages));
    }

    protected override Task OnCommandErrorAsync(Exception ex)
    {
        ErrorMessage = ErrorMessages.Describe(ex);
        return Task.CompletedTask;
    }

    public override void OnClosed() => Clear();

    internal static string FormatDelay(TimeSpan t)
    {
        if (t.TotalMinutes >= 1)
        {
            int m = (int)Math.Ceiling(t.TotalMinutes);
            return $"{m} minute{(m == 1 ? "" : "s")}";
        }
        int s = Math.Max(1, (int)Math.Ceiling(t.TotalSeconds));
        return $"{s} second{(s == 1 ? "" : "s")}";
    }
}

// ===================================================================== activity log

public sealed record ActivityRow(string Time, string Kind, string Message, string Severity);

public static class ActivityKindText
{
    public static string Describe(ActivityKind kind) => kind switch
    {
        ActivityKind.VaultCreated => "Vault created",
        ActivityKind.UnlockSucceeded => "Unlocked",
        ActivityKind.UnlockFailuresReported => "Failed unlock attempts",
        ActivityKind.VaultLocked => "Locked",
        ActivityKind.FileAdded => "File added",
        ActivityKind.FolderAdded => "Folder added",
        ActivityKind.FileExported => "File exported",
        ActivityKind.FileOpenedExternally => "Opened in another program",
        ActivityKind.FileRenamed => "File renamed",
        ActivityKind.FileDeleted => "File deleted",
        ActivityKind.PasswordChanged => "Password changed",
        ActivityKind.UsbRemoved => "USB drive removed",
        ActivityKind.IntegrityChecked => "Health check",
        ActivityKind.IntegrityRepaired => "Repair",
        ActivityKind.IndexRebuilt => "Index rebuilt",
        ActivityKind.HeaderRecoveredFromBackup => "Header recovered",
        ActivityKind.TempFilesCleaned => "Temporary files removed",
        _ => "Warning"
    };

    public static string SeverityOf(ActivityKind kind) => kind switch
    {
        ActivityKind.UnlockFailuresReported or ActivityKind.UsbRemoved or ActivityKind.Warning or
        ActivityKind.FileOpenedExternally or ActivityKind.HeaderRecoveredFromBackup or ActivityKind.IndexRebuilt => "Warning",
        _ => "Info"
    };
}

public sealed class ActivityLogViewModel : ModalViewModel
{
    private readonly VaultService _service;
    private List<ActivityEvent> _events = new();
    private string _filter = "", _warning = "", _error = "";
    private bool _loading;
    private ObservableCollection<ActivityRow> _rows = new();

    public ActivityLogViewModel(VaultService service)
    {
        _service = service;
        RefreshCommand = AsyncCommand(LoadAsync, () => !IsLoading);
        LoadTask = LoadAsync();
    }

    public override string Title => "Activity log";
    public Task LoadTask { get; }
    public AsyncRelayCommand RefreshCommand { get; }
    public ObservableCollection<ActivityRow> Rows { get => _rows; private set => SetProperty(ref _rows, value); }
    public string WarningText { get => _warning; private set { if (SetProperty(ref _warning, value)) OnPropertyChanged(nameof(HasWarning)); } }
    public bool HasWarning => WarningText.Length > 0;
    public string ErrorMessage { get => _error; private set => SetProperty(ref _error, value); }
    public bool IsLoading { get => _loading; private set { if (SetProperty(ref _loading, value)) RefreshCommand.RaiseCanExecuteChanged(); } }

    public string FilterText
    {
        get => _filter;
        set
        {
            if (SetProperty(ref _filter, value)) ApplyFilter();
        }
    }

    private async Task LoadAsync()
    {
        IsLoading = true;
        ErrorMessage = "";
        try
        {
            ActivityLogReadResult r = await Task.Run(() => _service.ReadActivityLog());
            _events = r.Events.Reverse().ToList();   // newest first
            WarningText = r.TamperDetected
                ? "Part of the log failed verification and was ignored. Someone may have modified the log."
                : r.TornTail ? "The last entry was incomplete (the drive may have been removed while writing)." : "";
            ApplyFilter();
        }
        catch (VaultLockedException)
        {
            RequestClose();
        }
        catch (Exception ex)
        {
            ErrorMessage = ErrorMessages.Describe(ex);
        }
        finally
        {
            IsLoading = false;
        }
    }

    private void ApplyFilter()
    {
        string q = FilterText.Trim();
        IEnumerable<ActivityEvent> source = q.Length == 0
            ? _events
            : _events.Where(e => e.Message.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                                 ActivityKindText.Describe(e.Kind).Contains(q, StringComparison.OrdinalIgnoreCase));
        Rows = new ObservableCollection<ActivityRow>(source.Select(e => new ActivityRow(
            e.TimestampUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
            ActivityKindText.Describe(e.Kind), e.Message, ActivityKindText.SeverityOf(e.Kind))));
    }

    protected override Task OnCommandErrorAsync(Exception ex)
    {
        ErrorMessage = ErrorMessages.Describe(ex);
        return Task.CompletedTask;
    }
}

// ===================================================================== health / integrity

public sealed record HealthIssueRow(string Severity, string Message);

public sealed class HealthViewModel : ModalViewModel
{
    private readonly VaultService _service;
    private readonly IDialogService _dialogs;
    private readonly Action<IntegrityReport> _onReport;
    private readonly Action _onRepaired;
    private readonly TimeProvider _time;
    private CancellationTokenSource? _cts;
    private bool _busy, _recover = true, _deleteOrphans, _removeMissing;
    private string _progress = "", _result = "", _error = "";
    private ObservableCollection<HealthIssueRow> _issues = new();

    public HealthViewModel(VaultService service, HealthStatus status, IDialogService dialogs,
        Action<IntegrityReport> onReport, Action onRepaired, TimeProvider? time = null)
    {
        _service = service;
        Status = status;
        _dialogs = dialogs;
        _onReport = onReport;
        _onRepaired = onRepaired;
        _time = time ?? TimeProvider.System;

        QuickCheckCommand = AsyncCommand(() => CheckAsync(deep: false), () => !IsBusy);
        FullCheckCommand = AsyncCommand(() => CheckAsync(deep: true), () => !IsBusy);
        RepairCommand = AsyncCommand(RepairAsync, () => !IsBusy && Status.Report is { IsClean: false });
        CancelCommand = new RelayCommand(() => _cts?.Cancel(), () => IsBusy);
        Status.PropertyChanged += OnStatusChanged;
        if (Status.Report is not null) ShowIssues(Status.Report);
    }

    public override string Title => "Vault health";
    public HealthStatus Status { get; }
    public AsyncRelayCommand QuickCheckCommand { get; }
    public AsyncRelayCommand FullCheckCommand { get; }
    public AsyncRelayCommand RepairCommand { get; }
    public RelayCommand CancelCommand { get; }
    public ObservableCollection<HealthIssueRow> Issues { get => _issues; private set => SetProperty(ref _issues, value); }
    public bool HasIssues => Issues.Count > 0;
    public string ProgressText { get => _progress; private set => SetProperty(ref _progress, value); }
    public string ResultText { get => _result; private set => SetProperty(ref _result, value); }
    public string ErrorMessage { get => _error; private set => SetProperty(ref _error, value); }

    public bool IsBusy
    {
        get => _busy;
        private set
        {
            if (SetProperty(ref _busy, value)) RefreshCommands();
        }
    }

    public bool RecoverOrphans
    {
        get => _recover;
        set
        {
            if (!SetProperty(ref _recover, value)) return;
            if (value && _deleteOrphans) { _deleteOrphans = false; OnPropertyChanged(nameof(DeleteOrphans)); }
        }
    }

    public bool DeleteOrphans
    {
        get => _deleteOrphans;
        set
        {
            if (!SetProperty(ref _deleteOrphans, value)) return;
            if (value && _recover) { _recover = false; OnPropertyChanged(nameof(RecoverOrphans)); }
        }
    }

    public bool RemoveMissingEntries { get => _removeMissing; set => SetProperty(ref _removeMissing, value); }

    private void OnStatusChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(HealthStatus.Report)) RefreshCommands();
    }

    private void RefreshCommands() => Raise(new IRaisableCommand[] { QuickCheckCommand, FullCheckCommand, RepairCommand, CancelCommand });

    private async Task CheckAsync(bool deep)
    {
        ErrorMessage = "";
        ResultText = "";
        ProgressText = deep ? "Verifying every file\u2026" : "Checking\u2026";
        IsBusy = true;
        _cts = new CancellationTokenSource();
        try
        {
            CancellationToken ct = _cts.Token;
            var progress = new CallbackProgress<IntegrityProgress>(p => ProgressText = $"Verifying file {p.Done} of {p.Total}\u2026");
            IntegrityReport report = await Task.Run(() => _service.CheckIntegrity(deep, progress, ct), ct);
            Apply(report);
            ProgressText = "";
        }
        catch (OperationCanceledException)
        {
            ProgressText = "";
            ResultText = "The check was cancelled.";
        }
        catch (VaultLockedException)
        {
            RequestClose();
        }
        catch (Exception ex)
        {
            ProgressText = "";
            ErrorMessage = ErrorMessages.Describe(ex);
        }
        finally
        {
            _cts?.Dispose();
            _cts = null;
            IsBusy = false;
        }
    }

    private async Task RepairAsync()
    {
        IntegrityReport? report = Status.Report;
        if (report is null || report.IsClean) return;

        bool destructive = DeleteOrphans || RemoveMissingEntries;
        string warning = destructive
            ? "Some of the selected repairs permanently remove data from the vault (unlisted encrypted files, or list entries whose encrypted data is missing). This cannot be undone."
            : "Leftover temporary files will be removed, unlisted encrypted files will be recovered, and the backup header will be refreshed.";
        if (!await _dialogs.ConfirmAsync(new ConfirmRequest("Repair the vault?", warning, "Repair", "Cancel", destructive)))
            return;

        ErrorMessage = "";
        ResultText = "";
        ProgressText = "Repairing\u2026";
        IsBusy = true;
        _cts = new CancellationTokenSource();
        try
        {
            var options = new RepairOptions
            {
                Orphans = RecoverOrphans ? OrphanAction.Recover : DeleteOrphans ? OrphanAction.Delete : OrphanAction.Keep,
                RemoveEntriesWithMissingBlobs = RemoveMissingEntries,
                DeleteStaleTemps = true,
                SyncHeaderBackup = true
            };
            CancellationToken ct = _cts.Token;
            RepairResult r = await Task.Run(() => _service.RepairIntegrity(report, options, ct), ct);
            ResultText = $"Repair finished: {r.OrphansRecovered} file(s) recovered, {r.OrphansDeleted} unlisted file(s) deleted, " +
                         $"{r.EntriesRemoved} entr{(r.EntriesRemoved == 1 ? "y" : "ies")} removed, {r.TempFilesDeleted} temporary file(s) removed.";

            IntegrityReport after = await Task.Run(() => _service.CheckIntegrity(false, null, ct), ct);
            Apply(after);
            _onRepaired();
        }
        catch (OperationCanceledException)
        {
            ResultText = "The repair was cancelled.";
        }
        catch (VaultLockedException)
        {
            RequestClose();
        }
        catch (Exception ex)
        {
            ErrorMessage = ErrorMessages.Describe(ex);
        }
        finally
        {
            _cts?.Dispose();
            _cts = null;
            ProgressText = "";
            IsBusy = false;
        }
    }

    private void Apply(IntegrityReport report)
    {
        Status.Update(report, _time.GetUtcNow());
        ShowIssues(report);
        _onReport(report);
    }

    private void ShowIssues(IntegrityReport report)
    {
        Issues = new ObservableCollection<HealthIssueRow>(
            report.Issues.OrderByDescending(i => i.Severity).Select(i => new HealthIssueRow(i.Severity.ToString(), i.Message)));
        OnPropertyChanged(nameof(HasIssues));
    }

    protected override Task OnCommandErrorAsync(Exception ex)
    {
        ErrorMessage = ErrorMessages.Describe(ex);
        ProgressText = "";
        return Task.CompletedTask;
    }

    public override void OnClosed()
    {
        _cts?.Cancel();
        Status.PropertyChanged -= OnStatusChanged;
    }
}

/// <summary>Synchronous IProgress (unlike Progress&lt;T&gt;, which posts to a synchronisation context).</summary>
internal sealed class CallbackProgress<T> : IProgress<T>
{
    private readonly Action<T> _callback;
    public CallbackProgress(Action<T> callback) => _callback = callback;
    public void Report(T value) => _callback(value);
}

// ===================================================================== settings / about

public sealed class SettingsViewModel : ModalViewModel
{
    private readonly SessionSettings _settings;
    private readonly VaultService _service;
    private readonly IDialogService _dialogs;
    private string _tempMessage = "";

    public SettingsViewModel(SessionSettings settings, VaultService service, IDialogService dialogs, AppInfo app)
    {
        _settings = settings;
        _service = service;
        _dialogs = dialogs;
        App = app;
        ToggleOpenInOtherProgramsCommand = AsyncCommand(ToggleOpenAsync);
        CleanTemporaryFilesCommand = AsyncCommand(CleanAsync);
        _settings.PropertyChanged += OnSettingsChanged;
    }

    public override string Title => "Settings and about";
    public AppInfo App { get; }
    public IReadOnlyList<AutoLockChoice> AutoLockChoices => SessionSettings.AutoLockChoices;
    public AsyncRelayCommand ToggleOpenInOtherProgramsCommand { get; }
    public AsyncRelayCommand CleanTemporaryFilesCommand { get; }
    public string TemporaryFilesMessage { get => _tempMessage; private set => SetProperty(ref _tempMessage, value); }

    public AutoLockChoice SelectedAutoLock
    {
        get => SessionSettings.AutoLockChoices.FirstOrDefault(c => c.Minutes == _settings.AutoLockMinutes) ?? SessionSettings.AutoLockChoices[0];
        set
        {
            if (value is not null) _settings.AutoLockMinutes = value.Minutes;
        }
    }

    public bool AllowOpenInOtherPrograms => _settings.AllowOpenInOtherPrograms;

    public bool ShowPreview
    {
        get => _settings.ShowPreview;
        set => _settings.ShowPreview = value;
    }

    public bool IsLightTheme
    {
        get => _settings.Theme == ThemeKind.Light;
        set { if (value) _settings.Theme = ThemeKind.Light; }
    }

    public bool IsDarkTheme
    {
        get => _settings.Theme == ThemeKind.Dark;
        set { if (value) _settings.Theme = ThemeKind.Dark; }
    }

    public IReadOnlyList<string> SecuritySummary { get; } = new[]
    {
        "Files are encrypted with AES-256-GCM, each with its own random key.",
        "Your password is stretched with Argon2id; it is never stored or shown.",
        "File names, folders and the activity log are encrypted too.",
        "Everything is tamper-checked: changes to the vault are detected.",
        "Closing the vault or removing the USB drive wipes the keys from memory."
    };

    public IReadOnlyList<string> Limitations { get; } = new[]
    {
        "A forgotten password cannot be recovered: there is no backdoor.",
        "A weak password can be guessed offline by someone who copies the drive. Use a long passphrase.",
        "Malware or a keylogger on the computer you use can capture your password.",
        "Only run SecureUSB from a source you trust: a modified program could steal your password.",
        "Opening a file in another program leaves a temporary decrypted copy until you lock the vault."
    };

    private void OnSettingsChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        OnPropertyChanged(nameof(SelectedAutoLock));
        OnPropertyChanged(nameof(AllowOpenInOtherPrograms));
        OnPropertyChanged(nameof(ShowPreview));
        OnPropertyChanged(nameof(IsLightTheme));
        OnPropertyChanged(nameof(IsDarkTheme));
    }

    private async Task ToggleOpenAsync()
    {
        if (_settings.AllowOpenInOtherPrograms)
        {
            _settings.AllowOpenInOtherPrograms = false;
            return;
        }

        bool ok = await _dialogs.ConfirmAsync(new ConfirmRequest(
            "Allow opening files in other programs?",
            "To open a file in another program, SecureUSB must write a temporary decrypted copy to this computer. " +
            "It is deleted when you lock the vault, remove the USB drive or close SecureUSB, but another program may still keep copies. " +
            "Leave this off if the computer is not fully trusted.",
            "Allow", "Keep it off", IsDestructive: true));
        if (ok) _settings.AllowOpenInOtherPrograms = true;
        OnPropertyChanged(nameof(AllowOpenInOtherPrograms));
    }

    private async Task CleanAsync()
    {
        CleanupReport report = await Task.Run(() => _service.CleanTemporaryFiles());
        TemporaryFilesMessage = report.IsComplete
            ? (report.Deleted == 0 ? "There are no temporary decrypted files." : $"Removed {report.Deleted} temporary decrypted file(s).")
            : $"Removed {report.Deleted}; {report.Failed.Count} could not be removed because another program is using them. Close that program and try again.";
    }

    protected override Task OnCommandErrorAsync(Exception ex)
    {
        if (ex is not VaultLockedException) TemporaryFilesMessage = ErrorMessages.Describe(ex);
        return Task.CompletedTask;
    }

    public override void OnClosed() => _settings.PropertyChanged -= OnSettingsChanged;
}
