namespace SecureUSB.ViewModels;

public static class FileTypeDescriber
{
    private static readonly Dictionary<string, string> Known = new(StringComparer.OrdinalIgnoreCase)
    {
        [".pdf"] = "PDF document", [".doc"] = "Word document", [".docx"] = "Word document",
        [".xls"] = "Excel workbook", [".xlsx"] = "Excel workbook", [".ppt"] = "PowerPoint presentation",
        [".pptx"] = "PowerPoint presentation", [".txt"] = "Text file", [".md"] = "Markdown file",
        [".csv"] = "CSV file", [".json"] = "JSON file", [".xml"] = "XML file", [".log"] = "Log file",
        [".jpg"] = "JPEG image", [".jpeg"] = "JPEG image", [".png"] = "PNG image", [".gif"] = "GIF image",
        [".bmp"] = "Bitmap image", [".tif"] = "TIFF image", [".tiff"] = "TIFF image",
        [".mp4"] = "Video", [".mov"] = "Video", [".avi"] = "Video", [".mkv"] = "Video",
        [".mp3"] = "Audio", [".wav"] = "Audio", [".zip"] = "Compressed folder", [".7z"] = "Compressed archive",
        [".exe"] = "Application", [".msi"] = "Installer"
    };

    /// <param name="extension">Including the dot (e.g. ".pdf"), or empty.</param>
    public static string Describe(string extension)
    {
        if (string.IsNullOrEmpty(extension)) return "File";
        if (Known.TryGetValue(extension, out string? text)) return text;
        return extension.TrimStart('.').ToUpperInvariant() + " file";
    }
}
