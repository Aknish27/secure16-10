using System.Collections.ObjectModel;
using System.Security.Cryptography;
using System.Text;
using SecureUSB.Core;
using SecureUSB.Models;
using SecureUSB.Security;
using SecureUSB.Storage;
using SecureUSB.ViewModels.Mvvm;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.ViewModels;

/// <summary>
/// The main screen after unlocking. It contains NO cryptography or storage logic: every action calls
/// <see cref="VaultService"/>. Long operations run on background threads with a cancellable progress overlay;
/// when the vault locks (button, auto-lock, USB removal) the shell disposes this view-model, which empties the file
/// list and wipes any preview data.
/// </summary>
public enum BusyOutcome { Completed, Cancelled, Failed }

public sealed class DashboardViewModel : PageViewModel
{
    private const int MaxPreviewChars = 20_000;

    private readonly VaultService _service;
    private readonly VaultLocation _location;
    private readonly IShellNavigation _nav;
    private readonly IDialogService _dialogs;
    private readonly IFileDialogService _files;
    private readonly IShellLauncher _launcher;
    private readonly AppInfo _app;
    private readonly TimeProvider _time;
    private readonly List<IRaisableCommand> _commands = new();

    private IReadOnlyList<FileEntry> _all = Array.Empty<FileEntry>();
    private Dictionary<Guid, ItemStatus> _statuses = new();
    private IReadOnlyList<VaultItemViewModel> _selection = Array.Empty<VaultItemViewModel>();
    private ObservableCollection<VaultItemViewModel> _items = new();
    private ObservableCollection<BreadcrumbItem> _crumbs = new();
    private string _currentFolder = "", _search = "", _status = "";
    private bool _busy, _canCancel, _indeterminate = true, _disposed;
    private string _busyTitle = "", _busyDetail = "";
    private double _progressValue, _progressMax = 1;
    private CancellationTokenSource? _cts;
    private Task? _init;

    private int _previewVersion;
    private byte[]? _previewImage;
    private PreviewKind _previewKind;
    private string _previewTitle = "", _previewText = "", _previewMessage = "";

    public DashboardViewModel(VaultService service, VaultLocation location, IShellNavigation nav, IDialogService dialogs,
        IFileDialogService files, IShellLauncher launcher, SessionSettings settings, AppInfo app, TimeProvider? time = null)
    {
        _service = service;
        _location = location;
        _nav = nav;
        _dialogs = dialogs;
        _files = files;
        _launcher = launcher;
        _app = app;
        _time = time ?? TimeProvider.System;
        Settings = settings;

        AddFilesCommand = Track(AsyncCommand(AddFilesAsync, () => !IsBusy));
        AddFolderCommand = Track(AsyncCommand(AddFolderAsync, () => !IsBusy));
        ExportCommand = Track(AsyncCommand(ExportAsync, () => !IsBusy && HasSelection));
        OpenExternalCommand = Track(AsyncCommand(OpenExternalAsync, () => !IsBusy && OpenExternalAvailable && SingleFileSelected));
        RenameCommand = Track(AsyncCommand(RenameAsync, () => !IsBusy && SingleFileSelected));
        DeleteCommand = Track(AsyncCommand(DeleteAsync, () => !IsBusy && HasSelection));
        LockCommand = Track(AsyncCommand(LockAsync));
        ChangePasswordCommand = Track(AsyncCommand(ChangePasswordAsync, () => !IsBusy));
        ActivityLogCommand = Track(AsyncCommand(ShowActivityLogAsync, () => !IsBusy));
        HealthCommand = Track(AsyncCommand(ShowHealthAsync, () => !IsBusy));
        SettingsCommand = Track(AsyncCommand(ShowSettingsAsync, () => !IsBusy));
        RefreshCommand = Track(AsyncCommand(RefreshAllAsync, () => !IsBusy));
        UpCommand = Track(new RelayCommand(GoUp, () => CurrentFolder.Length > 0 && !IsSearching));
        ClearSearchCommand = Track(new RelayCommand(() => SearchText = "", () => SearchText.Length > 0));
        CancelCommand = Track(new RelayCommand(() => _cts?.Cancel(), () => IsBusy && CanCancel));
        OpenItemCommand = new RelayCommand<VaultItemViewModel>(OpenItem);
        NavigateToCommand = new RelayCommand<BreadcrumbItem>(b => { if (b is not null) NavigateTo(b.Path); });

        Settings.PropertyChanged += OnSettingsChanged;
        RebuildBreadcrumbs();
    }

    // ------------------------------------------------------------------ state exposed to the view

    public SessionSettings Settings { get; }
    public StorageViewModel Storage { get; } = new();
    public HealthStatus Health { get; } = new();
    public string VaultName => _location.DisplayName;

    public AsyncRelayCommand AddFilesCommand { get; }
    public AsyncRelayCommand AddFolderCommand { get; }
    public AsyncRelayCommand ExportCommand { get; }
    public AsyncRelayCommand OpenExternalCommand { get; }
    public AsyncRelayCommand RenameCommand { get; }
    public AsyncRelayCommand DeleteCommand { get; }
    public AsyncRelayCommand LockCommand { get; }
    public AsyncRelayCommand ChangePasswordCommand { get; }
    public AsyncRelayCommand ActivityLogCommand { get; }
    public AsyncRelayCommand HealthCommand { get; }
    public AsyncRelayCommand SettingsCommand { get; }
    public AsyncRelayCommand RefreshCommand { get; }
    public RelayCommand UpCommand { get; }
    public RelayCommand ClearSearchCommand { get; }
    public RelayCommand CancelCommand { get; }
    public RelayCommand<VaultItemViewModel> OpenItemCommand { get; }
    public RelayCommand<BreadcrumbItem> NavigateToCommand { get; }

    public ObservableCollection<VaultItemViewModel> Items { get => _items; private set => SetProperty(ref _items, value); }
    public ObservableCollection<BreadcrumbItem> Breadcrumbs { get => _crumbs; private set => SetProperty(ref _crumbs, value); }
    public string CurrentFolder { get => _currentFolder; private set => SetProperty(ref _currentFolder, value); }
    public bool HasItems => Items.Count > 0;
    public bool IsSearching => _search.Trim().Length > 0;

    public string EmptyText => IsSearching ? "No files match your search."
        : CurrentFolder.Length > 0 ? "This folder is empty." : "Your vault is empty. Choose \"Add files\" to protect your first file.";

    public string ItemCountText => IsSearching
        ? $"{Items.Count} result{(Items.Count == 1 ? "" : "s")}"
        : $"{Items.Count} item{(Items.Count == 1 ? "" : "s")}";

    public string SearchText
    {
        get => _search;
        set
        {
            if (!SetProperty(ref _search, value)) return;
            _nav.NotifyActivity();
            ApplyFilter();
            ClearSearchCommand.RaiseCanExecuteChanged();
            UpCommand.RaiseCanExecuteChanged();
            OnPropertyChanged(nameof(IsSearching));
        }
    }

    public string StatusMessage { get => _status; private set => SetProperty(ref _status, value); }

    // selection
    public bool HasSelection => _selection.Count > 0;
    public bool SingleFileSelected => _selection.Count == 1 && !_selection[0].IsFolder;
    public bool OpenExternalAvailable => Settings.AllowOpenInOtherPrograms;

    public string SelectionSummary => _selection.Count switch
    {
        0 => "",
        1 => _selection[0].Name,
        _ => $"{_selection.Count} items selected"
    };

    // busy overlay
    public bool IsBusy { get => _busy; private set { if (SetProperty(ref _busy, value)) RefreshCommands(); } }
    public bool CanCancel { get => _canCancel; private set { if (SetProperty(ref _canCancel, value)) CancelCommand.RaiseCanExecuteChanged(); } }
    public string BusyTitle { get => _busyTitle; private set => SetProperty(ref _busyTitle, value); }
    public string BusyDetail { get => _busyDetail; private set => SetProperty(ref _busyDetail, value); }
    public bool IsIndeterminate { get => _indeterminate; private set => SetProperty(ref _indeterminate, value); }
    public double ProgressValue { get => _progressValue; private set => SetProperty(ref _progressValue, value); }
    public double ProgressMax { get => _progressMax; private set => SetProperty(ref _progressMax, value); }

    // preview (in memory only)
    public Task PreviewTask { get; private set; } = Task.CompletedTask;
    public PreviewKind PreviewKind { get => _previewKind; private set => SetProperty(ref _previewKind, value); }
    public string PreviewTitle { get => _previewTitle; private set => SetProperty(ref _previewTitle, value); }
    public string PreviewText { get => _previewText; private set => SetProperty(ref _previewText, value); }
    public string PreviewMessage { get => _previewMessage; private set => SetProperty(ref _previewMessage, value); }
    public byte[]? PreviewImageData { get => _previewImage; private set => SetProperty(ref _previewImage, value); }

    // ------------------------------------------------------------------ loading

    /// <summary>Loads the file list, the storage numbers and a quick health check. Safe to call more than once.</summary>
    public Task InitializeAsync() => _init ??= InitializeCoreAsync();

    private async Task InitializeCoreAsync()
    {
        await RefreshAsync();
        await RefreshStorageAsync();
        await QuickHealthAsync();
    }

    public async Task RefreshAsync()
    {
        try
        {
            IReadOnlyList<FileEntry> entries = await Task.Run(() => _service.ListFiles());
            if (_disposed) return;
            _all = entries;
            ApplyFilter();
        }
        catch (Exception ex)
        {
            await ReportAsync(ex);
        }
    }

    public async Task RefreshStorageAsync()
    {
        try
        {
            StorageUsage usage = await Task.Run(() => _service.GetStorageUsage());
            if (!_disposed) Storage.Update(usage);
        }
        catch (VaultLockedException) { }
        catch (Exception)
        {
            if (!_disposed) Storage.SetUnavailable();
        }
    }

    private async Task QuickHealthAsync()
    {
        try
        {
            IntegrityReport report = await Task.Run(() => _service.CheckIntegrity(false));
            if (_disposed) return;
            Health.Update(report, _time.GetUtcNow());
            ApplyReportStatuses(report);
        }
        catch (VaultLockedException) { }
        catch (Exception)
        {
            if (!_disposed) Health.SetUnavailable();
        }
    }

    private async Task RefreshAllAsync()
    {
        await RefreshAsync();
        await RefreshStorageAsync();
        await QuickHealthAsync();
    }

    private void ApplyFilter()
    {
        Items = new ObservableCollection<VaultItemViewModel>(VaultItemBuilder.Build(_all, CurrentFolder, SearchText, _statuses));
        OnPropertyChanged(nameof(HasItems));
        OnPropertyChanged(nameof(EmptyText));
        OnPropertyChanged(nameof(ItemCountText));
        SetSelection(Array.Empty<VaultItemViewModel>());
    }

    private void ApplyReportStatuses(IntegrityReport report)
    {
        var map = new Dictionary<Guid, ItemStatus>();
        foreach (IntegrityIssue issue in report.Issues)
        {
            if (issue.FileId is Guid id && issue.Severity == IssueSeverity.Error &&
                issue.Kind is IssueKind.BlobMissing or IssueKind.BlobSizeMismatch or IssueKind.BlobUnreadable or IssueKind.BlobAuthenticationFailed)
                map[id] = ItemStatus.Damaged;
        }
        _statuses = map;
        if (!_disposed) ApplyFilter();
    }

    // ------------------------------------------------------------------ navigation and selection

    private void GoUp()
    {
        int slash = CurrentFolder.LastIndexOf('/');
        NavigateTo(slash < 0 ? "" : CurrentFolder[..slash]);
    }

    public void NavigateTo(string folderPath)
    {
        _nav.NotifyActivity();
        _search = "";
        OnPropertyChanged(nameof(SearchText));
        OnPropertyChanged(nameof(IsSearching));
        CurrentFolder = folderPath;
        RebuildBreadcrumbs();
        ApplyFilter();
        RefreshCommands();
    }

    private void RebuildBreadcrumbs()
    {
        var list = new List<BreadcrumbItem> { new("Vault", "") };
        if (CurrentFolder.Length > 0)
        {
            string path = "";
            foreach (string segment in CurrentFolder.Split('/'))
            {
                path = path.Length == 0 ? segment : path + "/" + segment;
                list.Add(new BreadcrumbItem(segment, path));
            }
        }
        Breadcrumbs = new ObservableCollection<BreadcrumbItem>(list);
    }

    private void OpenItem(VaultItemViewModel? item)
    {
        if (item is null) return;
        if (item.IsFolder)
        {
            NavigateTo(item.FolderFullPath);
            return;
        }
        SetSelection(new[] { item });
        if (OpenExternalAvailable && OpenExternalCommand.CanExecute(null)) OpenExternalCommand.Execute(null);
    }

    /// <summary>Called by the view when the table selection changes.</summary>
    public void SetSelection(IEnumerable<VaultItemViewModel> items)
    {
        _selection = items.ToList();
        _nav.NotifyActivity();
        OnPropertyChanged(nameof(HasSelection));
        OnPropertyChanged(nameof(SingleFileSelected));
        OnPropertyChanged(nameof(SelectionSummary));
        RefreshCommands();
        PreviewTask = UpdatePreviewAsync();
    }

    // ------------------------------------------------------------------ preview

    private async Task UpdatePreviewAsync()
    {
        int version = ++_previewVersion;
        ClearPreviewData();
        PreviewMessage = "";

        if (!Settings.ShowPreview || _selection.Count != 1 || _selection[0].IsFolder)
        {
            PreviewKind = PreviewKind.None;
            PreviewTitle = Settings.ShowPreview && _selection.Count > 1 ? SelectionSummary : "";
            return;
        }

        FileEntry entry = _selection[0].Entry!;
        PreviewTitle = entry.Name;
        PreviewKind kind = PreviewClassifier.Classify(entry.Extension, entry.SizeBytes);
        if (kind == PreviewKind.Unsupported)
        {
            PreviewKind = kind;
            PreviewMessage = "No preview is available for this type of file.";
            return;
        }
        if (kind == PreviewKind.TooLarge)
        {
            PreviewKind = kind;
            PreviewMessage = "This file is too large to preview.";
            return;
        }

        PreviewKind = PreviewKind.Loading;
        long limit = PreviewClassifier.LimitFor(kind);
        try
        {
            byte[] data = await Task.Run(() => _service.ReadFileForPreview(entry.Id, limit));
            if (version != _previewVersion || _disposed)
            {
                CryptographicOperations.ZeroMemory(data);
                return;
            }

            if (kind == PreviewKind.Image)
            {
                PreviewImageData = data;   // the view decodes it; the array is wiped as soon as the selection changes
            }
            else
            {
                string text = Encoding.UTF8.GetString(data);
                CryptographicOperations.ZeroMemory(data);
                PreviewText = text.Length > MaxPreviewChars ? text[..MaxPreviewChars] + "\n\u2026 (preview shortened)" : text;
            }
            PreviewKind = kind;
        }
        catch (VaultLockedException)
        {
            if (version == _previewVersion) PreviewKind = PreviewKind.None;
        }
        catch (Exception ex)
        {
            if (version != _previewVersion || _disposed) return;
            PreviewKind = PreviewKind.Error;
            PreviewMessage = ErrorMessages.Describe(ex);
        }
    }

    private void ClearPreviewData()
    {
        byte[]? old = _previewImage;
        PreviewImageData = null;
        if (old is not null) CryptographicOperations.ZeroMemory(old);
        PreviewText = "";
    }

    // ------------------------------------------------------------------ file operations

    private async Task AddFilesAsync()
    {
        IReadOnlyList<string> paths = _files.PickFiles("Add files to the vault");
        if (paths.Count == 0) return;

        string folder = CurrentFolder;
        int added = 0;
        var failures = new List<string>();

        BusyOutcome outcome = await RunBusyAsync("Encrypting files\u2026", async ct =>
        {
            IsIndeterminate = false;
            ProgressMax = paths.Count;
            for (int i = 0; i < paths.Count; i++)
            {
                ct.ThrowIfCancellationRequested();
                string path = paths[i];
                string name = Path.GetFileName(path);
                BusyDetail = $"{i + 1} of {paths.Count}: {name}";
                ProgressValue = i;
                try
                {
                    await Task.Run(() => _service.AddFile(path, folder, ConflictPolicy.AutoRename, ct), ct);
                    added++;
                }
                catch (Exception ex) when (ex is not OperationCanceledException and not VaultLockedException)
                {
                    failures.Add($"{name}: {ErrorMessages.Describe(ex)}");
                }
            }
            ProgressValue = paths.Count;
        });

        await SummariseAsync("added to the vault", added, failures, outcome);
    }

    private async Task AddFolderAsync()
    {
        string? folder = _files.PickFolder("Choose a folder to add to the vault");
        if (string.IsNullOrWhiteSpace(folder)) return;

        string target = CurrentFolder;
        AddFolderResult? result = null;
        BusyOutcome outcome = await RunBusyAsync("Encrypting folder\u2026", async ct =>
        {
            var progress = new CallbackProgress<string>(p => BusyDetail = Path.GetFileName(p));
            result = await Task.Run(() => _service.AddFolder(folder, target, ConflictPolicy.AutoRename, progress, ct), ct);
        });

        var failures = new List<string>();
        if (result is not null)
            failures.AddRange(result.Failures.Select(f => $"{Path.GetFileName(f.Path)}: {ReasonText(f.Reason)}"));
        await SummariseAsync("added to the vault", result?.Added ?? 0, failures, outcome);
    }

    private static string ReasonText(string reason) =>
        reason.StartsWith("Skipped", StringComparison.Ordinal) ? reason.TrimEnd('.') :
        reason.Contains("already exists", StringComparison.OrdinalIgnoreCase) ? "a file with this name already exists" :
        "could not be added";

    private async Task ExportAsync()
    {
        List<(FileEntry Entry, string Folder)> work = ExpandSelection();
        if (work.Count == 0) return;

        string? destination = _files.PickFolder("Choose where to save the decrypted copies");
        if (string.IsNullOrWhiteSpace(destination)) return;

        bool sameDrive = string.Equals(
            Path.GetPathRoot(Path.GetFullPath(destination)), Path.GetPathRoot(Path.GetFullPath(_location.Root)),
            StringComparison.OrdinalIgnoreCase);
        string message = $"{(work.Count == 1 ? "This file" : $"These {work.Count} files")} will be saved as ordinary, unprotected " +
                         "files in the folder you chose. Anyone with access to that folder can read them." +
                         (sameDrive ? "\n\nThat folder is on the same drive as your vault: the decrypted copies would sit next to the protected data." : "");
        if (!await _dialogs.ConfirmAsync(new ConfirmRequest("Export decrypted copies?", message, "Export", "Cancel", sameDrive)))
            return;

        int done = 0;
        var failures = new List<string>();
        BusyOutcome outcome = await RunBusyAsync("Decrypting and exporting\u2026", async ct =>
        {
            IsIndeterminate = false;
            ProgressMax = work.Count;
            for (int i = 0; i < work.Count; i++)
            {
                ct.ThrowIfCancellationRequested();
                (FileEntry entry, string relative) = work[i];
                BusyDetail = $"{i + 1} of {work.Count}: {entry.Name}";
                ProgressValue = i;
                try
                {
                    string dir = relative.Length == 0
                        ? destination
                        : Path.Combine(destination, FilenameSanitizer.SanitizeFolderPath(relative).Replace('/', Path.DirectorySeparatorChar));
                    if (File.Exists(Path.Combine(dir, entry.Name)))
                    {
                        failures.Add($"{entry.Name}: a file with this name already exists in the destination folder (not replaced)");
                        continue;
                    }
                    await Task.Run(() =>
                    {
                        Directory.CreateDirectory(dir);
                        _service.ExportFile(entry.Id, dir, null, false, ct);
                    }, ct);
                    done++;
                }
                catch (Exception ex) when (ex is not OperationCanceledException and not VaultLockedException)
                {
                    failures.Add($"{entry.Name}: {ErrorMessages.Describe(ex)}");
                }
            }
            ProgressValue = work.Count;
        });

        await SummariseAsync("exported", done, failures, outcome);
    }

    private async Task OpenExternalAsync()
    {
        if (!SingleFileSelected || !OpenExternalAvailable) return;
        FileEntry entry = _selection[0].Entry!;

        bool ok = await _dialogs.ConfirmAsync(new ConfirmRequest(
            "Open in another program?",
            $"\"{entry.Name}\" will be decrypted to a temporary file on this computer so another program can open it. " +
            "The temporary copy is deleted when you lock the vault, remove the USB drive or close SecureUSB. " +
            "Changes you make there are NOT saved back into the vault.",
            "Open", "Cancel", IsDestructive: true));
        if (!ok) return;

        await RunBusyAsync("Decrypting\u2026", async ct =>
        {
            string path = await Task.Run(() => _service.OpenTemporaryCopy(entry.Id, ct), ct);
            _launcher.OpenFile(path);   // the path is handed to Windows only; it is never shown or stored here
            StatusMessage = "Opened in the default program. The temporary copy is removed when the vault locks.";
        }, cancellable: false);
    }

    private async Task RenameAsync()
    {
        if (!SingleFileSelected) return;
        VaultItemViewModel item = _selection[0];
        string? name = await _dialogs.PromptAsync(new PromptRequest("Rename file", "Enter a new name for this file.", item.Name, "Rename"));
        if (name is null) return;
        name = name.Trim();
        if (name.Length == 0 || name == item.Name) return;

        try
        {
            await Task.Run(() => _service.RenameFile(item.Entry!.Id, name));
            StatusMessage = "File renamed.";
        }
        catch (Exception ex)
        {
            await ReportAsync(ex);
        }
        if (!_disposed && _service.IsUnlocked) await RefreshAsync();
    }

    private async Task DeleteAsync()
    {
        List<(FileEntry Entry, string Folder)> work = ExpandSelection();
        if (work.Count == 0) return;

        bool hasFolder = _selection.Any(s => s.IsFolder);
        string what = work.Count == 1 && !hasFolder ? $"\"{work[0].Entry.Name}\""
            : hasFolder ? $"{work.Count} file{(work.Count == 1 ? "" : "s")} (including everything inside the selected folder{(_selection.Count(s => s.IsFolder) == 1 ? "" : "s")})"
            : $"{work.Count} files";
        if (!await _dialogs.ConfirmAsync(new ConfirmRequest(
                "Delete from the vault?", $"Permanently delete {what}? This cannot be undone.", "Delete", "Cancel", IsDestructive: true)))
            return;

        int deleted = 0;
        var failures = new List<string>();
        BusyOutcome outcome = await RunBusyAsync("Deleting\u2026", async ct =>
        {
            IsIndeterminate = false;
            ProgressMax = work.Count;
            for (int i = 0; i < work.Count; i++)
            {
                ct.ThrowIfCancellationRequested();
                FileEntry entry = work[i].Entry;
                BusyDetail = $"{i + 1} of {work.Count}: {entry.Name}";
                ProgressValue = i;
                try
                {
                    await Task.Run(() => _service.DeleteFile(entry.Id), ct);
                    deleted++;
                }
                catch (Exception ex) when (ex is not OperationCanceledException and not VaultLockedException)
                {
                    failures.Add($"{entry.Name}: {ErrorMessages.Describe(ex)}");
                }
            }
            ProgressValue = work.Count;
        });

        await SummariseAsync("deleted", deleted, failures, outcome);
    }

    /// <summary>The files behind the selection; folders expand to everything inside them (with their relative folder).</summary>
    private List<(FileEntry Entry, string Folder)> ExpandSelection()
    {
        var map = new Dictionary<Guid, (FileEntry Entry, string Folder)>();
        foreach (VaultItemViewModel item in _selection)
        {
            if (!item.IsFolder)
            {
                map.TryAdd(item.Entry!.Id, (item.Entry, ""));
                continue;
            }
            foreach (FileEntry e in VaultItemBuilder.FilesUnder(_all, item.FolderFullPath))
            {
                string tail = e.FolderPath.Length > item.FolderFullPath.Length ? e.FolderPath[item.FolderFullPath.Length..] : "";
                map.TryAdd(e.Id, (e, item.Name + tail));
            }
        }
        return map.Values.ToList();
    }

    // ------------------------------------------------------------------ lock, password, log, health, settings

    private async Task LockAsync()
    {
        _cts?.Cancel();
        await Task.Run(() => _service.Lock());   // the Locked event moves the shell to the unlock screen
    }

    private async Task ChangePasswordAsync()
    {
        var vm = new ChangePasswordViewModel(_service);
        await _dialogs.ShowModalAsync(vm);
        if (vm.Succeeded) StatusMessage = "Password changed.";
    }

    private async Task ShowActivityLogAsync() => await _dialogs.ShowModalAsync(new ActivityLogViewModel(_service));

    private async Task ShowHealthAsync()
    {
        var vm = new HealthViewModel(_service, Health, _dialogs, ApplyReportStatuses, () => _ = RefreshAfterRepairAsync(), _time);
        await _dialogs.ShowModalAsync(vm);
    }

    private async Task RefreshAfterRepairAsync()
    {
        if (_disposed) return;
        await RefreshAsync();
        await RefreshStorageAsync();
    }

    private async Task ShowSettingsAsync() =>
        await _dialogs.ShowModalAsync(new SettingsViewModel(Settings, _service, _dialogs, _app));

    // ------------------------------------------------------------------ plumbing

    private async Task<BusyOutcome> RunBusyAsync(string title, Func<CancellationToken, Task> work, bool cancellable = true)
    {
        _nav.NotifyActivity();
        _cts = new CancellationTokenSource();
        BusyTitle = title;
        BusyDetail = "";
        CanCancel = cancellable;
        IsIndeterminate = true;
        ProgressValue = 0;
        ProgressMax = 1;
        IsBusy = true;

        BusyOutcome outcome = BusyOutcome.Completed;
        try
        {
            await work(_cts.Token);
        }
        catch (OperationCanceledException)
        {
            outcome = BusyOutcome.Cancelled;
        }
        catch (VaultLockedException)
        {
            outcome = BusyOutcome.Cancelled;   // the Locked event has already moved the UI to the unlock screen
        }
        catch (Exception ex)
        {
            outcome = BusyOutcome.Failed;
            await ReportAsync(ex);
        }
        finally
        {
            IsBusy = false;
            CancellationTokenSource? cts = _cts;
            _cts = null;
            cts?.Dispose();
        }

        if (!_disposed && _service.IsUnlocked)
        {
            await RefreshAsync();
            await RefreshStorageAsync();
        }
        return outcome;
    }

    private async Task SummariseAsync(string verb, int count, List<string> failures, BusyOutcome outcome)
    {
        if (_disposed) return;
        string text = $"{count} file{(count == 1 ? "" : "s")} {verb}.";
        if (outcome == BusyOutcome.Cancelled) text = "Cancelled. " + text;
        else if (outcome == BusyOutcome.Failed) text = "The operation stopped because of an error. " + text;
        if (failures.Count > 0) text += $" {failures.Count} could not be processed.";
        StatusMessage = text;

        if (failures.Count > 0)
        {
            string lines = string.Join("\n", failures.Take(8).Select(f => "\u2022 " + f));
            if (failures.Count > 8) lines += $"\n\u2026 and {failures.Count - 8} more.";
            await _dialogs.ShowMessageAsync("Some files were skipped", lines, MessageKind.Warning);
        }
    }

    private async Task ReportAsync(Exception ex)
    {
        if (_disposed || ex is VaultLockedException or OperationCanceledException) return;
        await _dialogs.ShowMessageAsync("Something went wrong", ErrorMessages.Describe(ex), MessageKind.Error);
    }

    protected override Task OnCommandErrorAsync(Exception ex) => ReportAsync(ex);

    private T Track<T>(T command) where T : IRaisableCommand
    {
        _commands.Add(command);
        return command;
    }

    private void RefreshCommands() => Raise(_commands);

    private void OnSettingsChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(SessionSettings.AllowOpenInOtherPrograms))
        {
            OnPropertyChanged(nameof(OpenExternalAvailable));
            RefreshCommands();
        }
        else if (e.PropertyName == nameof(SessionSettings.ShowPreview))
        {
            PreviewTask = UpdatePreviewAsync();
        }
    }

    public override void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _cts?.Cancel();
        Settings.PropertyChanged -= OnSettingsChanged;
        ClearPreviewData();
        PreviewKind = PreviewKind.None;
        PreviewTitle = "";
        _all = Array.Empty<FileEntry>();
        _statuses = new Dictionary<Guid, ItemStatus>();
        _selection = Array.Empty<VaultItemViewModel>();
        Items = new ObservableCollection<VaultItemViewModel>();
        OnPropertyChanged(nameof(HasItems));
        StatusMessage = "";
    }
}
