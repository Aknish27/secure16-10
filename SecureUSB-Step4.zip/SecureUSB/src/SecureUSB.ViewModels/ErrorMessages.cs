using System.Security.Cryptography;
using System.Text.RegularExpressions;
using SecureUSB.Core;
using SecureUSB.Storage;

namespace SecureUSB.ViewModels;

/// <summary>
/// Turns exceptions into short, user-safe sentences. Raw exception text is never shown: it can contain host paths,
/// drive letters, file names or internal details. Only messages written by SecureUSB itself for end users pass through.
/// </summary>
public static class ErrorMessages
{
    public const string Unexpected = "An unexpected error occurred. If it keeps happening, lock the vault and check the USB drive.";

    public static string Describe(Exception ex)
    {
        switch (ex)
        {
            case VaultLockedException:
                return "The vault is locked.";
            case OperationCanceledException:
                return "The operation was cancelled.";
            case PasswordRejectedException p:
                return string.Join(" ", p.Issues);
            case InvalidEntryNameException:
                return StripParameter(ex.Message);
            case DuplicateEntryException:
                return ex.Message;
            case EntryNotFoundException:
                return "That item no longer exists in the vault.";
            case InsufficientSpaceException:
            case FileTooLargeException:
                return ex.Message;
            case VaultCorruptException:
                return "The vault data is damaged. Open the health check to review and repair it.";
            case CryptographicException:
                return "This file failed its integrity check. It may be damaged, or it may have been tampered with.";
            case FileNotFoundException:
                return "The file could not be found.";
            case DirectoryNotFoundException:
                return "The folder could not be found.";
            case UnauthorizedAccessException:
                return "Access was denied. Check that the location is not read-only.";
            case IOException:
                return "A problem occurred while reading or writing the USB drive. Make sure it is connected and has free space.";
            case ObjectDisposedException:
                return "The vault is locked.";
            case ArgumentException:
            case InvalidOperationException:
                return OwnMessageOrGeneric(ex);
            default:
                return Unexpected;
        }
    }

    /// <summary>Messages written by SecureUSB's own code mention the vault/SecureUSB and contain no path.</summary>
    private static string OwnMessageOrGeneric(Exception ex)
    {
        string message = StripParameter(ex.Message);
        bool ours = message.Contains("vault", StringComparison.OrdinalIgnoreCase) ||
                    message.Contains("SecureUSB", StringComparison.OrdinalIgnoreCase);
        return ours && !LooksLikePath(message) ? message : Unexpected;
    }

    private static string StripParameter(string message)
    {
        int i = message.IndexOf(" (Parameter", StringComparison.Ordinal);
        return i >= 0 ? message[..i] : message;
    }

    private static bool LooksLikePath(string message) =>
        message.Contains('\\') || message.Contains(":/") || Regex.IsMatch(message, @"\b[A-Za-z]:[\\/]");
}
