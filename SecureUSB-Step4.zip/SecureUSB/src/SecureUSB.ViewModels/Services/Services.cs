using SecureUSB.Core;

namespace SecureUSB.ViewModels.Services;

/// <summary>Marshals work onto the UI thread and provides UI-thread timers (WPF: Dispatcher; tests: manual).</summary>
public interface IUiScheduler
{
    void Post(Action action);
    IDisposable Every(TimeSpan interval, Action tick);
}

public interface IFileDialogService
{
    /// <returns>The chosen files, or an empty list if cancelled.</returns>
    IReadOnlyList<string> PickFiles(string title);

    /// <returns>The chosen folder, or null if cancelled.</returns>
    string? PickFolder(string title);
}

public interface IShellLauncher
{
    /// <summary>Opens a file with the program Windows associates with it.</summary>
    void OpenFile(string path);
}

public enum MessageKind { Information, Warning, Error }

public sealed record ConfirmRequest(string Title, string Message, string ConfirmText = "OK", string CancelText = "Cancel", bool IsDestructive = false);

public sealed record PromptRequest(string Title, string Message, string InitialValue = "", string ConfirmText = "OK");

public interface IDialogService
{
    Task<bool> ConfirmAsync(ConfirmRequest request);

    /// <returns>The entered text, or null if cancelled.</returns>
    Task<string?> PromptAsync(PromptRequest request);

    Task ShowMessageAsync(string title, string message, MessageKind kind = MessageKind.Information);

    /// <summary>Shows a modal view-model and completes when it is closed.</summary>
    Task ShowModalAsync(ModalViewModel modal);
}

public interface IVaultServiceFactory
{
    VaultService Create(VaultLocation location);
}

public interface ILocationProvider
{
    /// <summary>Removable drives (and the drive SecureUSB runs from), with or without a vault.</summary>
    IReadOnlyList<VaultLocation> Discover();

    /// <summary>A location the user picked manually (any folder or drive root).</summary>
    VaultLocation FromFolder(string root);
}

public enum ThemeKind { Light, Dark }

public interface IThemeService
{
    void Apply(ThemeKind theme);
}

/// <summary>A drive (or folder) that holds, or can hold, a SecureUSB vault.</summary>
public sealed record VaultLocation(string Root, string DisplayName, string Details, bool HasVault, bool IsRemovable, bool IsAppDrive)
{
    public string StatusText => HasVault ? "Vault found" : "No vault yet";
}

public sealed record AppInfo(string Name, string Version, string Edition = "V1 - one password");
