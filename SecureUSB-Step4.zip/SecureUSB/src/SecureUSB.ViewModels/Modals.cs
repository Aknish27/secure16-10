using SecureUSB.ViewModels.Mvvm;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.ViewModels;

public abstract class PageViewModel : ViewModelBase, IDisposable
{
    public virtual void Dispose() { }
}

/// <summary>A dialog shown over the current page. Closing it completes <see cref="ModalHost.ShowModalAsync"/>.</summary>
public abstract class ModalViewModel : ViewModelBase
{
    protected ModalViewModel()
    {
        CloseCommand = new RelayCommand(RequestClose);
    }

    public abstract string Title { get; }

    /// <summary>true = the dialog shows vault data and must disappear when the vault locks (USB removal, auto-lock).</summary>
    public virtual bool ClosesOnLock => true;

    public bool IsCancelled { get; internal set; }

    public RelayCommand CloseCommand { get; }

    public event Action? CloseRequested;

    public void RequestClose() => CloseRequested?.Invoke();

    /// <summary>Called after the dialog is gone: clear anything sensitive.</summary>
    public virtual void OnClosed() { }
}

public sealed class ConfirmViewModel : ModalViewModel
{
    public ConfirmViewModel(ConfirmRequest request)
    {
        Request = request;
        ConfirmCommand = new RelayCommand(() => { Result = true; RequestClose(); });
        CancelCommand = new RelayCommand(() => { Result = false; RequestClose(); });
    }

    public ConfirmRequest Request { get; }
    public override string Title => Request.Title;
    public string Message => Request.Message;
    public string ConfirmText => Request.ConfirmText;
    public string CancelText => Request.CancelText;
    public bool IsDestructive => Request.IsDestructive;
    public override bool ClosesOnLock => false;
    public bool Result { get; private set; }
    public RelayCommand ConfirmCommand { get; }
    public RelayCommand CancelCommand { get; }
}

public sealed class PromptViewModel : ModalViewModel
{
    private string _text;

    public PromptViewModel(PromptRequest request)
    {
        Request = request;
        _text = request.InitialValue;
        ConfirmCommand = new RelayCommand(() => { Result = Text; RequestClose(); }, () => !string.IsNullOrWhiteSpace(Text));
        CancelCommand = new RelayCommand(() => { Result = null; RequestClose(); });
    }

    public PromptRequest Request { get; }
    public override string Title => Request.Title;
    public string Message => Request.Message;
    public string ConfirmText => Request.ConfirmText;
    public string? Result { get; private set; }

    public string Text
    {
        get => _text;
        set
        {
            if (SetProperty(ref _text, value)) ConfirmCommand.RaiseCanExecuteChanged();
        }
    }

    public RelayCommand ConfirmCommand { get; }
    public RelayCommand CancelCommand { get; }
}

public sealed class MessageViewModel : ModalViewModel
{
    public MessageViewModel(string title, string message, MessageKind kind)
    {
        Title = title;
        Message = message;
        Kind = kind;
    }

    public override string Title { get; }
    public string Message { get; }
    public MessageKind Kind { get; }
    public override bool ClosesOnLock => false;
}

/// <summary>
/// Shows one modal at a time (others wait their turn) and implements the dialog service the view-models use.
/// The window binds to <see cref="Current"/>.
/// </summary>
public sealed class ModalHost : ObservableObject, IDialogService
{
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly List<ModalViewModel> _pending = new();
    private ModalViewModel? _current;

    public ModalHost()
    {
        CloseCurrentCommand = new RelayCommand(() => _current?.RequestClose(), () => _current is not null);
    }

    public ModalViewModel? Current
    {
        get => _current;
        private set
        {
            if (!SetProperty(ref _current, value)) return;
            OnPropertyChanged(nameof(IsOpen));
            CloseCurrentCommand.RaiseCanExecuteChanged();
        }
    }

    public bool IsOpen => _current is not null;

    /// <summary>Bound to the Escape key.</summary>
    public RelayCommand CloseCurrentCommand { get; }

    public async Task ShowModalAsync(ModalViewModel modal)
    {
        ArgumentNullException.ThrowIfNull(modal);
        lock (_pending) _pending.Add(modal);

        await _gate.WaitAsync().ConfigureAwait(true);
        try
        {
            lock (_pending) _pending.Remove(modal);
            if (modal.IsCancelled)
            {
                modal.OnClosed();
                return;
            }

            var closed = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            void OnCloseRequested() => closed.TrySetResult();
            modal.CloseRequested += OnCloseRequested;
            Current = modal;
            try
            {
                await closed.Task.ConfigureAwait(true);
            }
            finally
            {
                modal.CloseRequested -= OnCloseRequested;
                Current = null;
                modal.OnClosed();
            }
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task<bool> ConfirmAsync(ConfirmRequest request)
    {
        var vm = new ConfirmViewModel(request);
        await ShowModalAsync(vm).ConfigureAwait(true);
        return vm.Result;
    }

    public async Task<string?> PromptAsync(PromptRequest request)
    {
        var vm = new PromptViewModel(request);
        await ShowModalAsync(vm).ConfigureAwait(true);
        return vm.Result;
    }

    public Task ShowMessageAsync(string title, string message, MessageKind kind = MessageKind.Information) =>
        ShowModalAsync(new MessageViewModel(title, message, kind));

    /// <summary>Closes (and cancels the waiting ones of) every dialog that shows vault data. Called when the vault locks.</summary>
    public void CloseVaultModals()
    {
        ModalViewModel? current;
        lock (_pending)
        {
            foreach (ModalViewModel m in _pending)
                if (m.ClosesOnLock) m.IsCancelled = true;
            current = _current;
        }
        if (current is { ClosesOnLock: true }) current.RequestClose();
    }
}

public enum BannerKind { Info, Warning, Error }

/// <summary>The strip at the top of the window (for example "The USB drive was removed").</summary>
public sealed class BannerViewModel : ObservableObject
{
    private string _message = "";
    private BannerKind _kind;
    private bool _isVisible;

    public BannerViewModel()
    {
        DismissCommand = new RelayCommand(Hide);
    }

    public string Message { get => _message; private set => SetProperty(ref _message, value); }
    public BannerKind Kind { get => _kind; private set => SetProperty(ref _kind, value); }
    public bool IsVisible { get => _isVisible; private set => SetProperty(ref _isVisible, value); }
    public RelayCommand DismissCommand { get; }

    public void Show(BannerKind kind, string message)
    {
        Kind = kind;
        Message = message;
        IsVisible = true;
    }

    public void Hide()
    {
        IsVisible = false;
        Message = "";
    }
}

public sealed record AutoLockChoice(int Minutes, string Label);

/// <summary>User preferences for this run only. Nothing is written to disk (nothing security-relevant is remembered).</summary>
public sealed class SessionSettings : ObservableObject
{
    public static readonly IReadOnlyList<AutoLockChoice> AutoLockChoices = new[]
    {
        new AutoLockChoice(0, "Never"),
        new AutoLockChoice(1, "After 1 minute"),
        new AutoLockChoice(5, "After 5 minutes"),
        new AutoLockChoice(10, "After 10 minutes"),
        new AutoLockChoice(15, "After 15 minutes"),
        new AutoLockChoice(30, "After 30 minutes")
    };

    private int _autoLockMinutes = 10;
    private bool _allowOpenInOtherPrograms;
    private bool _showPreview = true;
    private ThemeKind _theme = ThemeKind.Light;

    /// <summary>0 = never.</summary>
    public int AutoLockMinutes { get => _autoLockMinutes; set => SetProperty(ref _autoLockMinutes, Math.Max(0, value)); }

    /// <summary>Off by default: opening a file in another program creates a temporary decrypted copy.</summary>
    public bool AllowOpenInOtherPrograms { get => _allowOpenInOtherPrograms; set => SetProperty(ref _allowOpenInOtherPrograms, value); }

    public bool ShowPreview { get => _showPreview; set => SetProperty(ref _showPreview, value); }

    public ThemeKind Theme { get => _theme; set => SetProperty(ref _theme, value); }
}
