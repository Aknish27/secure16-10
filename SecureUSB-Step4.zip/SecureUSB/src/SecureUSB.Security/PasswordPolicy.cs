namespace SecureUSB.Security;

public enum PasswordStrength { VeryWeak = 0, Weak = 1, Fair = 2, Strong = 3, VeryStrong = 4 }

public sealed record PasswordAssessment(
    PasswordStrength Strength,
    double EstimatedBits,
    bool MeetsPolicy,
    IReadOnlyList<string> Issues,
    IReadOnlyList<string> Suggestions);

/// <summary>
/// Password-creation gate for first-time setup and password change.
///
/// Why this matters: Argon2id slows each guess, but an attacker who copies the vault attacks it
/// offline and never touches the app's login screen, so no in-app rate limit helps. The password
/// itself is the real security boundary, and this policy keeps users from choosing trivially
/// guessable ones.
///
/// This is a HEURISTIC estimator (length, character variety, repetition, simple sequences, small
/// common-password list). It is not a substitute for a full dictionary-based estimator such as zxcvbn;
/// a clever-looking but predictable password can still score well. Prefer passphrases.
/// </summary>
public static class PasswordPolicy
{
    public const int MinimumLength = 12;
    public const double MinimumBits = 50;

    private static readonly HashSet<string> CommonStems = new(StringComparer.Ordinal)
    {
        "password", "passphrase", "qwerty", "qwertyuiop", "asdfgh", "asdfghjkl", "zxcvbn", "qazwsx",
        "letmein", "welcome", "admin", "administrator", "login", "iloveyou", "monkey", "dragon",
        "football", "baseball", "master", "shadow", "sunshine", "princess", "secret", "changeme",
        "default", "company", "organization", "organisation", "secureusb", "usb", "flashdrive",
        "pendrive", "confidential", "trustno", "whatever", "freedom", "superman", "batman", "hello",
        "summer", "winter", "spring", "autumn", "abc", "test", "guest", "root", "user"
    };

    public static PasswordAssessment Evaluate(string? password)
    {
        var issues = new List<string>();
        var suggestions = new List<string>();

        if (string.IsNullOrEmpty(password))
        {
            issues.Add("A password is required.");
            return new PasswordAssessment(PasswordStrength.VeryWeak, 0, false, issues, suggestions);
        }

        bool lower = false, upper = false, digit = false, symbol = false, nonAscii = false;
        foreach (char c in password)
        {
            if (c > 127) nonAscii = true;
            else if (char.IsAsciiLetterLower(c)) lower = true;
            else if (char.IsAsciiLetterUpper(c)) upper = true;
            else if (char.IsAsciiDigit(c)) digit = true;
            else symbol = true;   // punctuation and space
        }

        int pool = (lower ? 26 : 0) + (upper ? 26 : 0) + (digit ? 10 : 0) + (symbol ? 33 : 0) + (nonAscii ? 64 : 0);
        int distinct = password.Distinct().Count();

        // Repeated characters carry little information; sequences like "abcd"/"4321" even less.
        double effectiveLength = distinct + (password.Length - distinct) * 0.25;
        effectiveLength -= SequencePenalty(password);
        if (effectiveLength < 0) effectiveLength = 0;

        double bits = pool > 1 ? effectiveLength * Math.Log2(pool) : 0;

        bool commonStem = IsCommonStem(password);
        if (!commonStem && ContainsCommonWord(password))
        {
            bits -= 15;
            suggestions.Add("Avoid common words such as 'password', 'welcome' or the organization's name.");
        }
        if (bits < 0) bits = 0;

        if (password.Length < MinimumLength)
            issues.Add($"Use at least {MinimumLength} characters.");
        if (commonStem)
            issues.Add("This is a very common password (or a trivial variation of one).");
        if (bits < MinimumBits)
            issues.Add("This password is too predictable (repeats, sequences or too few distinct characters).");

        if (issues.Count > 0)
            suggestions.Add("Use a passphrase of 4 or more unrelated random words (for example, picked with dice), 16+ characters.");

        PasswordStrength strength = bits switch
        {
            < 28 => PasswordStrength.VeryWeak,
            < 40 => PasswordStrength.Weak,
            < 60 => PasswordStrength.Fair,
            < 80 => PasswordStrength.Strong,
            _ => PasswordStrength.VeryStrong
        };
        if (commonStem) strength = PasswordStrength.VeryWeak;
        else if (password.Length < MinimumLength && strength > PasswordStrength.Weak) strength = PasswordStrength.Weak;

        return new PasswordAssessment(strength, Math.Round(bits, 1), issues.Count == 0, issues, suggestions);
    }

    private static int SequencePenalty(string s)
    {
        int penalty = 0, i = 0;
        while (i < s.Length - 1)
        {
            int step = s[i + 1] - s[i];
            if (step == 1 || step == -1)
            {
                int j = i + 1;
                while (j + 1 < s.Length && s[j + 1] - s[j] == step) j++;
                int run = j - i + 1;
                if (run >= 3) penalty += run - 2;
                i = j;
            }
            else
            {
                i++;
            }
        }
        return penalty;
    }

    private static string Deleet(string s)
    {
        var chars = s.ToLowerInvariant().ToCharArray();
        for (int i = 0; i < chars.Length; i++)
        {
            chars[i] = chars[i] switch
            {
                '0' => 'o', '1' => 'i', '3' => 'e', '4' => 'a', '5' => 's', '7' => 't',
                '@' => 'a', '$' => 's', '!' => 'i',
                var c => c
            };
        }
        return new string(chars);
    }

    /// <summary>Strips trailing digits/symbols ("Password123!" -> "Password"), then undoes simple leetspeak.</summary>
    private static bool IsCommonStem(string password)
    {
        int end = password.Length;
        while (end > 0 && !char.IsLetter(password[end - 1])) end--;
        if (end == 0) return false;   // no letters at all: handled by the entropy estimate
        return CommonStems.Contains(Deleet(password.Substring(0, end)));
    }

    private static bool ContainsCommonWord(string password)
    {
        string d = Deleet(password);
        foreach (string word in CommonStems)
            if (word.Length >= 6 && d.Contains(word, StringComparison.Ordinal)) return true;
        return false;
    }
}
