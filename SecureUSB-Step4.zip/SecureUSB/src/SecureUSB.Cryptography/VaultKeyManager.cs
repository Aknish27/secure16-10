using System.Security.Cryptography;
using SecureUSB.Models;

namespace SecureUSB.Cryptography;

/// <summary>Result of vault creation: the header to persist, and the unlocked keys for this session.</summary>
public sealed record NewVault(VaultHeader Header, VaultKeys Keys);

/// <summary>
/// Creates vaults, unlocks them with the single user password, and changes the password.
///
///   password --Argon2id(salt)--> KEK --AES-256-GCM--> wraps random Master Key
///
/// The password is never stored or compared. "Correct password" simply means the GCM tag of the
/// wrapped master key verifies. The master key itself is random and independent of the password,
/// so changing the password only re-wraps it; no file needs re-encrypting.
/// </summary>
public static class VaultKeyManager
{
    public static NewVault CreateVault(ReadOnlySpan<char> password, KdfParams? kdf = null)
    {
        kdf ??= KdfParams.Default;
        Guid vaultId = SecureRandom.NewGuid();

        var masterKey = new SecureBytes(VaultKeys.KeyLength);
        try
        {
            SecureRandom.Fill(masterKey.Span);
            VaultHeader header = BuildHeader(vaultId, masterKey.Span, password, kdf);
            return new NewVault(header, new VaultKeys(vaultId, masterKey));
        }
        catch
        {
            masterKey.Dispose();
            throw;
        }
    }

    /// <exception cref="VaultAuthenticationException">Wrong password, or the header was modified/corrupted.</exception>
    public static VaultKeys Unlock(ReadOnlySpan<char> password, VaultHeader header)
    {
        ArgumentNullException.ThrowIfNull(header);
        using SecureBytes kek = Argon2idKeyDeriver.DeriveKey(password, header.Salt, header.Kdf);
        try
        {
            SecureBytes masterKey = Aead.OpenSecure(kek.Span, header.WrappedMasterKey, header.GetAuthenticatedPrefix());
            if (masterKey.Length != VaultKeys.KeyLength)
            {
                masterKey.Dispose();
                throw new VaultAuthenticationException("Unexpected master key length.");
            }
            return new VaultKeys(header.VaultId, masterKey);
        }
        catch (CryptographicException ex) when (ex is not VaultAuthenticationException)
        {
            throw new VaultAuthenticationException("Wrong password, or the vault header is damaged or has been tampered with.", ex);
        }
    }

    /// <summary>
    /// Verifies the current password, then returns a NEW header wrapping the SAME master key under a
    /// new password with a fresh salt and nonce. The caller must persist it atomically
    /// (write temp, flush, replace, keep backup) - see Storage in Step 2.
    /// </summary>
    public static VaultHeader ChangePassword(
        ReadOnlySpan<char> currentPassword, ReadOnlySpan<char> newPassword, VaultHeader header, KdfParams? newKdf = null)
    {
        using VaultKeys keys = Unlock(currentPassword, header);
        return Rewrap(keys, newPassword, newKdf ?? header.Kdf);
    }

    /// <summary>For an already unlocked session (e.g. after re-prompting for the current password).</summary>
    public static VaultHeader Rewrap(VaultKeys keys, ReadOnlySpan<char> newPassword, KdfParams? kdf = null)
    {
        ArgumentNullException.ThrowIfNull(keys);
        return BuildHeader(keys.VaultId, keys.MasterKey, newPassword, kdf ?? KdfParams.Default);
    }

    private static VaultHeader BuildHeader(Guid vaultId, ReadOnlySpan<byte> masterKey, ReadOnlySpan<char> password, KdfParams kdf)
    {
        kdf.Validate();
        byte[] salt = SecureRandom.GetBytes(KdfParams.SaltLength);
        using SecureBytes kek = Argon2idKeyDeriver.DeriveKey(password, salt, kdf);

        // Build once with a placeholder so the authenticated prefix (everything before the wrapped key) is exact.
        var placeholder = new VaultHeader(vaultId, kdf, salt, new byte[VaultHeader.WrappedKeyLength]);
        byte[] wrapped = Aead.Seal(kek.Span, masterKey, placeholder.GetAuthenticatedPrefix());
        return new VaultHeader(vaultId, kdf, salt, wrapped);
    }
}
