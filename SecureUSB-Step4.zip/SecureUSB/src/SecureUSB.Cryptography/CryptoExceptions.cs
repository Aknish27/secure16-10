using System.Security.Cryptography;

namespace SecureUSB.Cryptography;

/// <summary>
/// The password was wrong OR the vault header was modified/corrupted. These two cases are
/// cryptographically indistinguishable (both fail the AES-GCM tag check), and the application
/// must not pretend otherwise. The UI should say "wrong password or damaged vault".
/// </summary>
public sealed class VaultAuthenticationException : CryptographicException
{
    public VaultAuthenticationException(string message, Exception? inner = null) : base(message, inner) { }
}

/// <summary>An encrypted blob or file stream failed authentication, or is truncated/malformed.</summary>
public sealed class DataIntegrityException : CryptographicException
{
    public DataIntegrityException(string message, Exception? inner = null) : base(message, inner) { }
}
