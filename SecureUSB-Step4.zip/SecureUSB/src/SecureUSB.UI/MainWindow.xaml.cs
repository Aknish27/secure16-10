using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using SecureUSB.ViewModels;

namespace SecureUSB.UI;

public partial class MainWindow : Window
{
    private readonly ShellViewModel _shell;
    private IInputElement? _focusBeforeDialog;

    public MainWindow(ShellViewModel shell)
    {
        _shell = shell;
        InitializeComponent();
        DataContext = shell;

        shell.Modals.PropertyChanged += OnModalsChanged;
        // any input counts as activity for the auto-lock countdown
        PreviewMouseMove += (_, _) => shell.NotifyActivity();
        PreviewKeyDown += (_, _) => shell.NotifyActivity();
        PreviewMouseDown += (_, _) => shell.NotifyActivity();
        Closing += OnClosing;
    }

    private void OnModalsChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName != nameof(ModalHost.Current)) return;

        if (_shell.Modals.Current is not null)
        {
            _focusBeforeDialog ??= Keyboard.FocusedElement;
            // let the dialog's view load first, then move keyboard focus into it
            Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() =>
            {
                if (!ModalContent.IsKeyboardFocusWithin) ModalLayer.MoveFocus(new TraversalRequest(FocusNavigationDirection.First));
            }));
        }
        else
        {
            IInputElement? previous = _focusBeforeDialog;
            _focusBeforeDialog = null;
            Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() => previous?.Focus()));
        }
    }

    private void OnClosing(object? sender, CancelEventArgs e)
    {
        // locks the vault, wipes temporary decrypted files and the keys
        _shell.Dispose();
    }
}
