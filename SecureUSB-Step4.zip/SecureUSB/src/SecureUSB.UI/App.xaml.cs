using System.Reflection;
using System.Windows;
using System.Windows.Threading;
using SecureUSB.UI.Services;
using SecureUSB.ViewModels;
using SecureUSB.ViewModels.Services;

namespace SecureUSB.UI;

public partial class App : Application
{
    private ShellViewModel? _shell;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        DispatcherUnhandledException += OnUnhandledException;

        string version = Assembly.GetExecutingAssembly().GetName().Version?.ToString(3) ?? "1.0.0";
        var services = new ShellServices
        {
            Factory = new VaultServiceFactory(),
            Locations = new DriveLocationProvider(),
            Modals = new ModalHost(),
            Files = new WpfFileDialogService(),
            Launcher = new ShellLauncher(),
            Ui = new WpfUiScheduler(Dispatcher),
            Theme = new ThemeService(),
            App = new AppInfo("SecureUSB", version)
        };

        _shell = new ShellViewModel(services);
        var window = new MainWindow(_shell);
        MainWindow = window;
        window.Show();
        _shell.Initialize();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _shell?.Dispose();
        base.OnExit(e);
    }

    /// <summary>Last line of defence: lock the vault, show a message without technical details, and keep running.</summary>
    private void OnUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        e.Handled = true;
        try { _shell?.Service?.Lock(); } catch { /* nothing more can be done */ }
        MessageBox.Show(
            "An unexpected error occurred. For your safety the vault was locked. You can unlock it again.",
            "SecureUSB", MessageBoxButton.OK, MessageBoxImage.Warning);
    }
}
