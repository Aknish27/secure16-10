using System.Windows;
using System.Windows.Controls;

namespace SecureUSB.UI.Controls;

/// <summary>Colour bar + word for a password's strength (Level: -1 none, 0 very weak ... 4 very strong).</summary>
public partial class StrengthMeter : UserControl
{
    public static readonly DependencyProperty LevelProperty = DependencyProperty.Register(
        nameof(Level), typeof(int), typeof(StrengthMeter), new PropertyMetadata(-1));

    public static readonly DependencyProperty FractionProperty = DependencyProperty.Register(
        nameof(Fraction), typeof(double), typeof(StrengthMeter), new PropertyMetadata(0d));

    public static readonly DependencyProperty TextProperty = DependencyProperty.Register(
        nameof(Text), typeof(string), typeof(StrengthMeter), new PropertyMetadata(""));

    public StrengthMeter()
    {
        InitializeComponent();
    }

    public int Level
    {
        get => (int)GetValue(LevelProperty);
        set => SetValue(LevelProperty, value);
    }

    public double Fraction
    {
        get => (double)GetValue(FractionProperty);
        set => SetValue(FractionProperty, value);
    }

    public string Text
    {
        get => (string)GetValue(TextProperty);
        set => SetValue(TextProperty, value);
    }
}
