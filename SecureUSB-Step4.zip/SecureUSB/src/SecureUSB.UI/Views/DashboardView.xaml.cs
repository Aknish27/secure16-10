using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using SecureUSB.ViewModels;

namespace SecureUSB.UI.Views;

public partial class DashboardView : UserControl
{
    public DashboardView()
    {
        InitializeComponent();
        InputBindings.Add(new KeyBinding(new FocusSearchCommand(this), Key.F, ModifierKeys.Control));
    }

    private DashboardViewModel? Model => DataContext as DashboardViewModel;

    public void FocusSearch()
    {
        SearchBox.Focus();
        SearchBox.SelectAll();
    }

    private void OnSelectionChanged(object sender, SelectionChangedEventArgs e) =>
        Model?.SetSelection(FileGrid.SelectedItems.OfType<VaultItemViewModel>().ToList());

    private void OnDoubleClick(object sender, MouseButtonEventArgs e)
    {
        // ignore double-clicks on column headers or empty space
        if (e.OriginalSource is not DependencyObject source) return;
        if (ItemsControl.ContainerFromElement(FileGrid, source) is not DataGridRow row) return;
        if (row.Item is VaultItemViewModel item) Model?.OpenItemCommand.Execute(item);
    }

    private void OnGridKeyDown(object sender, KeyEventArgs e)
    {
        if (Model is null) return;
        if (e.Key == Key.Enter && FileGrid.SelectedItem is VaultItemViewModel item)
        {
            Model.OpenItemCommand.Execute(item);
            e.Handled = true;
        }
        else if (e.Key == Key.Back)
        {
            Model.UpCommand.Execute(null);
            e.Handled = true;
        }
    }

    private sealed class FocusSearchCommand : ICommand
    {
        private readonly DashboardView _view;
        public FocusSearchCommand(DashboardView view) => _view = view;
        public event EventHandler? CanExecuteChanged { add { } remove { } }
        public bool CanExecute(object? parameter) => true;
        public void Execute(object? parameter) => _view.FocusSearch();
    }
}
