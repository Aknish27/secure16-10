using System.Windows;
using System.Windows.Controls;

namespace SecureUSB.UI.Views;

public partial class MessageView : UserControl
{
    public MessageView()
    {
        InitializeComponent();
        Loaded += OnLoaded;
    }

    private void OnLoaded(object sender, RoutedEventArgs e) => OkButton.Focus();
}
