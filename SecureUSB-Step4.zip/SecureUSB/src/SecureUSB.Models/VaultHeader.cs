using System.Buffers.Binary;

namespace SecureUSB.Models;

/// <summary>
/// Fixed-size (131 byte) binary vault header, stored as SecureUSB_Data/vault.hdr.
///
/// Layout (big-endian integers):
///   0   8  magic "SUSBVLT1"
///   8   2  format version (currently 1)
///  10  16  vault ID (random GUID bytes, unique per USB)
///  26   1  KDF id (1 = Argon2id)
///  27   4  Argon2 memory cost (KiB)
///  31   4  Argon2 iterations
///  35   4  Argon2 parallelism
///  39  32  Argon2 salt (random, unique per password set/change)
///  ---- bytes 0..70 are the "authenticated prefix" used as AES-GCM AAD ----
///  71  60  wrapped master key = nonce(12) | AES-256-GCM ciphertext(32) | tag(16)
///
/// Nothing in this header is secret. Everything in it is authenticated: any change to the
/// prefix makes the master-key unwrap fail its GCM tag check.
/// There are deliberately no second-factor / organization-key fields in V1; adding one later
/// means a new format version.
/// </summary>
public sealed class VaultHeader
{
    public const ushort CurrentFormatVersion = 1;
    public const byte KdfIdArgon2id = 1;

    public const int VaultIdOffset = 10;
    public const int KdfIdOffset = 26;
    public const int KdfMemoryOffset = 27;
    public const int KdfIterationsOffset = 31;
    public const int KdfParallelismOffset = 35;
    public const int SaltOffset = 39;
    public const int AuthenticatedPrefixLength = SaltOffset + KdfParams.SaltLength;   // 71
    public const int WrappedKeyOffset = AuthenticatedPrefixLength;                   // 71
    public const int WrappedKeyLength = 12 + 32 + 16;                                // 60
    public const int TotalLength = WrappedKeyOffset + WrappedKeyLength;              // 131

    private static ReadOnlySpan<byte> Magic => "SUSBVLT1"u8;

    private readonly byte[] _salt;
    private readonly byte[] _wrappedMasterKey;

    public VaultHeader(Guid vaultId, KdfParams kdf, ReadOnlySpan<byte> salt, ReadOnlySpan<byte> wrappedMasterKey)
        : this(CurrentFormatVersion, vaultId, kdf, salt, wrappedMasterKey) { }

    private VaultHeader(ushort version, Guid vaultId, KdfParams kdf, ReadOnlySpan<byte> salt, ReadOnlySpan<byte> wrappedMasterKey)
    {
        ArgumentNullException.ThrowIfNull(kdf);
        if (salt.Length != KdfParams.SaltLength)
            throw new ArgumentException($"Salt must be {KdfParams.SaltLength} bytes.", nameof(salt));
        if (wrappedMasterKey.Length != WrappedKeyLength)
            throw new ArgumentException($"Wrapped master key must be {WrappedKeyLength} bytes.", nameof(wrappedMasterKey));
        kdf.Validate();

        FormatVersion = version;
        VaultId = vaultId;
        Kdf = kdf;
        _salt = salt.ToArray();
        _wrappedMasterKey = wrappedMasterKey.ToArray();
    }

    public ushort FormatVersion { get; }
    public Guid VaultId { get; }
    public KdfParams Kdf { get; }
    public ReadOnlySpan<byte> Salt => _salt;
    public ReadOnlySpan<byte> WrappedMasterKey => _wrappedMasterKey;

    public byte[] ToBytes()
    {
        var buffer = new byte[TotalLength];
        Span<byte> s = buffer;

        Magic.CopyTo(s);
        BinaryPrimitives.WriteUInt16BigEndian(s.Slice(8, 2), FormatVersion);
        VaultId.TryWriteBytes(s.Slice(VaultIdOffset, 16));
        s[KdfIdOffset] = KdfIdArgon2id;
        BinaryPrimitives.WriteInt32BigEndian(s.Slice(KdfMemoryOffset, 4), Kdf.MemoryKiB);
        BinaryPrimitives.WriteInt32BigEndian(s.Slice(KdfIterationsOffset, 4), Kdf.Iterations);
        BinaryPrimitives.WriteInt32BigEndian(s.Slice(KdfParallelismOffset, 4), Kdf.Parallelism);
        _salt.CopyTo(s.Slice(SaltOffset, KdfParams.SaltLength));
        _wrappedMasterKey.CopyTo(s.Slice(WrappedKeyOffset, WrappedKeyLength));
        return buffer;
    }

    /// <summary>The bytes bound to the wrapped master key as AES-GCM associated data.</summary>
    public byte[] GetAuthenticatedPrefix() => ToBytes().AsSpan(0, AuthenticatedPrefixLength).ToArray();

    public static VaultHeader Parse(ReadOnlySpan<byte> data)
    {
        if (data.Length != TotalLength)
            throw new InvalidVaultFormatException($"Vault header must be exactly {TotalLength} bytes (found {data.Length}).");
        if (!data.Slice(0, 8).SequenceEqual(Magic))
            throw new InvalidVaultFormatException("Not a SecureUSB vault header (bad magic).");

        ushort version = BinaryPrimitives.ReadUInt16BigEndian(data.Slice(8, 2));
        if (version != CurrentFormatVersion)
            throw new InvalidVaultFormatException($"Unsupported vault format version {version}.");
        if (data[KdfIdOffset] != KdfIdArgon2id)
            throw new InvalidVaultFormatException("Unsupported key-derivation function.");

        var kdf = new KdfParams(
            BinaryPrimitives.ReadInt32BigEndian(data.Slice(KdfMemoryOffset, 4)),
            BinaryPrimitives.ReadInt32BigEndian(data.Slice(KdfIterationsOffset, 4)),
            BinaryPrimitives.ReadInt32BigEndian(data.Slice(KdfParallelismOffset, 4)));
        kdf.Validate();

        var vaultId = new Guid(data.Slice(VaultIdOffset, 16));
        return new VaultHeader(version, vaultId, kdf,
            data.Slice(SaltOffset, KdfParams.SaltLength),
            data.Slice(WrappedKeyOffset, WrappedKeyLength));
    }
}
