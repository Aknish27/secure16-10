using System.Globalization;

namespace SecureUSB.Models;

/// <summary>
/// Validation rules for names stored in the vault index. Names are DISPLAY data only (blobs on disk are
/// named by random IDs), but they become real file names on export, so the vault refuses anything that
/// could escape a directory, spoof an extension, or be a reserved Windows device name.
/// Step 3's FilenameSanitizer turns arbitrary input into names that pass these rules.
/// </summary>
public static class EntryNames
{
    public const int MaxNameLength = 255;
    public const int MaxFolderPathLength = 1024;
    public const int MaxFolderDepth = 32;

    private const string ForbiddenChars = "<>:\"/\\|?*";

    private static readonly HashSet<string> ReservedDeviceNames = new(StringComparer.OrdinalIgnoreCase)
    {
        "CON", "PRN", "AUX", "NUL",
        "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
        "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"
    };

    public static string NormalizeFolderPath(string? folderPath) => folderPath ?? "";

    public static bool IsValidName(string? name, out string reason)
    {
        reason = "";
        if (string.IsNullOrEmpty(name)) { reason = "Name is empty."; return false; }
        if (name.Length > MaxNameLength) { reason = $"Name is longer than {MaxNameLength} characters."; return false; }
        if (name[0] == ' ') { reason = "Name must not start with a space."; return false; }
        if (name[^1] == ' ' || name[^1] == '.') { reason = "Name must not end with a space or a dot."; return false; }

        foreach (char c in name)
        {
            if (c < 0x20 || c == 0x7F) { reason = "Name contains a control character."; return false; }
            if (ForbiddenChars.Contains(c)) { reason = $"Name contains the forbidden character '{c}'."; return false; }
            // Format characters include right-to-left overrides (U+202E) used to disguise extensions.
            if (char.GetUnicodeCategory(c) == UnicodeCategory.Format) { reason = "Name contains an invisible formatting character."; return false; }
        }

        int dot = name.IndexOf('.');
        string stem = (dot < 0 ? name : name[..dot]).TrimEnd(' ');
        if (ReservedDeviceNames.Contains(stem)) { reason = "Name is a reserved device name."; return false; }
        return true;
    }

    /// <summary>"" is the vault root. Otherwise segments separated by '/', no empty segments, no "." or "..".</summary>
    public static bool IsValidFolderPath(string? folderPath, out string reason)
    {
        reason = "";
        string path = NormalizeFolderPath(folderPath);
        if (path.Length == 0) return true;
        if (path.Length > MaxFolderPathLength) { reason = "Folder path is too long."; return false; }

        string[] segments = path.Split('/');
        if (segments.Length > MaxFolderDepth) { reason = $"Folder nesting is deeper than {MaxFolderDepth}."; return false; }
        foreach (string segment in segments)
        {
            if (!IsValidName(segment, out string segmentReason))
            {
                reason = $"Invalid folder name: {segmentReason}";
                return false;
            }
        }
        return true;
    }
}
