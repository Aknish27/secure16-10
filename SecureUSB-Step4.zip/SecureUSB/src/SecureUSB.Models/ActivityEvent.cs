namespace SecureUSB.Models;

public enum ActivityKind
{
    VaultCreated = 1,
    UnlockSucceeded = 2,
    UnlockFailuresReported = 3,
    VaultLocked = 4,
    FileAdded = 5,
    FolderAdded = 6,
    FileExported = 7,
    FileOpenedExternally = 8,
    FileRenamed = 9,
    FileDeleted = 10,
    PasswordChanged = 11,
    UsbRemoved = 12,
    IntegrityChecked = 13,
    IntegrityRepaired = 14,
    IndexRebuilt = 15,
    HeaderRecoveredFromBackup = 16,
    TempFilesCleaned = 17,
    Warning = 18
}

/// <summary>One line of the encrypted security/activity log (visible only after unlocking).</summary>
public sealed record ActivityEvent
{
    public DateTimeOffset TimestampUtc { get; init; }
    public ActivityKind Kind { get; init; }
    public string Message { get; init; } = "";
}
