namespace SecureUSB.Models;

/// <summary>
/// Argon2id cost parameters. They are stored (unencrypted but authenticated) in the
/// vault header so the cost can be raised in future versions without breaking old vaults.
/// Bounds are enforced when a header is parsed, so a tampered header cannot make the
/// application allocate gigabytes of RAM or run for hours (denial-of-service guard).
/// </summary>
public sealed record KdfParams(int MemoryKiB, int Iterations, int Parallelism)
{
    public const int MinMemoryKiB = 8 * 1024;          // 8 MiB  (hard floor; tests use this)
    public const int MaxMemoryKiB = 1024 * 1024;       // 1 GiB  (hard ceiling)
    public const int MinIterations = 1;
    public const int MaxIterations = 16;
    public const int MinParallelism = 1;
    public const int MaxParallelism = 16;

    public const int SaltLength = 32;
    public const int DerivedKeyLength = 32;

    /// <summary>Default for new vaults: 128 MiB, 3 passes, 4 lanes. Measure on target hardware.</summary>
    public static KdfParams Default { get; } = new(MemoryKiB: 131_072, Iterations: 3, Parallelism: 4);

    /// <summary>
    /// Policy floor the application should require when OPENING or CREATING a real vault.
    /// Parsing accepts anything within hard bounds; Core (Step 3) warns when this is not met.
    /// </summary>
    public bool MeetsProductionPolicy => MemoryKiB >= 65_536 && Iterations >= 3;

    public void Validate()
    {
        if (MemoryKiB < MinMemoryKiB || MemoryKiB > MaxMemoryKiB)
            throw new InvalidVaultFormatException($"KDF memory cost out of range ({MinMemoryKiB}-{MaxMemoryKiB} KiB).");
        if (Iterations < MinIterations || Iterations > MaxIterations)
            throw new InvalidVaultFormatException($"KDF iteration count out of range ({MinIterations}-{MaxIterations}).");
        if (Parallelism < MinParallelism || Parallelism > MaxParallelism)
            throw new InvalidVaultFormatException($"KDF parallelism out of range ({MinParallelism}-{MaxParallelism}).");
    }
}
