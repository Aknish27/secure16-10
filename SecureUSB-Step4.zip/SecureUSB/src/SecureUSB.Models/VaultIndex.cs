namespace SecureUSB.Models;

/// <summary>The decrypted file index: the vault's table of contents.</summary>
public sealed record VaultIndex
{
    public const int CurrentFormatVersion = 1;
    public const int MaxEntries = 1_000_000;
    public const int MinChunkSize = 1024;
    public const int MaxChunkSize = 16 * 1024 * 1024;

    public int FormatVersion { get; init; } = CurrentFormatVersion;
    public Guid VaultId { get; init; }
    /// <summary>Increases on every change. Lets recovery pick the newest of several index copies.</summary>
    public long Revision { get; init; }
    public DateTimeOffset CreatedUtc { get; init; }
    public DateTimeOffset UpdatedUtc { get; init; }
    public IReadOnlyList<FileEntry> Files { get; init; } = Array.Empty<FileEntry>();

    public static VaultIndex CreateEmpty(Guid vaultId, DateTimeOffset now) => new()
    {
        VaultId = vaultId,
        Revision = 1,
        CreatedUtc = now,
        UpdatedUtc = now
    };

    public VaultIndex WithFiles(IReadOnlyList<FileEntry> files, DateTimeOffset now) =>
        this with { Files = files, Revision = Revision + 1, UpdatedUtc = now };

    /// <summary>Defensive validation of an index that decrypted successfully (it may still be malformed).</summary>
    public void Validate(Guid expectedVaultId)
    {
        if (FormatVersion != CurrentFormatVersion)
            throw new InvalidVaultFormatException($"Unsupported index format version {FormatVersion}.");
        if (VaultId != expectedVaultId)
            throw new InvalidVaultFormatException("Index belongs to a different vault.");
        if (Revision < 0)
            throw new InvalidVaultFormatException("Invalid index revision.");
        if (Files is null)
            throw new InvalidVaultFormatException("Index has no file list.");
        if (Files.Count > MaxEntries)
            throw new InvalidVaultFormatException("Index has too many entries.");

        var ids = new HashSet<Guid>();
        var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (FileEntry? f in Files)
        {
            if (f is null) throw new InvalidVaultFormatException("Index contains an empty entry.");
            if (f.Id == Guid.Empty || !ids.Add(f.Id))
                throw new InvalidVaultFormatException("Index contains a missing or duplicate file ID.");
            if (!EntryNames.IsValidName(f.Name, out string reason))
                throw new InvalidVaultFormatException($"Index contains an invalid file name: {reason}");
            if (!EntryNames.IsValidFolderPath(f.FolderPath, out reason))
                throw new InvalidVaultFormatException($"Index contains an invalid folder path: {reason}");
            if (f.SizeBytes < 0)
                throw new InvalidVaultFormatException("Index contains a negative file size.");
            if (f.ChunkSize < MinChunkSize || f.ChunkSize > MaxChunkSize)
                throw new InvalidVaultFormatException("Index contains an invalid chunk size.");
            if (!paths.Add(f.FolderPath + "\n" + f.Name))
                throw new InvalidVaultFormatException("Index contains two files with the same name in one folder.");
        }
    }
}
